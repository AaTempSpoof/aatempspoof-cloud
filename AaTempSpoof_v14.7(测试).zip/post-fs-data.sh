#!/system/bin/sh
MODDIR=${0%/*}
BIN="$MODDIR/bin/AaTempSpoof"

[ -x "$BIN" ] || exit 0
"$BIN" --load-kcompat --moddir "$MODDIR" >/dev/null 2>&1 || true
"$BIN" --post-fs-data --moddir "$MODDIR" >/dev/null 2>&1
exit 0
