#!/system/bin/sh
PATH="/system/bin:/system/xbin:/vendor/bin:/product/bin:${PATH:-}"
export PATH

case "$0" in
    */*) MODDIR=${0%/*} ;;
    *) MODDIR=$(pwd) ;;
esac
MODDIR=$(CDPATH= cd -- "$MODDIR" 2>/dev/null && pwd) ||
    MODDIR="/data/adb/modules/AAaTempSpoof"
BIN="$MODDIR/bin/AaTempSpoof"

[ -x "$BIN" ] || exit 0
# 这里只执行原有的文件/配置初始化；内核兼容层必须等 service 阶段
# boot_completed 且 oplus_chg_v2 稳定后再加载，避免不同 root 管理器的
# post-fs-data 时序过早导致模块竞态或设备卡死。
"$BIN" --post-fs-data --moddir "$MODDIR" >/dev/null 2>&1
exit 0
