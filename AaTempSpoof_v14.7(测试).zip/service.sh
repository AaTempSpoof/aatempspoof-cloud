#!/system/bin/sh

# 不依赖任一 Root 管理器注入的 PATH。
PATH="/system/bin:/system/xbin:/vendor/bin:/product/bin:${PATH:-}"
export PATH

case "$0" in
    */*) MODDIR="${0%/*}" ;;
    *) MODDIR="$(pwd)" ;;
esac
MODDIR=$(CDPATH= cd -- "$MODDIR" 2>/dev/null && pwd) ||
    MODDIR="/data/adb/modules/AAaTempSpoof"
BIN="$MODDIR/bin/AaTempSpoof"
GAUGE_PATH="/sys/module/oplus_chg_v2/parameters/gauge_dbg_tbat"
VIRTUAL_IC_ROOT="/sys/class/virtual_ic"

CFGDIR="$MODDIR/bin/config/AaTempSpoof"
PIDDIR="$MODDIR/pid"
LOG="$CFGDIR/tempspoof.log"
KCOMPAT_WAIT_LIMIT=30
KCOMPAT_DIAG_PID="$PIDDIR/kcompat_diag.pid"
KCOMPAT_LOADER_PID="$PIDDIR/kcompat_loader.pid"

mkdir -p "$CFGDIR" "$PIDDIR"

PIDFILE="$PIDDIR/daemon.pid"
CBPID="$PIDDIR/cb.pid"
TOUCHPID="$PIDDIR/touch_daemon.pid"
TOMBSTONEPID="$PIDDIR/color_tombstone.pid"
CHARGEPID="$PIDDIR/charge_horae_daemon.pid"
NOTIFY_FILE="$PIDDIR/通知"

FLAGFILE="$PIDDIR/fake_batt_temp"
STOP_FLAG="$CFGDIR/user_stopped"

_log() {
    printf '[%s] [service] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOG"
}

_diag_log() {
    _diag_line="[$(date '+%Y-%m-%d %H:%M:%S')] [kcompat] $1"
    # 内核兼容诊断与模块运行日志统一保存，避免依赖共享存储挂载时序。
    printf '%s\n' "$_diag_line" >> "$LOG" 2>/dev/null
    unset _diag_line
}

_diag_block() {
    _diag_label="$1"
    shift
    _diag_log "$_diag_label"
    "$@" 2>&1 | while IFS= read -r _diag_line; do
        _diag_log "  $_diag_line"
    done
    unset _diag_label _diag_line
}

_diag_capabilities() {
    _diag_log "uid=$(id -u 2>/dev/null) gid=$(id -g 2>/dev/null)"
    _diag_log "moddir=$MODDIR"
    _diag_log "manager_env KSU=$([ -n "$KSU" ] && printf set || printf unset) APATCH=$([ -n "$APATCH" ] && printf set || printf unset) MAGISK_VER_CODE=$([ -n "$MAGISK_VER_CODE" ] && printf set || printf unset)"
    _diag_log "root_paths ksud=$([ -x /data/adb/ksud ] && printf yes || printf no) apd=$([ -x /data/adb/apd ] && printf yes || printf no) magisk=$([ -x /data/adb/magisk ] && printf yes || printf no)"
    _diag_log "modules_disabled=$(cat /proc/sys/kernel/modules_disabled 2>/dev/null || printf unavailable) proc_modules=$([ -r /proc/modules ] && printf readable || printf unavailable)"
    _diag_log "kptr_restrict=$(cat /proc/sys/kernel/kptr_restrict 2>/dev/null || printf unavailable)"
}

_diag_opbatt_view() {
    local opid opcmd opns viewtemp procdir
    opid=$(pidof opbatt_control 2>/dev/null)
    opid=${opid%% *}
    [ -n "$opid" ] || opid=$(pidof opbatt 2>/dev/null)
    opid=${opid%% *}
    if [ -z "$opid" ]; then
        for procdir in /proc/[0-9]*; do
            [ -r "$procdir/cmdline" ] || continue
            opcmd=$(tr '\0' ' ' < "$procdir/cmdline" 2>/dev/null)
            case "$opcmd" in
                *opbatt*) opid=${procdir##*/}; break ;;
            esac
        done
    fi
    [ -n "$opid" ] || {
        _diag_log "opbatt_pid=not_found"
        return 0
    }
    opcmd=$(tr '\0' ' ' < "/proc/$opid/cmdline" 2>/dev/null)
    opns=$(readlink "/proc/$opid/ns/mnt" 2>/dev/null || printf unavailable)
    viewtemp=$(cat "/proc/$opid/root/sys/class/power_supply/battery/temp" 2>/dev/null || printf unavailable)
    _diag_log "opbatt_pid=$opid cmd=${opcmd:-unavailable} mnt_ns=$opns visible_battery_temp=$viewtemp"
    if [ -r "/proc/$opid/mountinfo" ]; then
        _diag_block "opbatt_mounts" sh -c "grep -E 'power_supply|vendor_dlkm|oplus' '/proc/$opid/mountinfo' | tail -n 40 || true"
    fi
    unset opid opcmd opns viewtemp procdir
}

_diag_snapshot() {
    _diag_reason="$1"
    _diag_log "---- snapshot: ${_diag_reason:-unspecified} ----"
    _diag_log "version=$(grep '^version=' "$MODDIR/module.prop" 2>/dev/null | cut -d= -f2)"
    _diag_log "model=$(getprop ro.product.model 2>/dev/null) board=$(getprop ro.board.platform 2>/dev/null) android=$(getprop ro.build.version.release 2>/dev/null)"
    _diag_log "kernel=$(uname -r 2>/dev/null) boot=$(getprop sys.boot_completed 2>/dev/null)"
    _diag_capabilities
    _diag_opbatt_view
    _diag_virtual_ic
    _diag_log "temperature_params gauge_dbg_tbat=$([ -w /sys/module/oplus_chg_v2/parameters/gauge_dbg_tbat ] && printf writable || printf unavailable) oplus_dbg_tbat=$([ -w /sys/module/oplus_chg_v2/parameters/oplus_dbg_tbat ] && printf writable || printf unavailable) usbtemp=$([ -w /sys/module/oplus_chg_v2/parameters/usbtemp_debug ] && printf writable || printf unavailable)"
    if [ -r /proc/modules ]; then
        _diag_block "loaded_modules(oplus/aats)" sh -c "grep -E '^(oplus_chg_v2|aats_kcompat)[[:space:]]' /proc/modules || true"
    fi
    if [ -f "$CFGDIR/内核兼容状态.txt" ]; then
        _diag_block "kcompat_state" sed -n '1,80p' "$CFGDIR/内核兼容状态.txt"
    else
        _diag_log "kcompat_state=missing"
    fi
    if [ -x "$BIN" ]; then
        _diag_block "kcompat_status_cmd" "$BIN" --kcompat-status --moddir "$MODDIR"
    fi
    if [ -r /dev/aats_kcompat ]; then
        _diag_log "device=/dev/aats_kcompat present"
    else
        _diag_log "device=/dev/aats_kcompat absent"
    fi
    if [ -r /proc/kmsg ]; then
        _diag_block "dmesg(filtered)" sh -c "dmesg 2>/dev/null | grep -Ei 'aats|oplus_chg_v2|opbatt|kcompat|module' | tail -n 80 || true"
    fi
    if [ -x /system/bin/logcat ]; then
        _diag_block "logcat_kernel(filtered)" sh -c "logcat -b kernel -d -t 80 2>/dev/null | grep -Ei 'aats|oplus_chg_v2|opbatt|kcompat|module' || true"
    fi
    _diag_log "---- end snapshot ----"
    unset _diag_reason
}

_find_opbatt_target() {
    # 只检查常见的只读模块目录，不递归扫描共享存储或 data，避免启动阶段卡顿。
    for _target in \
        /vendor_dlkm/lib/modules/oplus_chg_v2.ko \
        /vendor/lib/modules/oplus_chg_v2.ko \
        /odm_dlkm/lib/modules/oplus_chg_v2.ko \
        /system/lib/modules/oplus_chg_v2.ko \
        /system_dlkm/lib/modules/oplus_chg_v2.ko; do
        [ -f "$_target" ] && { printf '%s\n' "$_target"; unset _target; return 0; }
    done
    unset _target
    return 1
}

_sha256_file() {
    [ -f "$1" ] || return 1
    if command -v sha256sum >/dev/null 2>&1; then
        _sha_line=$(sha256sum "$1" 2>/dev/null)
        printf '%s\n' "${_sha_line%% *}"
        unset _sha_line
        return
    fi
    if command -v toybox >/dev/null 2>&1; then
        _sha_line=$(toybox sha256sum "$1" 2>/dev/null)
        printf '%s\n' "${_sha_line%% *}"
        unset _sha_line
        return
    fi
    return 1
}

_native_virtual_ic_profile() {
    local target sha manifest
    target=$(_find_opbatt_target 2>/dev/null) || return 1
    sha=$(_sha256_file "$target" 2>/dev/null) || return 1
    manifest="$MODDIR/bin/kcompat/manifest.tsv"
    [ -r "$manifest" ] || return 1
    awk -F '\t' -v expected="$sha" '
        $1 !~ /^#/ && NF == 8 && $4 == expected &&
        $5 == "-" && $6 == "*" && $7 == "virtual_ic" && $8 == "-" {
            found = 1
        }
        END { exit found ? 0 : 1 }
    ' "$manifest" >/dev/null 2>&1
}

_diag_virtual_ic() {
    local target sha backend D name func
    target=$(_find_opbatt_target 2>/dev/null)
    sha=$(_sha256_file "$target" 2>/dev/null)
    backend=legacy
    _native_virtual_ic_profile && backend=native-virtual_ic
    _diag_log "opbatt_target=${target:-unavailable} sha=${sha:-unavailable} backend=$backend"
    for D in "$VIRTUAL_IC_ROOT"/vic-*; do
        [ -e "$D" ] || continue
        name=$(tr -d '\r\n' < "$D/name" 2>/dev/null)
        func=$(tr -d ' \r\n' < "$D/func_id" 2>/dev/null)
        _diag_log "virtual_ic node=${D##*/} name=${name:-unavailable} func_id=${func:-unavailable} overwrite=$([ -w "$D/overwrite" ] && printf writable || printf unavailable) clean=$([ -w "$D/clean_overwrite" ] && printf writable || printf unavailable)"
    done
    unset target sha backend D name func
}

_opbatt_loaded() {
    [ -d /sys/module/oplus_chg_v2 ] && return 0
    [ -r /proc/modules ] &&
        grep -q '^oplus_chg_v2[[:space:]]' /proc/modules 2>/dev/null
}

_wait_opbatt_stable() {
    local elapsed stable target sha prev
    elapsed=0
    stable=0
    target=""
    sha=""
    prev=""
    _diag_log "等待 opbatt 充电内核稳定（最多 ${KCOMPAT_WAIT_LIMIT}s）"
    while [ "$elapsed" -lt "$KCOMPAT_WAIT_LIMIT" ]; do
        if _opbatt_loaded; then
            target=$(_find_opbatt_target 2>/dev/null)
            if [ -n "$target" ]; then
                sha=$(_sha256_file "$target" 2>/dev/null)
                if [ -n "$sha" ] && [ "$sha" = "$prev" ]; then
                    stable=$((stable + 1))
                else
                    stable=1
                fi
                prev="$sha"
                _diag_log "opbatt candidate=$target sha=${sha:-unavailable} stable=$stable"
            else
                # 某些厂商把原始 ko 放在只读镜像的隐藏路径；此时以 sysfs 模块
                # 连续存在作为稳定信号，最终 profile 校验仍由主程序执行。
                stable=$((stable + 1))
                _diag_log "opbatt module loaded, source path unavailable stable=$stable"
                # The userspace loader deliberately hashes the exact
                # uncompressed vendor module. Continuing to spin when that
                # path is hidden cannot make a profile loadable and used to
                # make boot look hung, so fail fast and leave the legacy
                # sysfs path untouched.
                _diag_log "opbatt 已加载但找不到可校验的未压缩 ko，跳过兼容层"
                unset elapsed stable target sha prev
                return 1
            fi
            [ "$stable" -ge 3 ] && {
                _diag_log "opbatt 充电内核已稳定 target=${target:-unknown} sha=${sha:-unknown}"
                unset elapsed stable target sha prev
                return 0
            }
        else
            stable=0
            prev=""
            # 目标充电模块若在 10 秒内仍未出现，继续等待不会改变
            # profile 解析结果，避免模块服务把启动拖到 30 秒。
            if [ "$elapsed" -ge 10 ]; then
                _diag_log "opbatt 充电内核未出现，拒绝兼容层加载"
                _diag_snapshot "opbatt_not_loaded"
                unset elapsed stable target sha prev
                return 1
            fi
        fi
        sleep 2
        elapsed=$((elapsed + 2))
    done
    _diag_log "opbatt 充电内核等待超时，拒绝早期加载"
    _diag_snapshot "opbatt_wait_timeout"
    unset elapsed stable target sha prev
    return 1
}

_start_kcompat_diag_monitor() {
    local old
    if [ -s "$KCOMPAT_DIAG_PID" ]; then
        old=$(cat "$KCOMPAT_DIAG_PID" 2>/dev/null)
        case "$old" in
            ''|*[!0-9]*) ;;
            *) kill -0 "$old" 2>/dev/null && return 0 ;;
        esac
        rm -f "$KCOMPAT_DIAG_PID" 2>/dev/null
    fi
    (
        sleep 10
        _diag_snapshot "kcompat_after_10s"
        sleep 50
        _diag_snapshot "kcompat_after_60s"
        rm -f "$KCOMPAT_DIAG_PID" 2>/dev/null
    ) &
    printf '%s\n' "$!" > "$KCOMPAT_DIAG_PID" 2>/dev/null
    unset old
}

_sec() {
    local _ts
    _ts=$(date '+%Y-%m-%d %H:%M:%S')
    printf '\n' >> "$LOG"
    printf '[%s] [service] ┌─────────────────────────────────────┐\n' "$_ts" >> "$LOG"
    printf '[%s] [service] │  %-35s│\n' "$_ts" "$1" >> "$LOG"
    printf '[%s] [service] └─────────────────────────────────────┘\n' "$_ts" >> "$LOG"
}

_trim_pid() {
    tr -d ' \r\n' 2>/dev/null
}

_umount_all() {
    local I
    [ -n "$1" ] || return
    I=0
    while [ "$I" -lt 8 ]; do
        umount -l "$1" >/dev/null 2>&1 || break
        I=$((I + 1))
    done
}

_clear_kernel_virtual_gauge() {
    local D NAME FUNCS FUNC OLD SELECTED RESTORED BACKEND NODES ATTEMPTS CLEANED
    BACKEND=legacy
    NODES=0
    ATTEMPTS=0
    CLEANED=0
    if _native_virtual_ic_profile; then
        BACKEND=native-virtual_ic
        FUNCS="405 448 509 510 527 528 532 315"
    fi
    for D in "$VIRTUAL_IC_ROOT"/vic-*; do
        [ -w "$D/func_id" ] && [ -w "$D/clean_overwrite" ] || continue
        if [ "$BACKEND" = legacy ]; then
            [ -r "$D/name" ] || continue
            NAME=$(tr -d '\r\n' < "$D/name" 2>/dev/null)
            case "$NAME" in
                oplus,virtual_gauge) FUNCS="405" ;;
                oplus,adsp_gauge) FUNCS="448" ;;
                oplus,virtual_buck) FUNCS="510 528" ;;
                oplus,pm8550_charger) FUNCS="510" ;;
                oplus,adsp_mos|oplus,ufcs_virtual_cp) FUNCS="315" ;;
                *) continue ;;
            esac
        fi
        OLD=$(tr -d ' \r\n' < "$D/func_id" 2>/dev/null)
        case "$OLD" in ''|*[!0-9-]*) continue ;; esac
        NODES=$((NODES + 1))
        for FUNC in $FUNCS; do
            ATTEMPTS=$((ATTEMPTS + 1))
            printf '%s\n' "$FUNC" > "$D/func_id" 2>/dev/null || continue
            SELECTED=$(tr -d ' \r\n' < "$D/func_id" 2>/dev/null)
            [ "$SELECTED" = "$FUNC" ] || continue
            if printf '1\n' > "$D/clean_overwrite" 2>/dev/null; then
                CLEANED=$((CLEANED + 1))
            fi
        done
        printf '%s\n' "$OLD" > "$D/func_id" 2>/dev/null
        RESTORED=$(tr -d ' \r\n' < "$D/func_id" 2>/dev/null)
        if [ "$RESTORED" != "$OLD" ]; then
            printf '%s\n' "$OLD" > "$D/func_id" 2>/dev/null
        fi
    done
    _diag_log "virtual_ic_cleanup backend=$BACKEND nodes=$NODES clean=$CLEANED/$ATTEMPTS"
}

_clear_kernel_usb_therm() {
    local Z TYPE LABEL_PATH LABEL INPUT NAME
    for Z in /sys/class/thermal/thermal_zone*; do
        [ -r "$Z/type" ] || continue
        TYPE=$(tr '[:upper:]-' '[:lower:]_' < "$Z/type" 2>/dev/null | tr -d '\r\n')
        case "$TYPE" in
            usb|*usb_therm*|*svooc_mos_btb*)
                [ -w "$Z/emul_temp" ] && printf '0\n' > "$Z/emul_temp" 2>/dev/null
                _umount_all "$Z/temp"
                ;;
        esac
    done

    for LABEL_PATH in /sys/bus/iio/devices/iio:device*/in_temp_*_label; do
        [ -r "$LABEL_PATH" ] || continue
        LABEL=$(tr '[:upper:]-' '[:lower:]_' < "$LABEL_PATH" 2>/dev/null | tr -d '\r\n')
        case "$LABEL" in
            *usb_therm*|*svooc_mos_btb*)
                INPUT=${LABEL_PATH%_label}_input
                [ -e "$INPUT" ] && _umount_all "$INPUT"
                ;;
        esac
    done

    for INPUT in /sys/bus/iio/devices/iio:device*/in_temp_*usb*therm*_input \
                 /sys/bus/iio/devices/iio:device*/in_temp_*svooc_mos_btb*_input; do
        [ -e "$INPUT" ] || continue
        NAME=$(printf '%s' "${INPUT##*/}" | tr '[:upper:]-' '[:lower:]_')
        case "$NAME" in
            *usb_therm*|*svooc_mos_btb*) _umount_all "$INPUT" ;;
        esac
    done
}

_pid_alive() {
    local p expected cmd
    [ -s "$1" ] || return 1
    expected="$2"
    p=$(cat "$1" 2>/dev/null | _trim_pid)
    case "$p" in
        ''|*[!0-9]*) rm -f "$1" 2>/dev/null; return 1 ;;
    esac
    if kill -0 "$p" 2>/dev/null && [ -r "/proc/$p/cmdline" ]; then
        cmd=$(tr '\0' ' ' < "/proc/$p/cmdline" 2>/dev/null)
        case "$cmd" in
            *"$BIN"*)
                if [ -z "$expected" ]; then
                    return 0
                fi
                case "$cmd" in *"$expected"*) return 0 ;; esac
                ;;
        esac
    fi
    rm -f "$1" 2>/dev/null
    return 1
}

_pid_value() {
    cat "$1" 2>/dev/null | _trim_pid
}

_load_kcompat() {
    local state output rc
    if ! _wait_opbatt_stable; then
        _log "内核兼容层等待 opbatt 稳定失败，跳过本次加载"
        return 1
    fi
    _diag_log "开始调用管理器无关内核兼容层加载器"
    output=$("$BIN" --load-kcompat --moddir "$MODDIR" 2>&1)
    rc=$?
    [ -n "$output" ] && printf '%s\n' "$output" >> "$LOG"
    _diag_log "loader_rc=$rc"
    if [ "$rc" -eq 0 ]; then
        output=$("$BIN" --kcompat-status --moddir "$MODDIR" 2>&1)
        rc=$?
        [ -n "$output" ] && printf '%s\n' "$output" >> "$LOG"
        _diag_log "status_rc=$rc status=${output:-unavailable}"
        _diag_snapshot "kcompat_load_success"
        _start_kcompat_diag_monitor
        case "$output" in
            *"backend=virtual_ic"*)
                _log "opbatt 原生 virtual_ic 后端已识别，等待主进程按启用类别完成覆盖"
                ;;
            *)
                _log "opbatt 内核兼容层已就绪"
                ;;
        esac
        return 0
    fi
    state=$(sed -n 's/^state=//p' "$CFGDIR/内核兼容状态.txt" 2>/dev/null | head -n 1)
    _diag_log "内核兼容层未启用 state=${state:-unavailable}"
    _diag_snapshot "kcompat_load_failed"
    _log "内核兼容层未启用: ${state:-unavailable}（旧接口继续按原逻辑运行）"
    return 1
}

_kcompat_loader_alive() {
    [ -s "$KCOMPAT_LOADER_PID" ] || return 1
    _loader_pid=$(cat "$KCOMPAT_LOADER_PID" 2>/dev/null)
    case "$_loader_pid" in
        ''|*[!0-9]*) rm -f "$KCOMPAT_LOADER_PID" 2>/dev/null; return 1 ;;
    esac
    if kill -0 "$_loader_pid" 2>/dev/null; then
        unset _loader_pid
        return 0
    fi
    rm -f "$KCOMPAT_LOADER_PID" 2>/dev/null
    unset _loader_pid
    return 1
}

_start_kcompat_loader_bg() {
    _kcompat_loader_alive && return 0
    rm -f "$KCOMPAT_LOADER_PID" 2>/dev/null
    (
        _load_kcompat
        # 加载任务是一次性的；不留下可误判为“仍在运行”的 PID 文件。
        rm -f "$KCOMPAT_LOADER_PID" 2>/dev/null
    ) &
    _loader_pid=$!
    printf '%s\n' "$_loader_pid" > "$KCOMPAT_LOADER_PID" 2>/dev/null
    _diag_log "内核兼容层加载任务已后台启动 pid=$_loader_pid"
    unset _loader_pid
}

MODULE_NAME=$(grep "^name=" "$MODDIR/module.prop" 2>/dev/null | cut -d= -f2)
[ -z "$MODULE_NAME" ] && MODULE_NAME="模块加载失败"

notify() {
    su 2000 -c "cmd notification post -S bigtext -t \"$1\" tempspoof_action \"$2\"" 2>/dev/null
    _log "通知发送: 标题=\"$1\", 内容=\"$2\""
}

if [ -f "$LOG" ] && [ "$(wc -c < "$LOG")" -gt 1048576 ]; then
    tail -c 65536 "$LOG" > "${LOG}.tmp"
    mv "${LOG}.tmp" "$LOG"
fi

touch "$LOG" 2>/dev/null
chmod 0755 "$BIN" 2>/dev/null

[ -x "$BIN" ] || { _log "致命: AaTempSpoof 不可执行"; exit 1; }

_sec "SERVICE"

_log "设备: $(getprop ro.product.model)"
_log "Android: $(getprop ro.build.version.release)"
_log "平台: $(getprop ro.board.platform)"
_diag_log "AaTempSpoof 内核伪装诊断启动"
_diag_snapshot "service_start"

rm -f "$STOP_FLAG" "$FLAGFILE"

WAIT=0
while [ "$WAIT" -lt 120 ]; do
    [ "$(getprop sys.boot_completed)" = "1" ] && break
    sleep 5
    WAIT=$((WAIT + 5))
done

_log "等待 sysfs 热管理节点就绪..."
SYSFS_WAIT=0
while [ "$SYSFS_WAIT" -lt 30 ]; do
    if [ -e "/sys/class/thermal/thermal_zone0/emul_temp" ] || \
       [ -e "/sys/class/oplus_chg/battery/temp" ] || \
       [ -e "/sys/class/power_supply/battery/temp" ]; then
        break
    fi
    sleep 2
    SYSFS_WAIT=$((SYSFS_WAIT + 2))
done

BATT_WAIT=0
while [ "$BATT_WAIT" -lt 20 ]; do
    _v=$(cat /sys/class/power_supply/battery/temp 2>/dev/null)
    case "${_v:-0}" in
        [1-9]*|[-][1-9]*) break ;;
    esac
    sleep 2
    BATT_WAIT=$((BATT_WAIT + 2))
done
unset _v

if [ -w "$GAUGE_PATH" ]; then
    printf '0\n' > "$GAUGE_PATH" 2>/dev/null
    _log "内核电池温度伪装节点已复位"
fi
_clear_kernel_virtual_gauge
_clear_kernel_usb_therm
[ -d "$VIRTUAL_IC_ROOT" ] && _log "内核电池底层伪装节点已复位"

_log "系统就绪 (boot=${WAIT}s sysfs=${SYSFS_WAIT}s batt=${BATT_WAIT}s)"
_diag_snapshot "system_ready"

CDMSFILE="$CFGDIR/cdms.txt"
(
    sleep 10
    if [ -f "$CDMSFILE" ] && [ "$(tr -d '[:space:]' < "$CDMSFILE" 2>/dev/null)" = "1" ]; then
        _log "cdms.txt=1，触发重置"
        printf '0' > "$CDMSFILE"
        sleep 1
        printf '1' > "$CDMSFILE"
        _log "cdms.txt 重触发完成"
    fi
) &

is_alive() {
    _pid_alive "$PIDFILE" --start
}

cb_alive() {
    _pid_alive "$CBPID" cb
}

touch_alive() {
    _pid_alive "$TOUCHPID" touch_daemon
}

tombstone_alive() {
    _pid_alive "$TOMBSTONEPID" color_tombstone
}

charge_alive() {
    _pid_alive "$CHARGEPID" charge_horae_daemon
}

start_daemon() {
    local i p try
    [ -x "$BIN" ] || { _log "AaTempSpoof 二进制不存在或不可执行"; return 1; }
    is_alive && { p=$(_pid_value "$PIDFILE"); _log "AaTempSpoof 已运行 PID=$p"; return 0; }

    rm -f "$PIDFILE"
    for try in 1 2 3; do
        _log "启动 AaTempSpoof (${try}/3)"
        "$BIN" --start --moddir "$MODDIR" >/dev/null 2>&1
        i=0
        while [ "$i" -lt 10 ]; do
            if is_alive; then
                touch "$FLAGFILE"
                p=$(_pid_value "$PIDFILE")
                _log "AaTempSpoof PID=$p"
                _start_kcompat_loader_bg
                return 0
            fi
            sleep 1
            i=$((i + 1))
        done
        _log "AaTempSpoof 第 ${try} 次启动后未确认到进程"
        sleep 2
    done
    _log "⚠ AaTempSpoof 未检测到"
    return 1
}

_start_bg() {
    local tool="$1"
    local pidfile="$2"
    local label="$3"
    local p try i

    [ -x "$BIN" ] || { _log "⚠ AaTempSpoof 不存在或不可执行，无法启动 $label"; return 0; }
    _pid_alive "$pidfile" "$tool" && { p=$(_pid_value "$pidfile"); _log "$label 已运行 PID=$p"; return 0; }

    rm -f "$pidfile"
    for try in 1 2 3; do
        _log "启动 $label (${try}/3)"
        "$BIN" "$tool" >/dev/null 2>&1 &
        p=$!
        i=0
        while [ "$i" -lt 8 ]; do
            if _pid_alive "$pidfile" "$tool"; then
                p=$(_pid_value "$pidfile")
                _log "$label PID=$p"
                return 0
            fi
            if [ "$i" -ge 2 ] && [ -n "$p" ] && kill -0 "$p" 2>/dev/null; then
                printf '%s\n' "$p" > "$pidfile" 2>/dev/null
                _log "$label PID=$p (shell)"
                return 0
            fi
            sleep 1
            i=$((i + 1))
        done
        _log "$label 第 ${try} 次启动后未确认到进程"
        sleep 2
    done
    _log "⚠ $label 未检测到"
    return 1
}

start_cb() {
    _start_bg cb "$CBPID" cb
}

start_touch() {
    _start_bg touch_daemon "$TOUCHPID" touch_daemon
}

start_tombstone() {
    _start_bg color_tombstone "$TOMBSTONEPID" color_tombstone
}

start_charge() {
    _start_bg charge_horae_daemon "$CHARGEPID" charge_horae_daemon
}

ensure_all() {
    local round ok
    _log "$1：检查所有功能进程"
    for round in 1 2 3; do
        ok=1
        is_alive        || { ok=0; start_daemon; }
        cb_alive        || { ok=0; start_cb; }
        touch_alive     || { ok=0; start_touch; }
        tombstone_alive || { ok=0; start_tombstone; }
        charge_alive    || { ok=0; start_charge; }
        [ "$ok" = "1" ] && { _log "$1：所有功能进程已确认"; return 0; }
        sleep 3
    done
    _log "$1：仍有功能进程未确认，等待后续 watchdog"
    return 1
}

_sec "守护进程启动"
ensure_all "首次启动"

(sleep 20
 [ -f "$STOP_FLAG" ] && exit 0
 ensure_all "20s 二次确认"
 if [ -s "$PIDFILE" ]; then
     read _p < "$PIDFILE"
     kill -HUP "$_p" 2>/dev/null
     _log "20s SIGHUP 已发送 (PID=$_p)"
 fi
) &

if [ -f "$PIDDIR/hw" ]; then
    _log "检测到 hw 标记，禁用 HW 叠加层"
    service call SurfaceFlinger 1008 i32 1 >/dev/null 2>&1
fi

_sec "启动完成"

if [ -f "$NOTIFY_FILE" ]; then
    (
        _log "开始发送初始化通知"
        notify "$MODULE_NAME" "模块初始化加载中，预计15s加载完成"
        sleep 15
        notify "$MODULE_NAME" "模块加载完成，温控伪装挂载等已生效"
    ) &
else
    _log "通知文件不存在，跳过通知发送"
fi

renice 10 $$ >/dev/null 2>&1

FAIL=0
WATCHDOG_TICKS=0
MAIN_WAS_ALIVE=1

while true; do
    sleep 2

    if is_alive; then
        MAIN_WAS_ALIVE=1
    elif [ "$MAIN_WAS_ALIVE" = "1" ]; then
        _diag_log "AaTempSpoof 主进程退出，开始清理内核兼容层"
        if [ -s "$KCOMPAT_LOADER_PID" ]; then
            _loader_pid=$(cat "$KCOMPAT_LOADER_PID" 2>/dev/null)
            case "$_loader_pid" in ''|*[!0-9]*) ;; *) kill "$_loader_pid" 2>/dev/null ;; esac
            rm -f "$KCOMPAT_LOADER_PID" 2>/dev/null
            unset _loader_pid
        fi
        if [ -s "$KCOMPAT_DIAG_PID" ]; then
            _diag_pid=$(cat "$KCOMPAT_DIAG_PID" 2>/dev/null)
            case "$_diag_pid" in ''|*[!0-9]*) ;; *) kill "$_diag_pid" 2>/dev/null ;; esac
            rm -f "$KCOMPAT_DIAG_PID" 2>/dev/null
            unset _diag_pid
        fi
        "$BIN" --unload-kcompat --moddir "$MODDIR" >/dev/null 2>&1 || true
        [ -w "$GAUGE_PATH" ] && printf '0\n' > "$GAUGE_PATH" 2>/dev/null
        _clear_kernel_virtual_gauge
        _clear_kernel_usb_therm
        MAIN_WAS_ALIVE=0
        _diag_snapshot "main_exit_cleanup"
        _log "⚠ AaTempSpoof 异常退出，内核温度伪装已复位"
    fi

    WATCHDOG_TICKS=$((WATCHDOG_TICKS + 1))
    [ "$WATCHDOG_TICKS" -lt 60 ] && continue
    WATCHDOG_TICKS=0

    [ -f "$STOP_FLAG" ] && continue

    if ! is_alive; then
        FAIL=$((FAIL + 1))
        _diag_log "watchdog 检测到 AaTempSpoof 死亡 count=$FAIL"
        _log "⚠ AaTempSpoof 死亡 ($FAIL/5)"
        _clear_kernel_virtual_gauge
        _clear_kernel_usb_therm
        rm -f "$PIDFILE"
        start_daemon && FAIL=0
    else
        FAIL=0
    fi

    if ! cb_alive; then
        _log "⚠ cb 死亡"
        rm -f "$CBPID"
        start_cb
    fi

    if ! touch_alive; then
        _log "⚠ touch_daemon 死亡"
        rm -f "$TOUCHPID"
        start_touch
    fi

    if ! tombstone_alive; then
        _log "⚠ color_tombstone 死亡"
        rm -f "$TOMBSTONEPID"
        start_tombstone
    fi

    if ! charge_alive; then
        _log "⚠ charge_horae_daemon 死亡"
        rm -f "$CHARGEPID"
        start_charge
    fi

    if [ "$FAIL" -gt 5 ]; then
        _log "✗ AaTempSpoof 连续重启失败，延长等待后继续监控"
        sleep 300
        FAIL=0
    fi
done
