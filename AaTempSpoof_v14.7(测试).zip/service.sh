#!/system/bin/sh

MODDIR="${0%/*}"
BIN="$MODDIR/bin/AaTempSpoof"
GAUGE_PATH="/sys/module/oplus_chg_v2/parameters/gauge_dbg_tbat"
VIRTUAL_IC_ROOT="/sys/class/virtual_ic"

CFGDIR="$MODDIR/bin/config/AaTempSpoof"
PIDDIR="$MODDIR/pid"
LOG="$CFGDIR/tempspoof.log"

mkdir -p "$CFGDIR" "$PIDDIR"

PIDFILE="$PIDDIR/daemon.pid"
CBPID="$PIDDIR/cb.pid"
TOUCHPID="$PIDDIR/touch_daemon.pid"
TOMBSTONEPID="$PIDDIR/color_tombstone.pid"
CHARGEPID="$PIDDIR/charge_horae_daemon.pid"
NOTIFY_FILE="$PIDDIR/通知"

FLAGFILE="$PIDDIR/fake_batt_temp"
STOP_FLAG="$CFGDIR/user_stopped"
APP_PACKAGE="com.aatempspoof.tile"
APP_SERVICE="$APP_PACKAGE/.ChargingLiveService"
APP_PREF="/data/user/0/$APP_PACKAGE/shared_prefs/charging_live.xml"
APP_APK="$MODDIR/bin/apk/AaTempSpoof.apk"
APP_DUAL_CELL_CONFIG="$CFGDIR/充电统计双电.txt"
APP_DUAL_CELL_RUNTIME="/dev/aatempspoof/charge_dual_cell"
APP_HANS_PIDFILE="$PIDDIR/app_hans_guard.pid"
APP_HANS_READY="$PIDDIR/app_hans_guard.ready"

_log() {
    printf '[%s] [service] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOG"
}

_sec() {
    local _ts
    _ts=$(date '+%Y-%m-%d %H:%M:%S')
    printf '\n' >> "$LOG"
    printf '[%s] [service] ┌─────────────────────────────────────┐\n' "$_ts" >> "$LOG"
    printf '[%s] [service] │  %-35s│\n' "$_ts" "$1" >> "$LOG"
    printf '[%s] [service] └─────────────────────────────────────┘\n' "$_ts" >> "$LOG"
}

_trim_pid() {
    tr -d ' \r\n' 2>/dev/null
}

_umount_all() {
    local I
    [ -n "$1" ] || return
    I=0
    while [ "$I" -lt 8 ]; do
        umount -l "$1" >/dev/null 2>&1 || break
        I=$((I + 1))
    done
}

_clear_kernel_virtual_gauge() {
    local D NAME FUNCS FUNC OLD
    for D in "$VIRTUAL_IC_ROOT"/vic-*; do
        [ -r "$D/name" ] || continue
        NAME=$(tr -d '\r\n' < "$D/name" 2>/dev/null)
        case "$NAME" in
            oplus,virtual_gauge) FUNCS="405" ;;
            oplus,adsp_gauge) FUNCS="448" ;;
            oplus,virtual_buck) FUNCS="510 528" ;;
            oplus,pm8550_charger) FUNCS="510" ;;
            oplus,adsp_mos|oplus,ufcs_virtual_cp) FUNCS="315" ;;
            *) continue ;;
        esac
        [ -w "$D/func_id" ] && [ -w "$D/clean_overwrite" ] || continue
        OLD=$(tr -d ' \r\n' < "$D/func_id" 2>/dev/null)
        case "$OLD" in ''|*[!0-9-]*) continue ;; esac
        for FUNC in $FUNCS; do
            printf '%s\n' "$FUNC" > "$D/func_id" 2>/dev/null || continue
            printf '1\n' > "$D/clean_overwrite" 2>/dev/null
        done
        printf '%s\n' "$OLD" > "$D/func_id" 2>/dev/null
    done
}

_clear_kernel_usb_therm() {
    local Z TYPE LABEL_PATH LABEL INPUT NAME
    for Z in /sys/class/thermal/thermal_zone*; do
        [ -r "$Z/type" ] || continue
        TYPE=$(tr '[:upper:]-' '[:lower:]_' < "$Z/type" 2>/dev/null | tr -d '\r\n')
        case "$TYPE" in
            usb|*usb_therm*|*svooc_mos_btb*)
                [ -w "$Z/emul_temp" ] && printf '0\n' > "$Z/emul_temp" 2>/dev/null
                _umount_all "$Z/temp"
                ;;
        esac
    done

    for LABEL_PATH in /sys/bus/iio/devices/iio:device*/in_temp_*_label; do
        [ -r "$LABEL_PATH" ] || continue
        LABEL=$(tr '[:upper:]-' '[:lower:]_' < "$LABEL_PATH" 2>/dev/null | tr -d '\r\n')
        case "$LABEL" in
            *usb_therm*|*svooc_mos_btb*)
                INPUT=${LABEL_PATH%_label}_input
                [ -e "$INPUT" ] && _umount_all "$INPUT"
                ;;
        esac
    done

    for INPUT in /sys/bus/iio/devices/iio:device*/in_temp_*usb*therm*_input \
                 /sys/bus/iio/devices/iio:device*/in_temp_*svooc_mos_btb*_input; do
        [ -e "$INPUT" ] || continue
        NAME=$(printf '%s' "${INPUT##*/}" | tr '[:upper:]-' '[:lower:]_')
        case "$NAME" in
            *usb_therm*|*svooc_mos_btb*) _umount_all "$INPUT" ;;
        esac
    done
}

_pid_alive() {
    local p expected cmd
    [ -s "$1" ] || return 1
    expected="$2"
    p=$(cat "$1" 2>/dev/null | _trim_pid)
    case "$p" in
        ''|*[!0-9]*) rm -f "$1" 2>/dev/null; return 1 ;;
    esac
    if kill -0 "$p" 2>/dev/null && [ -r "/proc/$p/cmdline" ]; then
        cmd=$(tr '\0' ' ' < "/proc/$p/cmdline" 2>/dev/null)
        case "$cmd" in
            *"$BIN"*)
                if [ -z "$expected" ]; then
                    return 0
                fi
                case "$cmd" in *"$expected"*) return 0 ;; esac
                ;;
        esac
    fi
    rm -f "$1" 2>/dev/null
    return 1
}

_pid_value() {
    cat "$1" 2>/dev/null | _trim_pid
}

MODULE_NAME=$(grep "^name=" "$MODDIR/module.prop" 2>/dev/null | cut -d= -f2)
[ -z "$MODULE_NAME" ] && MODULE_NAME="模块加载失败"

notify() {
    su 2000 -c "cmd notification post -S bigtext -t \"$1\" tempspoof_action \"$2\"" 2>/dev/null
    _log "通知发送: 标题=\"$1\", 内容=\"$2\""
}

if [ -f "$LOG" ] && [ "$(wc -c < "$LOG")" -gt 1048576 ]; then
    tail -c 65536 "$LOG" > "${LOG}.tmp"
    mv "${LOG}.tmp" "$LOG"
fi

touch "$LOG" 2>/dev/null
chmod 0755 "$BIN" 2>/dev/null

[ -x "$BIN" ] || { _log "致命: AaTempSpoof 不可执行"; exit 1; }

_sec "SERVICE"

_log "设备: $(getprop ro.product.model)"
_log "Android: $(getprop ro.build.version.release)"
_log "平台: $(getprop ro.board.platform)"

rm -f "$STOP_FLAG" "$FLAGFILE"

WAIT=0
while [ "$WAIT" -lt 120 ]; do
    [ "$(getprop sys.boot_completed)" = "1" ] && break
    sleep 5
    WAIT=$((WAIT + 5))
done

_log "等待 sysfs 热管理节点就绪..."
SYSFS_WAIT=0
while [ "$SYSFS_WAIT" -lt 30 ]; do
    if [ -e "/sys/class/thermal/thermal_zone0/emul_temp" ] || \
       [ -e "/sys/class/oplus_chg/battery/temp" ] || \
       [ -e "/sys/class/power_supply/battery/temp" ]; then
        break
    fi
    sleep 2
    SYSFS_WAIT=$((SYSFS_WAIT + 2))
done

BATT_WAIT=0
while [ "$BATT_WAIT" -lt 20 ]; do
    _v=$(cat /sys/class/power_supply/battery/temp 2>/dev/null)
    case "${_v:-0}" in
        [1-9]*|[-][1-9]*) break ;;
    esac
    sleep 2
    BATT_WAIT=$((BATT_WAIT + 2))
done
unset _v

if [ -w "$GAUGE_PATH" ]; then
    printf '0\n' > "$GAUGE_PATH" 2>/dev/null
    _log "内核电池温度伪装节点已复位"
fi
_clear_kernel_virtual_gauge
_clear_kernel_usb_therm
[ -d "$VIRTUAL_IC_ROOT" ] && _log "内核电池底层伪装节点已复位"

_log "系统就绪 (boot=${WAIT}s sysfs=${SYSFS_WAIT}s batt=${BATT_WAIT}s)"

CDMSFILE="$CFGDIR/cdms.txt"
(
    sleep 10
    if [ -f "$CDMSFILE" ] && [ "$(tr -d '[:space:]' < "$CDMSFILE" 2>/dev/null)" = "1" ]; then
        _log "cdms.txt=1，触发重置"
        printf '0' > "$CDMSFILE"
        sleep 1
        printf '1' > "$CDMSFILE"
        _log "cdms.txt 重触发完成"
    fi
) &

is_alive() {
    _pid_alive "$PIDFILE" --start
}

cb_alive() {
    _pid_alive "$CBPID" cb
}

touch_alive() {
    _pid_alive "$TOUCHPID" touch_daemon
}

tombstone_alive() {
    _pid_alive "$TOMBSTONEPID" color_tombstone
}

charge_alive() {
    _pid_alive "$CHARGEPID" charge_horae_daemon
}

app_user_ready() {
    local state
    state=$(getprop sys.user.0.ce_available 2>/dev/null | tr -d ' \r\n')
    case "$state" in
        true|1) return 0 ;;
        false|0) return 1 ;;
    esac
    dumpsys user 2>/dev/null \
        | grep -q 'Started users state:.*0=RUNNING_UNLOCKED'
}

app_device_charging() {
    local supply online type status
    for supply in /sys/class/power_supply/*; do
        [ -r "$supply/online" ] || continue
        online=$(tr -d ' \r\n' < "$supply/online" 2>/dev/null)
        [ "$online" = "1" ] || continue
        type=$(tr -d '\r\n' < "$supply/type" 2>/dev/null)
        case "$type" in
            Battery|BMS) ;;
            *) return 0 ;;
        esac
    done
    status=$(tr -d '\r\n' < /sys/class/power_supply/battery/status 2>/dev/null)
    case "$status" in
        Charging|Full) return 0 ;;
        *) return 1 ;;
    esac
}

app_live_enabled() {
    [ -r "$APP_PREF" ] || return 0
    grep -q 'name="enabled"[[:space:]]*value="false"' "$APP_PREF" 2>/dev/null \
        && return 1
    return 0
}

app_process_alive() {
    pidof "$APP_PACKAGE" >/dev/null 2>&1
}

app_service_alive() {
    app_process_alive || return 1
    dumpsys activity services "$APP_SERVICE" 2>/dev/null \
        | grep -Fq "$APP_SERVICE"
}

sync_charge_dual_cell() {
    local value current
    value=$(tr -d ' \r\n' < "$APP_DUAL_CELL_CONFIG" 2>/dev/null)
    [ "$value" = "1" ] || value=0
    mkdir -p "${APP_DUAL_CELL_RUNTIME%/*}" 2>/dev/null || return
    current=$(tr -d ' \r\n' < "$APP_DUAL_CELL_RUNTIME" 2>/dev/null)
    if [ "$current" != "$value" ]; then
        printf '%s\n' "$value" > "$APP_DUAL_CELL_RUNTIME" 2>/dev/null || return
        chmod 0644 "$APP_DUAL_CELL_RUNTIME" 2>/dev/null || true
    fi
}

app_hans_guard_alive() {
    local pid cmdline
    [ -s "$APP_HANS_PIDFILE" ] || return 1
    read pid < "$APP_HANS_PIDFILE"
    case "$pid" in ''|*[!0-9]*) return 1 ;; esac
    kill -0 "$pid" 2>/dev/null || return 1
    cmdline=$(tr '\000' ' ' < "/proc/$pid/cmdline" 2>/dev/null)
    printf '%s\n' "$cmdline" | grep -Fq 'com.aatempspoof.tile.RootHansGuard'
}

stop_app_hans_guard() {
    local pid
    if app_hans_guard_alive; then
        read pid < "$APP_HANS_PIDFILE"
        kill "$pid" 2>/dev/null || true
    fi
    rm -f "$APP_HANS_PIDFILE" "$APP_HANS_READY"
}

start_app_hans_guard() {
    local uid pid status wait_count
    app_hans_guard_alive && return 0
    [ "$APP_HANS_RETRY_BACKOFF" -le 0 ] || {
        APP_HANS_RETRY_BACKOFF=$((APP_HANS_RETRY_BACKOFF - 1))
        return 1
    }
    /system/bin/service check oplus_freeze 2>/dev/null \
        | grep -q 'found' || return 0
    [ -r "$APP_APK" ] || return 1

    uid=$(stat -c '%u' "/data/user/0/$APP_PACKAGE" 2>/dev/null)
    case "$uid" in ''|*[!0-9]*) return 1 ;; esac
    rm -f "$APP_HANS_PIDFILE" "$APP_HANS_READY"
    CLASSPATH="$APP_APK" /system/bin/app_process /system/bin \
        com.aatempspoof.tile.RootHansGuard \
        "$uid" "$APP_PACKAGE" "$APP_HANS_READY" >> "$LOG" 2>&1 &
    pid=$!
    printf '%s\n' "$pid" > "$APP_HANS_PIDFILE"
    wait_count=0
    status=
    while [ "$wait_count" -lt 4 ]; do
        status=$(tr -d ' \r\n' < "$APP_HANS_READY" 2>/dev/null)
        [ -n "$status" ] && break
        kill -0 "$pid" 2>/dev/null || break
        wait_count=$((wait_count + 1))
        sleep 1
    done
    if [ "$status" = "1" ] && app_hans_guard_alive; then
        _log "Oplus Hans 充电后台保护已启用 (PID=$pid)"
        APP_HANS_RETRY_BACKOFF=0
        return 0
    fi
    stop_app_hans_guard
    APP_HANS_RETRY_BACKOFF=15
    _log "⚠ Oplus Hans 充电后台保护启动失败 (${status:-无回调})"
    return 1
}

app_package_can_restart() {
    local package_state sdk
    pm path "$APP_PACKAGE" >/dev/null 2>&1 || return 1
    package_state=$(dumpsys package "$APP_PACKAGE" 2>/dev/null)
    printf '%s\n' "$package_state" \
        | grep -q 'User 0:.*stopped=true' && return 1

    sdk=$(getprop ro.build.version.sdk 2>/dev/null | tr -d ' \r\n')
    case "$sdk" in ''|*[!0-9]*) sdk=0 ;; esac
    if [ "$sdk" -ge 33 ]; then
        printf '%s\n' "$package_state" \
            | grep -q 'android.permission.POST_NOTIFICATIONS: granted=true' \
            || return 1
    fi
    return 0
}

ensure_charging_app() {
    app_user_ready || return
    if ! app_device_charging || ! app_live_enabled; then
        if [ "$APP_GUARD_ACTIVE" != "0" ]; then
            /system/bin/am stopservice --user 0 \
                -n "$APP_SERVICE" >/dev/null 2>&1
        fi
        stop_app_hans_guard
        APP_GUARD_ACTIVE=0
        APP_RESTART_BACKOFF=0
        return
    fi
    APP_GUARD_ACTIVE=1
    if app_service_alive; then
        APP_RESTART_BACKOFF=0
    else
        if [ "$APP_RESTART_BACKOFF" -gt 0 ]; then
            APP_RESTART_BACKOFF=$((APP_RESTART_BACKOFF - 1))
        elif ! app_package_can_restart; then
            APP_RESTART_BACKOFF=1
        elif /system/bin/am start-foreground-service --user 0 \
                -n "$APP_SERVICE" >/dev/null 2>&1; then
            _log "充电流体云应用进程缺失，已静默拉起"
            APP_RESTART_BACKOFF=0
        else
            _log "⚠ 充电流体云应用静默拉起失败，下一轮重试"
            APP_RESTART_BACKOFF=1
        fi
    fi
    start_app_hans_guard || true
}

publish_real_temp_node() {
    (
        local i
        i=0
        while [ "$i" -lt 15 ]; do
            if [ -d /dev/aatempspoof ]; then
                chmod 0711 /dev/aatempspoof 2>/dev/null
                chcon u:object_r:system_file:s0 /dev/aatempspoof 2>/dev/null || true
            fi
            if [ -f /dev/aatempspoof/real_batt_temp ]; then
                chmod 0644 /dev/aatempspoof/real_batt_temp 2>/dev/null
                chcon u:object_r:system_file:s0 \
                    /dev/aatempspoof/real_batt_temp 2>/dev/null || true
                return 0
            fi
            sleep 1
            i=$((i + 1))
        done
    ) &
}

start_daemon() {
    local i p try
    [ -x "$BIN" ] || { _log "AaTempSpoof 二进制不存在或不可执行"; return 1; }
    is_alive && {
        p=$(_pid_value "$PIDFILE")
        _log "AaTempSpoof 已运行 PID=$p"
        publish_real_temp_node
        return 0
    }

    rm -f "$PIDFILE"
    for try in 1 2 3; do
        _log "启动 AaTempSpoof (${try}/3)"
        "$BIN" --start --moddir "$MODDIR" >/dev/null 2>&1
        i=0
        while [ "$i" -lt 10 ]; do
            if is_alive; then
                touch "$FLAGFILE"
                p=$(_pid_value "$PIDFILE")
                _log "AaTempSpoof PID=$p"
                publish_real_temp_node
                return 0
            fi
            sleep 1
            i=$((i + 1))
        done
        _log "AaTempSpoof 第 ${try} 次启动后未确认到进程"
        sleep 2
    done
    _log "⚠ AaTempSpoof 未检测到"
    return 1
}

_start_bg() {
    local tool="$1"
    local pidfile="$2"
    local label="$3"
    local p try i

    [ -x "$BIN" ] || { _log "⚠ AaTempSpoof 不存在或不可执行，无法启动 $label"; return 0; }
    _pid_alive "$pidfile" "$tool" && { p=$(_pid_value "$pidfile"); _log "$label 已运行 PID=$p"; return 0; }

    rm -f "$pidfile"
    for try in 1 2 3; do
        _log "启动 $label (${try}/3)"
        "$BIN" "$tool" >/dev/null 2>&1 &
        p=$!
        i=0
        while [ "$i" -lt 8 ]; do
            if _pid_alive "$pidfile" "$tool"; then
                p=$(_pid_value "$pidfile")
                _log "$label PID=$p"
                return 0
            fi
            if [ "$i" -ge 2 ] && [ -n "$p" ] && kill -0 "$p" 2>/dev/null; then
                printf '%s\n' "$p" > "$pidfile" 2>/dev/null
                _log "$label PID=$p (shell)"
                return 0
            fi
            sleep 1
            i=$((i + 1))
        done
        _log "$label 第 ${try} 次启动后未确认到进程"
        sleep 2
    done
    _log "⚠ $label 未检测到"
    return 1
}

start_cb() {
    _start_bg cb "$CBPID" cb
}

start_touch() {
    _start_bg touch_daemon "$TOUCHPID" touch_daemon
}

start_tombstone() {
    _start_bg color_tombstone "$TOMBSTONEPID" color_tombstone
}

start_charge() {
    _start_bg charge_horae_daemon "$CHARGEPID" charge_horae_daemon
}

ensure_all() {
    local round ok
    _log "$1：检查所有功能进程"
    for round in 1 2 3; do
        ok=1
        is_alive        || { ok=0; start_daemon; }
        cb_alive        || { ok=0; start_cb; }
        touch_alive     || { ok=0; start_touch; }
        tombstone_alive || { ok=0; start_tombstone; }
        charge_alive    || { ok=0; start_charge; }
        [ "$ok" = "1" ] && { _log "$1：所有功能进程已确认"; return 0; }
        sleep 3
    done
    _log "$1：仍有功能进程未确认，等待后续 watchdog"
    return 1
}

_sec "守护进程启动"
sync_charge_dual_cell
ensure_all "首次启动"

(sleep 20
 [ -f "$STOP_FLAG" ] && exit 0
 ensure_all "20s 二次确认"
 if [ -s "$PIDFILE" ]; then
     read _p < "$PIDFILE"
     kill -HUP "$_p" 2>/dev/null
     _log "20s SIGHUP 已发送 (PID=$_p)"
 fi
) &

if [ -f "$PIDDIR/hw" ]; then
    _log "检测到 hw 标记，禁用 HW 叠加层"
    service call SurfaceFlinger 1008 i32 1 >/dev/null 2>&1
fi

_sec "启动完成"

if [ -f "$NOTIFY_FILE" ]; then
    (
        _log "开始发送初始化通知"
        notify "$MODULE_NAME" "模块初始化加载中，预计15s加载完成"
        sleep 15
        notify "$MODULE_NAME" "模块加载完成，温控伪装挂载等已生效"
    ) &
else
    _log "通知文件不存在，跳过通知发送"
fi

renice 10 $$ >/dev/null 2>&1

FAIL=0
WATCHDOG_TICKS=0
MAIN_WAS_ALIVE=1
APP_GUARD_ACTIVE=
APP_RESTART_BACKOFF=0
APP_HANS_RETRY_BACKOFF=0

while true; do
    sleep 2

    sync_charge_dual_cell
    ensure_charging_app

    if is_alive; then
        MAIN_WAS_ALIVE=1
    elif [ "$MAIN_WAS_ALIVE" = "1" ]; then
        [ -w "$GAUGE_PATH" ] && printf '0\n' > "$GAUGE_PATH" 2>/dev/null
        _clear_kernel_virtual_gauge
        _clear_kernel_usb_therm
        MAIN_WAS_ALIVE=0
        _log "⚠ AaTempSpoof 异常退出，内核温度伪装已复位"
    fi

    WATCHDOG_TICKS=$((WATCHDOG_TICKS + 1))
    [ "$WATCHDOG_TICKS" -lt 60 ] && continue
    WATCHDOG_TICKS=0

    [ -f "$STOP_FLAG" ] && continue

    if ! is_alive; then
        FAIL=$((FAIL + 1))
        _log "⚠ AaTempSpoof 死亡 ($FAIL/5)"
        _clear_kernel_virtual_gauge
        _clear_kernel_usb_therm
        rm -f "$PIDFILE"
        start_daemon && FAIL=0
    else
        FAIL=0
    fi

    if ! cb_alive; then
        _log "⚠ cb 死亡"
        rm -f "$CBPID"
        start_cb
    fi

    if ! touch_alive; then
        _log "⚠ touch_daemon 死亡"
        rm -f "$TOUCHPID"
        start_touch
    fi

    if ! tombstone_alive; then
        _log "⚠ color_tombstone 死亡"
        rm -f "$TOMBSTONEPID"
        start_tombstone
    fi

    if ! charge_alive; then
        _log "⚠ charge_horae_daemon 死亡"
        rm -f "$CHARGEPID"
        start_charge
    fi

    if [ "$FAIL" -gt 5 ]; then
        _log "✗ AaTempSpoof 连续重启失败，延长等待后继续监控"
        sleep 300
        FAIL=0
    fi
done
