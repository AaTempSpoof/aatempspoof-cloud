#!/system/bin/sh

MODULE_DIR="/data/adb/modules/AAaTempSpoof"
MODULE_UPDATE_DIR="/data/adb/modules_update/AAaTempSpoof"
# Never derive deletion targets from $0: this script may be copied and run elsewhere.
MODDIR="$MODULE_DIR"

DATA_DIR="$MODULE_DIR/bin/config/AaTempSpoof"
PID_DIR="$MODULE_DIR/pid"
BATT_SYS="/sys/class/power_supply/battery"
BIN="$MODULE_DIR/bin/AaTempSpoof"

[ -d "$MODDIR/bin/config/AaTempSpoof" ] && DATA_DIR="$MODDIR/bin/config/AaTempSpoof"
[ -d "$MODDIR/pid" ] && PID_DIR="$MODDIR/pid"
[ -x "$MODDIR/bin/AaTempSpoof" ] && BIN="$MODDIR/bin/AaTempSpoof"

_write() {
    [ -w "$1" ] && printf '%s\n' "$2" > "$1" 2>/dev/null
}

_find_opbatt_target() {
    local target
    for target in \
        /vendor_dlkm/lib/modules/oplus_chg_v2.ko \
        /vendor/lib/modules/oplus_chg_v2.ko \
        /odm_dlkm/lib/modules/oplus_chg_v2.ko \
        /system/lib/modules/oplus_chg_v2.ko \
        /system_dlkm/lib/modules/oplus_chg_v2.ko; do
        [ -f "$target" ] && { printf '%s\n' "$target"; return 0; }
    done
    return 1
}

_native_virtual_ic_profile() {
    local target sha manifest
    target=$(_find_opbatt_target) || return 1
    sha=$(sha256sum "$target" 2>/dev/null | awk '{print $1}')
    [ -n "$sha" ] || return 1
    manifest="$MODDIR/bin/kcompat/manifest.tsv"
    [ -r "$manifest" ] || return 1
    awk -F '\t' -v expected="$sha" '
        $1 !~ /^#/ && NF == 8 && $4 == expected &&
        $5 == "-" && $6 == "*" && $7 == "virtual_ic" && $8 == "-" {
            found = 1
        }
        END { exit found ? 0 : 1 }
    ' "$manifest" >/dev/null 2>&1
}

_clear_kernel_virtual_gauge() {
    local D NAME FUNCS FUNC OLD SELECTED NATIVE
    FUNCS=""
    NATIVE=0
    if _native_virtual_ic_profile; then
        FUNCS="405 448 509 510 527 528 532 315"
        NATIVE=1
    fi
    for D in /sys/class/virtual_ic/vic-*; do
        [ -w "$D/func_id" ] && [ -w "$D/clean_overwrite" ] || continue
        if [ "$NATIVE" -eq 0 ]; then
            [ -r "$D/name" ] || continue
            NAME=$(tr -d '\r\n' < "$D/name" 2>/dev/null)
            case "$NAME" in
                oplus,virtual_gauge) FUNCS="405" ;;
                oplus,adsp_gauge) FUNCS="448" ;;
                oplus,virtual_buck) FUNCS="510 528" ;;
                oplus,pm8550_charger) FUNCS="510" ;;
                oplus,adsp_mos|oplus,ufcs_virtual_cp) FUNCS="315" ;;
                *) continue ;;
            esac
        fi
        OLD=$(tr -d ' \r\n' < "$D/func_id" 2>/dev/null)
        case "$OLD" in ''|*[!0-9-]*) continue ;; esac
        for FUNC in $FUNCS; do
            printf '%s\n' "$FUNC" > "$D/func_id" 2>/dev/null || continue
            SELECTED=$(tr -d ' \r\n' < "$D/func_id" 2>/dev/null)
            [ "$SELECTED" = "$FUNC" ] || continue
            printf '1\n' > "$D/clean_overwrite" 2>/dev/null
        done
        printf '%s\n' "$OLD" > "$D/func_id" 2>/dev/null
        if [ "$(tr -d ' \r\n' < "$D/func_id" 2>/dev/null)" != "$OLD" ]; then
            printf '%s\n' "$OLD" > "$D/func_id" 2>/dev/null
        fi
    done
}

_chmod_rw() {
    [ -e "$1" ] && chmod 0644 "$1" 2>/dev/null
}

_umount_all() {
    local I
    [ -n "$1" ] || return
    I=0
    while [ "$I" -lt 8 ]; do
        umount -l "$1" >/dev/null 2>&1 || break
        I=$((I + 1))
    done
}

_clear_kernel_usb_therm() {
    local Z TYPE LABEL_PATH LABEL INPUT NAME
    for Z in /sys/class/thermal/thermal_zone*; do
        [ -r "$Z/type" ] || continue
        TYPE=$(tr '[:upper:]-' '[:lower:]_' < "$Z/type" 2>/dev/null | tr -d '\r\n')
        case "$TYPE" in
            usb|*usb_therm*|*svooc_mos_btb*)
                [ -w "$Z/emul_temp" ] && printf '0\n' > "$Z/emul_temp" 2>/dev/null
                _umount_all "$Z/temp"
                ;;
        esac
    done

    for LABEL_PATH in /sys/bus/iio/devices/iio:device*/in_temp_*_label; do
        [ -r "$LABEL_PATH" ] || continue
        LABEL=$(tr '[:upper:]-' '[:lower:]_' < "$LABEL_PATH" 2>/dev/null | tr -d '\r\n')
        case "$LABEL" in
            *usb_therm*|*svooc_mos_btb*)
                INPUT=${LABEL_PATH%_label}_input
                [ -e "$INPUT" ] && _umount_all "$INPUT"
                ;;
        esac
    done

    for INPUT in /sys/bus/iio/devices/iio:device*/in_temp_*usb*therm*_input \
                 /sys/bus/iio/devices/iio:device*/in_temp_*svooc_mos_btb*_input; do
        [ -e "$INPUT" ] || continue
        NAME=$(printf '%s' "${INPUT##*/}" | tr '[:upper:]-' '[:lower:]_')
        case "$NAME" in
            *usb_therm*|*svooc_mos_btb*) _umount_all "$INPUT" ;;
        esac
    done
}

_clear_real_batt_temp() {
    local SOURCE_FILE SOURCE ALIAS_FILE ALIAS
    SOURCE_FILE="$DATA_DIR/charge_stats/real_temp_source"
    ALIAS_FILE="$DATA_DIR/charge_stats/real_temp_alias"
    _umount_all /dev/aatempspoof/.real_batt_temp_source
    while IFS= read -r SOURCE; do
        SOURCE=$(printf '%s' "$SOURCE" | tr -d '\r')
        case "$SOURCE" in
            /sys/bus/iio/devices/iio:device*/in_temp_*_input|\
            /sys/*/iio:device*/in_temp_*_input)
                _umount_all "$SOURCE"
                ;;
        esac
    done < "$SOURCE_FILE" 2>/dev/null
    while IFS= read -r ALIAS; do
        ALIAS=$(printf '%s' "$ALIAS" | tr -d '\r')
        case "$ALIAS" in
            /dev/aatempspoof/.real_batt_temp_source|\
            /sys/class/thermal/thermal_zone*/temp)
                _umount_all "$ALIAS"
                ;;
        esac
    done < "$ALIAS_FILE" 2>/dev/null
    rm -rf /dev/aatempspoof 2>/dev/null
}

_setprop() {
    setprop "$1" "$2" 2>/dev/null
    command -v resetprop >/dev/null 2>&1 && resetprop "$1" "$2" >/dev/null 2>&1
}

_delprop() {
    command -v resetprop >/dev/null 2>&1 || return
    resetprop -p -d "$1" >/dev/null 2>&1
    resetprop -d "$1" >/dev/null 2>&1
}

_kill_pid() {
    local PID CMD
    PID=$(cat "$1" 2>/dev/null | tr -d ' \r\n')
    case "$PID" in ''|*[!0-9]*) return ;; esac
    [ "$PID" = "$$" ] && return
    [ -r "/proc/$PID/cmdline" ] || return
    CMD=$(tr '\0' ' ' < "/proc/$PID/cmdline" 2>/dev/null)
    case "$CMD" in
        *"$MODULE_DIR/bin/"*|*"$MODDIR/bin/"*|*"$MODULE_DIR/service.sh"*|*"$MODDIR/service.sh"*) ;;
        *) return ;;
    esac
    kill "$PID" 2>/dev/null
    sleep 0.2
    kill -0 "$PID" 2>/dev/null && kill -9 "$PID" 2>/dev/null
}

_kill_pattern() {
    local P PAT="$1"
    [ -z "$PAT" ] && return
    for P in $(pgrep -f "$PAT" 2>/dev/null); do
        [ "$P" = "$$" ] && continue
        kill "$P" 2>/dev/null
        sleep 0.1
        kill -0 "$P" 2>/dev/null && kill -9 "$P" 2>/dev/null
    done
}

_kill_module_bins() {
    local PAT
    for PAT in "$MODULE_DIR/bin/" "$MODDIR/bin/"; do
        [ -n "$PAT" ] && _kill_pattern "$PAT"
    done
}

_umount_module_mounts() {
    local M
    [ -r /proc/self/mountinfo ] || return
    for M in "$MODULE_DIR" "$MODDIR"; do
        [ -z "$M" ] && continue
        awk -v mod="$M" '$0 ~ mod {print $5}' /proc/self/mountinfo 2>/dev/null
    done | sort -ru | while IFS= read -r MP; do
        [ -n "$MP" ] && _umount_all "$MP"
    done
}

_umount_overlay_map() {
    local MAP="$1" MP
    [ -f "$MAP" ] || return
    while IFS= read -r MP; do
        [ -n "$MP" ] && _umount_all "$MP"
    done < "$MAP"
}

_cleanup_tmp_files() {
    rm -rf /data/local/tmp/aats_install_gate.* \
           /data/adb/aats_install_gate.* 2>/dev/null
    rm -f /data/local/tmp/aats_volkey.* \
          /data/local/tmp/aats_action_key.* \
          /data/local/tmp/aat_vid_tmp.b64 2>/dev/null
}

_remove_module_dir() {
    case "$1" in
        "$MODULE_DIR"|"$MODULE_UPDATE_DIR") rm -rf "$1" 2>/dev/null ;;
        *) return 1 ;;
    esac
}

_cleanup_color_cgroup() {
    _write "/sys/fs/cgroup/frozen/cgroup.freeze" 0
    _write "/sys/fs/cgroup/unfrozen/cgroup.freeze" 0
    rmdir "/sys/fs/cgroup/frozen" "/sys/fs/cgroup/unfrozen" 2>/dev/null
}

_write "/sys/module/oplus_chg_v2/parameters/gauge_dbg_tbat" 0
_clear_kernel_virtual_gauge
_clear_kernel_usb_therm

for B in "$BIN" "$MODDIR/bin/AaTempSpoof" "$MODULE_DIR/bin/AaTempSpoof"; do
    [ -x "$B" ] || continue
    "$B" --stop --moddir "$MODDIR" >/dev/null 2>&1
    [ "$MODDIR" = "$MODULE_DIR" ] || "$B" --stop --moddir "$MODULE_DIR" >/dev/null 2>&1
done
[ -x "$BIN" ] && "$BIN" --unload-kcompat >/dev/null 2>&1

for PIDFILE in "$PID_DIR"/*.pid "$MODDIR/pid"/*.pid "$DATA_DIR"/*.pid \
               "$MODDIR/daemon.pid" "$DATA_DIR/daemon.pid"; do
    [ -f "$PIDFILE" ] && _kill_pid "$PIDFILE"
done

sleep 0.3
for PAT in "$MODULE_DIR/service.sh" "$MODDIR/service.sh"; do
    _kill_pattern "$PAT"
done
_kill_module_bins
_clear_real_batt_temp

_umount_overlay_map "$MODULE_DIR/pid/overlay.mounts"
_umount_overlay_map "$MODDIR/pid/overlay.mounts"

for NODE in \
    "$BATT_SYS/temp" \
    "$BATT_SYS/uevent" \
    "$BATT_SYS/capacity" \
    "$BATT_SYS/status" \
    "/sys/class/power_supply/usb/online" \
    "/sys/class/power_supply/ac/online" \
    "/sys/class/oplus_chg/battery/temp" \
    "/sys/class/oplus_chg/battery/batt_temp" \
    "/sys/class/oplus_chg/battery/temp_level" \
    "/sys/devices/platform/soc/soc:oplus,mms_gauge/oplus_mms/gauge/battery/temp" \
    "/sys/class/xm_power/fg_master/temp" \
    "/sys/devices/virtual/xm_power/fg_master/temp" \
    "/sys/class/oplus_chg/battery/bcc_parms" \
    "/sys/class/oplus_chg/battery/chip_soc"
do
    _umount_all "$NODE"
done

for NODE in \
    "$BATT_SYS/cycle_count" \
    "$BATT_SYS/battery_cycle" \
    "$BATT_SYS/batt_cycle" \
    "$BATT_SYS/cycle" \
    "/sys/class/power_supply/bms/cycle_count" \
    "/sys/class/power_supply/bms/battery_cycle" \
    "/sys/class/oplus_chg/battery/cycle_count" \
    "/sys/class/oplus_chg/battery/charge_cycle" \
    "/sys/class/oplus_chg/battery/batt_chargecycles" \
    "/sys/class/oplus_chg/battery/battery_cc" \
    "/sys/devices/platform/soc/soc:oplus,mms_gauge/oplus_mms/gauge/battery/cycle_count" \
    "/sys/class/qcom-battery/fake_cycle" \
    "/sys/class/xm_power/fg_master/qmax_cyclecount" \
    "/sys/class/xm_power/fg_master/cyclecount" \
    "/sys/devices/virtual/xm_power/fg_master/qmax_cyclecount" \
    "/sys/devices/virtual/xm_power/fg_master/cyclecount"
do
    _umount_all "$NODE"
done

for F in \
    "/system/product/etc/displayconfig/thermal_brightness_control.xml" \
    "/system/product/etc/displayconfig/common_multi_factor_thermal_brightness_control.xml" \
    "/system/vendor/bin/thermal-engine" \
    "/system/vendor/etc/thermald-devices.conf" \
    "/system/vendor/etc/thermal-tgame.conf" \
    "/system/vendor/etc/thermal-region-map.conf" \
    "/system/vendor/etc/thermal-phone.conf" \
    "/system/vendor/etc/thermal-per-normal.conf" \
    "/system/vendor/etc/thermal-per-navigation.conf" \
    "/system/vendor/etc/thermal-per-class0.conf" \
    "/system/vendor/etc/thermal-per-camera.conf" \
    "/system/vendor/etc/thermal-normal.conf" \
    "/system/vendor/etc/thermal-nolimits.conf" \
    "/system/vendor/etc/thermal-navigation.conf" \
    "/system/vendor/etc/thermal-map.conf" \
    "/system/vendor/etc/thermal-map-india.conf" \
    "/system/vendor/etc/thermal-india-per-normal.conf" \
    "/system/vendor/etc/thermal-india-per-camera.conf" \
    "/system/vendor/etc/thermal-india-normal.conf" \
    "/system/vendor/etc/thermal-india-camera.conf" \
    "/system/vendor/etc/thermal-engine.conf" \
    "/system/vendor/etc/thermal-class0.conf" \
    "/system/vendor/etc/thermal-chg-only.conf" \
    "/system/vendor/etc/thermal-camera.conf" \
    "/system/vendor/etc/thermal-8k.conf" \
    "/system/vendor/etc/thermal-4k.conf" \
    "/system/vendor/etc/perf/thermalboost.conf" \
    "/system/vendor/etc/init/init_thermal-engine.rc" \
    "/system/vendor/etc/init/init.mi_thermald.rc" \
    "/vendor/etc/thermal-engine.conf" \
    "/vendor/etc/thermal-engine-v2.conf" \
    "/vendor/etc/thermal-engine.v3.conf" \
    "/vendor/etc/thermal-engine.v4.conf" \
    "/vendor/etc/thermal-engine.v5.conf" \
    "/vendor/etc/init/android.hardware.thermal-service.qti.rc" \
    "/vendor/etc/init/init_thermal-engine-v2.rc" \
    "/odm/etc/ThermalServiceConfig/sys_thermal_config.xml" \
    "/odm/etc/temperature_profile/sys_thermal_control_config.xml" \
    "/odm/etc/temperature_profile/sys_thermal_control_config_ext.xml" \
    "/odm/etc/temperature_profile/sys_high_temp_protect_OPPO_24811.xml" \
    "/odm/etc/temperature_profile/sys_thermal_zoom_window_restrict_list.xml" \
    "/odm/etc/horae/horae_target.conf" \
    "/system/vendor/etc/power_app_cfg.xml" \
    "/system/vendor/etc/powercontable.xml" \
    "/system/vendor/etc/powerscntbl.xml" \
    "/system/vendor/etc/.tp/.ht120.mtc" \
    "/system/vendor/etc/.tp/thermal.conf" \
    "/system/vendor/etc/.tp/thermal.off.conf" \
    "/system/vendor/etc/.tp/.thermal_policy_08" \
    "/odm/etc/powerhal/power_app_cfg.xml" \
    "/odm/etc/powerhal/powercontable.xml" \
    "/odm/etc/powerhal/powerscntbl.xml"
do
    _umount_all "$F"
done

_umount_module_mounts

for TZ in /sys/class/thermal/thermal_zone*; do
    _write "$TZ/emul_temp" 0
    _write "$TZ/mode" enabled
done
for CS in /sys/class/thermal/cooling_device*/cur_state; do
    _write "$CS" 0
done

for POLICY in /sys/devices/system/cpu/cpufreq/policy*; do
    MAX="$POLICY/cpuinfo_max_freq"
    SCA="$POLICY/scaling_max_freq"
    [ -r "$MAX" ] && [ -w "$SCA" ] && cat "$MAX" > "$SCA" 2>/dev/null
done

_chmod_rw "/sys/kernel/msm_performance/parameters/cpu_max_freq"
_chmod_rw "/sys/module/cpufreq_bouncing/parameters/enable"
_write "/sys/module/cpufreq_bouncing/parameters/enable" 1

_write "/sys/module/msm_thermal/parameters/enabled" 1
_write "/sys/module/msm_thermal/core_control/enabled" 1
_write "/sys/kernel/msm_thermal/enabled" 1
_write "/proc/oplus_temp/oplus_thermal_enable" 1
_write "/proc/oplus_temp/disable_thermal" 0
_write "/sys/class/thermal/thermal_message/board_sensor_temp_ratio" 100
_write "/sys/devices/platform/soc/soc:qcom,bcl-monitor/mode" enable
_write "/sys/devices/platform/soc/soc:qcom,bcl/mode" enable
_write "/proc/game_opt/disable_cpufreq_limit" 0

for N in \
    "/sys/class/xm_power/charger/charger_thermal/wired_thermal_remove" \
    "/sys/class/xm_power/charger/charger_thermal/wireless_thermal_remove" \
    "/sys/class/qcom-battery/thermal_remove"
do
    _write "$N" 0
done

for VA in FCC ICL WIRED_CURR_CTRL GAUGE_UPDATE \
          CHG_DISABLE CHG_SUSPEND WIRED_CHARGE_DONE COOL_DOWN \
          LOW_SOC TRICKLE_CHG LOW_CAPACITY PRE_CHG LOW_POWER; do
    _write "/proc/oplus-votable/$VA/force_active" 0
done
for VA in FCC ICL WIRED_CURR_CTRL GAUGE_UPDATE; do
    _write "/proc/oplus-votable/$VA/force_val" 0
done

_write "$BATT_SYS/siop_level" 100
for N in \
    "/sys/class/oplus_chg/battery/input_suspend" \
    "/sys/class/power_supply/battery/input_suspend" \
    "/sys/class/oplus_chg/battery/stop_chg" \
    "/sys/class/oplus_chg/common/chg_disable_votable" \
    "/sys/class/power_supply/battery/restricted_charging" \
    "/sys/class/qcom-battery/restrict_chg" \
    "/sys/devices/platform/soc/soc:google,charger/charge_disable" \
    "/sys/class/oplus_chg/battery/cool_down" \
    "/sys/class/oplus_chg/battery/chg_cool_down" \
    "/sys/class/oplus_chg/battery/thermal_ctrl" \
    "/sys/kernel/oplus_chg/battery/thermal_ctrl" \
    "/sys/class/oplus_chg/battery/super_endurance_mode" \
    "/sys/class/oplus_chg/battery/chg_cycle_enable" \
    "/sys/class/oplus_chg/common/chg_cycle_status" \
    "/sys/class/oplus_chg/battery/aging_fcc_voted" \
    "/sys/class/oplus_chg/battery/chg_protect_enable" \
    "/sys/class/oplus_chg/battery/battery_notify_code" \
    "/sys/class/oplus_chg/common/cool_down" \
    "/sys/class/oplus_chg/battery/slow_chg_enable" \
    "/sys/class/oplus_chg/common/slow_chg_enable" \
    "/sys/class/oplus_chg/common/pps_disable_votable" \
    "/sys/class/oplus_chg/common/ufcs_disable_votable" \
    "/sys/class/oplus_chg/common/pd_disable_votable" \
    "/sys/class/oplus_chg/battery/screen_off_chg_enable" \
    "/sys/class/oplus_chg/battery/screen_off_slow_chg" \
    "/sys/class/oplus_chg/common/screen_off_chg" \
    "/sys/class/power_supply/battery/screen_off_chg" \
    "/sys/devices/platform/charger/screen_off_throttle" \
    "/sys/class/oplus_chg/battery/night_chg_enable" \
    "/sys/class/oplus_chg/common/night_chg_enable" \
    "/sys/class/power_supply/battery/batt_slate_mode" \
    "/sys/class/power_supply/battery/store_mode" \
    "/sys/class/power_supply/battery/batt_misc_event" \
    "/sys/class/power_supply/battery/mmi_chrg_dis" \
    "/sys/class/power_supply/battery/charge_rate" \
    "/sys/class/power_supply/battery/charge_control_limit" \
    "/sys/class/power_supply/battery/chg_control_limit_max" \
    "/sys/class/power_supply/battery/lim_charge" \
    "/sys/class/oplus_chg/battery/low_soc_limit" \
    "/sys/class/oplus_chg/common/low_soc_limit" \
    "/sys/kernel/oplus_chg/battery/low_chg_current" \
    "/sys/class/power_supply/battery/bd_trickle_cnt" \
    "/sys/class/power_supply/battery/bd_trickle_eoc" \
    "/sys/devices/platform/vivo_battery/screen_off_charge" \
    "/sys/devices/platform/vivo_battery/charge_sleep_mode" \
    "/sys/class/hw_power/charger/charge_data/iin_thermal_aux" \
    "/sys/class/mi_battchg/mi_battchg/thermal_level"
do
    _write "$N" 0
done

for N in \
    "/sys/class/oplus_chg/battery/mmi_charging_enable" \
    "/sys/class/oplus_chg/battery/battery_charging_enabled" \
    "/sys/class/power_supply/battery/battery_charging_enabled" \
    "/sys/class/power_supply/battery/charge_enabled" \
    "/sys/class/power_supply/battery/charging_enabled" \
    "/sys/class/hw_power/charger/charge_data/enable_charger" \
    "/sys/class/oplus_chg/battery/fast_chg_allow" \
    "/sys/class/oplus_chg/battery/pd_allow" \
    "/sys/class/oplus_chg/common/pd_allow" \
    "/sys/class/oplus_chg/battery/vooc_allow" \
    "/sys/class/oplus_chg/battery/wls_boost_en" \
    "/sys/class/oplus_chg/battery/wired_boost_enable" \
    "/sys/class/oplus_chg/common/wired_boost_enable" \
    "/sys/kernel/oplus_chg/battery/voocphy_enable" \
    "/sys/class/power_supply/battery/smart_charging_activation_enabled" \
    "/sys/class/oplus_chg/battery/thermal_enable" \
    "/sys/class/power_supply/battery/thermal_feature_on" \
    "/sys/class/mi_battchg/mi_battchg/thermal_enable"
do
    _write "$N" 1
done

CUP="/sys/class/oplus_chg/common/chg_up_limit"
[ -e "$CUP" ] && chmod 0644 "$CUP" 2>/dev/null

if [ -w "/proc/shell-temp" ]; then
    I=0
    while [ "$I" -le 9 ]; do
        printf '%d 0\n' "$I" > "/proc/shell-temp" 2>/dev/null
        I=$((I + 1))
    done
fi

for P in \
    persist.vendor.charge.thermal.control \
    persist.vendor.oplus.charge.cooldown \
    persist.vendor.oplus.slow_chg_enable \
    persist.oplus.chg.vooc.allow \
    persist.oplus.chg.ufcs.allow \
    persist.oplus.chg.pps.allow \
    persist.oplus.chg.voocphy.allow \
    persist.oplus.chg.svooc.allow \
    persist.oplus.chg.flash_charge.allow \
    persist.oplus.chg.cool_down \
    persist.oplus.chg.screenoff.decharge \
    persist.oplus.chg.screen_off_decharge \
    persist.oplus.chg.screen_off_slow_chg \
    persist.oplus.chg.night_charging \
    persist.sys.powerhal.thermal.disabled \
    persist.vendor.enable.cpulimit \
    persist.sys.charge.restrict \
    persist.sys.charge.screenoff \
    persist.sys.charge.sleep_mode \
    persist.chg.screen_off_reduce \
    persist.vendor.chg.screen_off_reduce \
    persist.vendor.battery.sleep_charging \
    persist.vendor.dgb.sleep.chg.enabled \
    persist.hw.charge.screenoff \
    persist.vivo.charge.screenoff \
    persist.vivo.charger.sleep_mode \
    persist.mmi.charge.screenoff \
    persist.samsung.charge.screenoff \
    persist.miui.charge.screenoff \
    persist.sys.miui_charge_screen_off \
    persist.sys.oplus.wifi.sla.game_high_temperature \
    persist.sys.environment.temp \
    persist.sys.ui.hw \
    ro.oplus.charge.thermal.limit \
    ro.oplus.audio.thermal_control \
    ro.oplus.radio.hide_nr_switch \
    oplus.dex.tempcontrol \
    dalvik.vm.dexopt.thermal-cutoff \
    gputuner_switch \
    vendor.perf.framepacing.enable \
    sys.thermal.enable \
    sys.enable.hypnus \
    vendor.battery.charge.disable \
    vendor.battery.restrict.charging \
    vendor.battery.screenoff.decharge \
    sys.oppo.high.performance
do
    _delprop "$P"
done

_setprop sys.thermal.enable true
_setprop sys.enable.hypnus 1
_setprop persist.vendor.enable.cpulimit true
_setprop persist.sys.powerhal.thermal.disabled 0
_setprop vendor.battery.charge.disable 0
_setprop vendor.battery.restrict.charging 0
_setprop vendor.battery.screenoff.decharge 0
_setprop sys.oppo.high.performance 0
_setprop gputuner_switch false
_setprop oplus.dex.tempcontrol true
_setprop dalvik.vm.dexopt.thermal-cutoff 1
_setprop ro.oplus.charge.thermal.limit 1
_setprop ro.oplus.audio.thermal_control 1
if getprop persist.sys.oiface.enable >/dev/null 2>&1; then
    _setprop persist.sys.horae.enable 1
fi
_cleanup_color_cgroup

dumpsys battery reset 2>/dev/null
service call SurfaceFlinger 1008 i32 0 >/dev/null 2>&1
_write "/sys/class/power_supply/usb/apsd_rerun" 1

for SVC in thermal-engine vendor.thermal-engine vendor.thermal_manager thermald \
           thermal_mnt_hal_service android.thermal-hal vendor.thermal-hal-2-0 \
           vendor.thermal-hal-2-1 oppo_theias orms-hal-1-0 \
           vendor.oplus.ormsHalService-aidl-default vendor.oplus.ormsHalService-aidl-defaults \
           fuelgauged smartcharging horae
do
    start "$SVC" 2>/dev/null
done

if [ -f /data/system/refresh_rate_config.xml.bak ]; then
    cp -fp /data/system/refresh_rate_config.xml.bak /data/system/refresh_rate_config.xml 2>/dev/null
    rm -f /data/system/refresh_rate_config.xml.bak 2>/dev/null
fi

rm -f "$MODDIR/daemon.pid" "$MODDIR/fake_batt_temp" "$MODDIR/user_stopped" \
      "$MODDIR/platform.txt" "$MODDIR/tempspoof.log" 2>/dev/null

rm -f "$DATA_DIR/daemon.pid" "$DATA_DIR/fake_batt_temp" "$DATA_DIR/fake_uevent" \
      "$DATA_DIR/fake_bcc_parms" "$DATA_DIR/fake_cycle_count" "$DATA_DIR/fake_capacity" \
      "$DATA_DIR/cb.pid" "$DATA_DIR/plug.log" "$DATA_DIR/plug.log.bak" \
      "$DATA_DIR/touch_daemon.log" "$DATA_DIR/touch_daemon.log.bak" \
      "$DATA_DIR/charge_horae_daemon.log" "$DATA_DIR/charge_horae_daemon.log.bak" \
      "$DATA_DIR/color_tombstone.log" "$DATA_DIR/color_tombstone.log.bak" 2>/dev/null

rm -rf "$PID_DIR" "$MODDIR/pid" "$MODULE_DIR/pid/overlay" "$MODDIR/pid/overlay" 2>/dev/null
rm -f "$MODULE_DIR/webroot/首次通知.css" "$MODULE_DIR/webroot/通知.png" 2>/dev/null
_cleanup_tmp_files

pm path com.aatempspoof.tile >/dev/null 2>&1 && pm uninstall com.aatempspoof.tile >/dev/null 2>&1

command -v ksud >/dev/null 2>&1 && ksud module uninstall AAaTempSpoof >/dev/null 2>&1
_umount_all "$MODULE_DIR"
_remove_module_dir "$MODULE_UPDATE_DIR"
_remove_module_dir "$MODULE_DIR"

exit 0
