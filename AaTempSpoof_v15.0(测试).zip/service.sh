#!/system/bin/sh

MODDIR="${0%/*}"
BIN="$MODDIR/bin/AaTempSpoof"
GAUGE_PATH="/sys/module/oplus_chg_v2/parameters/gauge_dbg_tbat"
VIRTUAL_IC_ROOT="/sys/class/virtual_ic"
OPBATT_KO=
OPBATT_BRIDGE_MANIFEST="$MODDIR/bin/kcompat/manifest.tsv"
OPBATT_BRIDGE_KO=
OPBATT_BRIDGE_RUNTIME_KO="$MODDIR/pid/opbatt_bridge.runtime.ko"
OPBATT_BRIDGE_DEVICE="/dev/aats_opbatt_bridge"
OPBATT_BRIDGE_MODULE="aats_opbatt_bridge"
OPBATT_LAYOUT_SCHEMA=2
OPBATT_LAYOUT_CACHE="$MODDIR/bin/config/AaTempSpoof/opbatt_layout.v1"

CFGDIR="$MODDIR/bin/config/AaTempSpoof"
PIDDIR="$MODDIR/pid"
LOG="$CFGDIR/tempspoof.log"

mkdir -p "$CFGDIR" "$PIDDIR"

PIDFILE="$PIDDIR/daemon.pid"
CBPID="$PIDDIR/cb.pid"
TOUCHPID="$PIDDIR/touch_daemon.pid"
TOMBSTONEPID="$PIDDIR/color_tombstone.pid"
CHARGEPID="$PIDDIR/charge_horae_daemon.pid"
CLOUDSYNCPID="$PIDDIR/cloud_sync.pid"
NOTIFY_FILE="$PIDDIR/通知"
DONATION_SUSPEND_FLAG="$PIDDIR/donation.suspended"
DONATION_STATUS_FILE="$PIDDIR/donation.status"
INTEGRITY_STATUS_FILE="$PIDDIR/integrity.status"
OPBATT_BRIDGE_STATUS_FILE="$PIDDIR/opbatt_bridge.status"
OPBATT_BRIDGE_LOADING_MARKER="$PIDDIR/opbatt_bridge.loading"
OPBATT_BRIDGE_QUARANTINE="$PIDDIR/opbatt_bridge.quarantine"
OPBATT_BRIDGE_DEFERRED="$PIDDIR/opbatt_bridge.deferred"
OPBATT_BRIDGE_DIAG_FILE="$PIDDIR/opbatt_bridge.diag"
OPBATT_BRIDGE_EVENTS_FILE="$PIDDIR/opbatt_bridge.events"
OPBATT_BRIDGE_PROBATION_SECONDS=45
OPBATT_BRIDGE_STABILIZE_SECONDS=8
OPBATT_BRIDGE_MARKER_VERSION=4
OPBATT_BRIDGE_DIAG_MAX_BYTES=262144
OPBATT_BRIDGE_EVENTS_MAX_BYTES=65536

OPBATT_ACTUAL_SHA256=
OPBATT_RELEASE=
OPBATT_MATCH_VERSION=
OPBATT_STATE=idle
OPBATT_REASON=等待检测
OPBATT_LAYOUT_ID=
OPBATT_CONFIDENCE=
OPBATT_VALIDATION_FLAGS=
OPBATT_TARGET_BUILD_ID=
OPBATT_KMI_MARKER=
OPBATT_FIND_DELTA=
OPBATT_GETTER_DELTA=
OPBATT_LIST_OFFSET=
OPBATT_LOCK_OFFSET=
OPBATT_BRIDGE_ABI=
OPBATT_ANCHOR_KCFI=
OPBATT_FIND_KCFI=
OPBATT_MODULE_ABI_VERIFIED=0
OPBATT_THIS_MODULE_SIZE=
OPBATT_THIS_MODULE_ALIGN=
OPBATT_MODULE_NAME_OFFSET=
OPBATT_MODULE_INIT_OFFSET=
OPBATT_MODULE_EXIT_OFFSET=
OPBATT_MODULE_LAYOUT_CRC=
OPBATT_MODULE_INIT_KCFI=
OPBATT_MODULE_ABI_REASON=
OPBATT_INITSTATE=
OPBATT_SELFTEST_OK=0
OPBATT_LIVE_OWNED=0
OPBATT_LIVE_SET_OK=0
OPBATT_LIVE_CLEAR_OK=0
OPBATT_LIVE_CONFLICTS=0
OPBATT_LIVE_ERRORS=0
OPBATT_LIVE_LAST_ERROR=0
OPBATT_ATTEMPT_EPOCH=0
OPBATT_LAST_LOADER=
OPBATT_LAST_LOADER_RC=127
OPBATT_LAST_LOADER_OUTPUT=
OPBATT_LOADER_POLICY=
OPBATT_KSUD_PATH=

FLAGFILE="$PIDDIR/fake_batt_temp"
STOP_FLAG="$CFGDIR/user_stopped"
APP_PACKAGE="com.aatempspoof.tile"
APP_SERVICE="$APP_PACKAGE/.ChargingLiveService"
APP_PREF="/data/user/0/$APP_PACKAGE/shared_prefs/charging_live.xml"
APP_APK="$MODDIR/bin/apk/AaTempSpoof.apk"
APP_DUAL_CELL_CONFIG="$CFGDIR/充电统计双电.txt"
APP_DUAL_CELL_RUNTIME="/dev/aatempspoof/charge_dual_cell"
APP_HANS_PIDFILE="$PIDDIR/app_hans_guard.pid"
APP_HANS_READY="$PIDDIR/app_hans_guard.ready"

_log() {
    printf '[%s] [service] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOG"
}

_bridge_clean_text() {
    printf '%s' "$*" | tr '\r\n' '  ' | cut -c1-600
}

_bridge_boot_id() {
    local id
    id=$(tr -d ' \r\n' < /proc/sys/kernel/random/boot_id 2>/dev/null)
    [ -n "$id" ] || id=$(getprop ro.boot.bootreason 2>/dev/null | tr -d ' \r\n')
    [ -n "$id" ] || id=unknown
    printf '%s' "$id"
}

_bridge_uptime() {
    awk '{printf "%.3f", $1}' /proc/uptime 2>/dev/null || printf 'unknown'
}

_bridge_diag() {
    local message timestamp size tmp event_size event_tmp
    message=$(_bridge_clean_text "$*")
    timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    printf '[%s] [opbatt_bridge] %s\n' "$timestamp" "$message" >> "$OPBATT_BRIDGE_DIAG_FILE" 2>/dev/null
    printf '%s|%s\n' "$timestamp" "$message" >> "$OPBATT_BRIDGE_EVENTS_FILE" 2>/dev/null
    printf '[%s] [service] opbatt_bridge: %s\n' "$timestamp" "$message" >> "$LOG" 2>/dev/null
    size=$(wc -c < "$OPBATT_BRIDGE_DIAG_FILE" 2>/dev/null)
    case "$size" in ''|*[!0-9]*) size=0 ;; esac
    if [ "$size" -gt "$OPBATT_BRIDGE_DIAG_MAX_BYTES" ] 2>/dev/null; then
        tmp="$OPBATT_BRIDGE_DIAG_FILE.tmp.$$"
        tail -c $((OPBATT_BRIDGE_DIAG_MAX_BYTES / 2)) "$OPBATT_BRIDGE_DIAG_FILE" > "$tmp" 2>/dev/null &&
            mv -f "$tmp" "$OPBATT_BRIDGE_DIAG_FILE"
        rm -f "$tmp" 2>/dev/null
    fi
    event_size=$(wc -c < "$OPBATT_BRIDGE_EVENTS_FILE" 2>/dev/null)
    case "$event_size" in ''|*[!0-9]*) event_size=0 ;; esac
    if [ "$event_size" -gt "$OPBATT_BRIDGE_EVENTS_MAX_BYTES" ] 2>/dev/null; then
        event_tmp="$OPBATT_BRIDGE_EVENTS_FILE.tmp.$$"
        tail -c $((OPBATT_BRIDGE_EVENTS_MAX_BYTES / 2)) "$OPBATT_BRIDGE_EVENTS_FILE" > "$event_tmp" 2>/dev/null &&
            mv -f "$event_tmp" "$OPBATT_BRIDGE_EVENTS_FILE"
        rm -f "$event_tmp" 2>/dev/null
    fi
}

_bridge_marker_field() {
    local key="$1" file="$2"
    [ -r "$file" ] || return 1
    sed -n "s/^${key}=//p" "$file" 2>/dev/null | head -n 1
}

_bridge_marker_write() {
    local stage="$1" loader="${2:-none}" tmp
    tmp="$OPBATT_BRIDGE_LOADING_MARKER.tmp.$$"
    {
        printf 'marker_version=%s\n' "$OPBATT_BRIDGE_MARKER_VERSION"
        printf 'boot_id=%s\n' "$(_bridge_boot_id)"
        printf 'pid=%s\n' "$$"
        printf 'started_epoch=%s\n' "$(date +%s 2>/dev/null)"
        printf 'started_at=%s\n' "$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)"
        printf 'uptime=%s\n' "$(_bridge_uptime)"
        printf 'stage=%s\n' "$stage"
        printf 'state=%s\n' "${OPBATT_STATE:-unknown}"
        printf 'opbatt_sha256=%s\n' "${OPBATT_ACTUAL_SHA256:-unknown}"
        printf 'opbatt_version=%s\n' "${OPBATT_MATCH_VERSION:-unknown}"
        printf 'kernel_release=%s\n' "${OPBATT_RELEASE:-$(uname -r 2>/dev/null)}"
        printf 'layout_schema=%s\n' "${OPBATT_LAYOUT_SCHEMA:-0}"
        printf 'layout_id=%s\n' "${OPBATT_LAYOUT_ID:-unknown}"
        printf 'confidence=%s\n' "${OPBATT_CONFIDENCE:-unknown}"
        printf 'validation_flags=%s\n' "${OPBATT_VALIDATION_FLAGS:-unknown}"
        printf 'find_from_anchor=%s\n' "${OPBATT_FIND_DELTA:-unknown}"
        printf 'getter_from_anchor=%s\n' "${OPBATT_GETTER_DELTA:-unknown}"
        printf 'ic_list_offset=%s\n' "${OPBATT_LIST_OFFSET:-unknown}"
        printf 'ic_lock_offset=%s\n' "${OPBATT_LOCK_OFFSET:-unknown}"
        printf 'bridge_abi=%s\n' "${OPBATT_BRIDGE_ABI:-unknown}"
        printf 'anchor_kcfi=%s\n' "${OPBATT_ANCHOR_KCFI:-unknown}"
        printf 'find_kcfi=%s\n' "${OPBATT_FIND_KCFI:-unknown}"
        printf 'module_abi_verified=%s\n' "${OPBATT_MODULE_ABI_VERIFIED:-0}"
        printf 'this_module_size=%s\n' "${OPBATT_THIS_MODULE_SIZE:-unknown}"
        printf 'this_module_align=%s\n' "${OPBATT_THIS_MODULE_ALIGN:-unknown}"
        printf 'module_name_offset=%s\n' "${OPBATT_MODULE_NAME_OFFSET:-unknown}"
        printf 'module_init_offset=%s\n' "${OPBATT_MODULE_INIT_OFFSET:-unknown}"
        printf 'module_exit_offset=%s\n' "${OPBATT_MODULE_EXIT_OFFSET:-unknown}"
        printf 'module_layout_crc=%s\n' "${OPBATT_MODULE_LAYOUT_CRC:-unknown}"
        printf 'module_init_kcfi=%s\n' "${OPBATT_MODULE_INIT_KCFI:-unknown}"
        printf 'module_abi_reason=%s\n' "${OPBATT_MODULE_ABI_REASON:-unknown}"
        printf 'loader_policy=%s\n' "${OPBATT_LOADER_POLICY:-unknown}"
        printf 'loader=%s\n' "$loader"
        printf 'runtime_sha256=%s\n' "$(sha256sum "$OPBATT_BRIDGE_RUNTIME_KO" 2>/dev/null | awk '{print $1}')"
    } > "$tmp" 2>/dev/null || {
        rm -f "$tmp" 2>/dev/null
        return 1
    }
    chmod 0600 "$tmp" 2>/dev/null || true
    mv -f "$tmp" "$OPBATT_BRIDGE_LOADING_MARKER" 2>/dev/null || {
        rm -f "$tmp" 2>/dev/null
        return 1
    }
    sync
    _bridge_diag "event=marker stage=$stage layout=${OPBATT_LAYOUT_ID:-unknown} loader=$loader boot_id=$(_bridge_boot_id)"
    return 0
}

_bridge_log_environment() {
    _bridge_diag "event=environment pid=$$ boot_id=$(_bridge_boot_id) uptime=$(_bridge_uptime) model=$(_bridge_clean_text "$(getprop ro.product.model 2>/dev/null)") platform=$(_bridge_clean_text "$(getprop ro.board.platform 2>/dev/null)") kernel=$(_bridge_clean_text "$(uname -r 2>/dev/null)")"
    _bridge_diag "event=boot_reason ro_boot_bootreason=$(_bridge_clean_text "$(getprop ro.boot.bootreason 2>/dev/null)") sys_boot_reason=$(_bridge_clean_text "$(getprop sys.boot.reason 2>/dev/null)")"
    _bridge_diag "event=loader_paths path_insmod=$(_bridge_clean_text "$(command -v insmod 2>/dev/null)") path_ksud=$(_bridge_clean_text "$(command -v ksud 2>/dev/null)") system_insmod=$([ -x /system/bin/insmod ] && printf yes || printf no) vendor_insmod=$([ -x /vendor/bin/insmod ] && printf yes || printf no)"
    for _AATS_PSTORE_DIR in /sys/fs/pstore /data/pstore; do
        [ -d "$_AATS_PSTORE_DIR" ] || continue
        for _AATS_PSTORE_FILE in "$_AATS_PSTORE_DIR"/*; do
            [ -r "$_AATS_PSTORE_FILE" ] || continue
            _bridge_diag "event=pstore file=$_AATS_PSTORE_FILE size=$(wc -c < "$_AATS_PSTORE_FILE" 2>/dev/null) matches=$(_bridge_clean_text "$(grep -iE 'aats[_-]opbatt|oplus_chg_v2|watchdog|panic|oops|fatal' "$_AATS_PSTORE_FILE" 2>/dev/null | tail -n 3)")"
        done
    done
}

_sec() {
    local _ts
    _ts=$(date '+%Y-%m-%d %H:%M:%S')
    printf '\n' >> "$LOG"
    printf '[%s] [service] ┌─────────────────────────────────────┐\n' "$_ts" >> "$LOG"
    printf '[%s] [service] │  %-35s│\n' "$_ts" "$1" >> "$LOG"
    printf '[%s] [service] └─────────────────────────────────────┘\n' "$_ts" >> "$LOG"
}

_trim_pid() {
    tr -d ' \r\n' 2>/dev/null
}

_umount_all() {
    local I
    [ -n "$1" ] || return
    I=0
    while [ "$I" -lt 8 ]; do
        umount -l "$1" >/dev/null 2>&1 || break
        I=$((I + 1))
    done
}

_clear_kernel_virtual_gauge() {
    local D NAME FUNCS FUNC OLD
    if [ -c "$OPBATT_BRIDGE_DEVICE" ]; then
        "$BIN" --opbatt-bridge-clear-all >/dev/null 2>&1 || true
        return
    fi
    for D in "$VIRTUAL_IC_ROOT"/vic-*; do
        [ -r "$D/name" ] || continue
        NAME=$(tr -d '\r\n' < "$D/name" 2>/dev/null)
        case "$NAME" in
            oplus,virtual_gauge|oplus,adsp_gauge) FUNCS="405 448" ;;
            oplus,virtual_buck|oplus,pm8550_charger) FUNCS="509 510 527 528 532" ;;
            oplus,adsp_mos|oplus,ufcs_virtual_cp) FUNCS="315" ;;
            *) continue ;;
        esac
        [ -w "$D/func_id" ] && [ -w "$D/clean_overwrite" ] || continue
        OLD=$(tr -d ' \r\n' < "$D/func_id" 2>/dev/null)
        case "$OLD" in ''|*[!0-9-]*) continue ;; esac
        for FUNC in $FUNCS; do
            printf '%s\n' "$FUNC" > "$D/func_id" 2>/dev/null || continue
            printf '1\n' > "$D/clean_overwrite" 2>/dev/null
        done
        printf '%s\n' "$OLD" > "$D/func_id" 2>/dev/null
    done
}

_bridge_status() {
    local ready="$1" reason="$3" tmp
    mkdir -p "$PIDDIR" 2>/dev/null
    OPBATT_STATE=$([ "$ready" = 1 ] && printf active || printf failed)
    OPBATT_REASON=$(_bridge_clean_text "${reason:-未知状态}")
    tmp="$OPBATT_BRIDGE_STATUS_FILE.tmp.$$"
    {
        printf 'report_schema=2\n'
        printf 'ready=%s\n' "$ready"
        printf 'state=%s\n' "$OPBATT_STATE"
        printf 'reason=%s\n' "$OPBATT_REASON"
        printf 'stage=%s\n' "${OPBATT_STAGE:-$OPBATT_STATE}"
        printf 'attempt_epoch=%s\n' "${OPBATT_ATTEMPT_EPOCH:-0}"
        printf 'layout_schema=%s\n' "${OPBATT_LAYOUT_SCHEMA:-0}"
        printf 'layout_id=%s\n' "${OPBATT_LAYOUT_ID:-unknown}"
        printf 'confidence=%s\n' "${OPBATT_CONFIDENCE:-unknown}"
        printf 'validation_flags=%s\n' "${OPBATT_VALIDATION_FLAGS:-unknown}"
        printf 'opbatt_path=%s\n' "${OPBATT_KO:-unknown}"
        printf 'opbatt_version=%s\n' "${OPBATT_MATCH_VERSION:-unknown}"
        printf 'opbatt_sha256=%s\n' "${OPBATT_ACTUAL_SHA256:-unknown}"
        printf 'opbatt_build_id=%s\n' "${OPBATT_TARGET_BUILD_ID:-unknown}"
        printf 'kernel_release=%s\n' "${OPBATT_RELEASE:-unknown}"
        printf 'kmi_marker=%s\n' "${OPBATT_KMI_MARKER:-unknown}"
        printf 'opbatt_initstate=%s\n' "${OPBATT_INITSTATE:-unknown}"
        printf 'bridge_abi=%s\n' "${OPBATT_BRIDGE_ABI:-unknown}"
        printf 'find_from_anchor=%s\n' "${OPBATT_FIND_DELTA:-unknown}"
        printf 'getter_from_anchor=%s\n' "${OPBATT_GETTER_DELTA:-unknown}"
        printf 'ic_list_offset=%s\n' "${OPBATT_LIST_OFFSET:-unknown}"
        printf 'ic_lock_offset=%s\n' "${OPBATT_LOCK_OFFSET:-unknown}"
        printf 'anchor_kcfi=%s\n' "${OPBATT_ANCHOR_KCFI:-unknown}"
        printf 'find_kcfi=%s\n' "${OPBATT_FIND_KCFI:-unknown}"
        printf 'module_abi_verified=%s\n' "${OPBATT_MODULE_ABI_VERIFIED:-0}"
        printf 'this_module_size=%s\n' "${OPBATT_THIS_MODULE_SIZE:-unknown}"
        printf 'this_module_align=%s\n' "${OPBATT_THIS_MODULE_ALIGN:-unknown}"
        printf 'module_name_offset=%s\n' "${OPBATT_MODULE_NAME_OFFSET:-unknown}"
        printf 'module_init_offset=%s\n' "${OPBATT_MODULE_INIT_OFFSET:-unknown}"
        printf 'module_exit_offset=%s\n' "${OPBATT_MODULE_EXIT_OFFSET:-unknown}"
        printf 'module_layout_crc=%s\n' "${OPBATT_MODULE_LAYOUT_CRC:-unknown}"
        printf 'module_init_kcfi=%s\n' "${OPBATT_MODULE_INIT_KCFI:-unknown}"
        printf 'module_abi_reason=%s\n' "${OPBATT_MODULE_ABI_REASON:-unknown}"
        printf 'bridge_source=%s\n' "${OPBATT_BRIDGE_KO:-unknown}"
        printf 'runtime_ko=%s\n' "$OPBATT_BRIDGE_RUNTIME_KO"
        printf 'runtime_sha256=%s\n' "$(sha256sum "$OPBATT_BRIDGE_RUNTIME_KO" 2>/dev/null | awk '{print $1}')"
        printf 'loader=%s\n' "${OPBATT_LAST_LOADER:-none}"
        printf 'loader_policy=%s\n' "${OPBATT_LOADER_POLICY:-unknown}"
        printf 'ksud_path=%s\n' "${OPBATT_KSUD_PATH:-none}"
        printf 'loader_rc=%s\n' "${OPBATT_LAST_LOADER_RC:-127}"
        printf 'loader_output=%s\n' "$(_bridge_clean_text "${OPBATT_LAST_LOADER_OUTPUT:-none}")"
        printf 'selftest_ok=%s\n' "${OPBATT_SELFTEST_OK:-0}"
        printf 'owned=%s\n' "${OPBATT_LIVE_OWNED:-0}"
        printf 'set_ok=%s\n' "${OPBATT_LIVE_SET_OK:-0}"
        printf 'clear_ok=%s\n' "${OPBATT_LIVE_CLEAR_OK:-0}"
        printf 'conflicts=%s\n' "${OPBATT_LIVE_CONFLICTS:-0}"
        printf 'errors=%s\n' "${OPBATT_LIVE_ERRORS:-0}"
        printf 'last_error=%s\n' "${OPBATT_LIVE_LAST_ERROR:-0}"
        printf 'diag_file=%s\n' "$OPBATT_BRIDGE_DIAG_FILE"
        printf 'events_file=%s\n' "$OPBATT_BRIDGE_EVENTS_FILE"
        printf 'marker_file=%s\n' "$OPBATT_BRIDGE_LOADING_MARKER"
        printf 'quarantine_file=%s\n' "$OPBATT_BRIDGE_QUARANTINE"
        printf 'timestamp=%s\n' "$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)"
    } > "$tmp" 2>/dev/null && {
        chmod 0600 "$tmp" 2>/dev/null || true
        mv -f "$tmp" "$OPBATT_BRIDGE_STATUS_FILE" 2>/dev/null || rm -f "$tmp"
    }
    _bridge_diag "event=status state=$OPBATT_STATE ready=$ready reason=$OPBATT_REASON layout=${OPBATT_LAYOUT_ID:-unknown} selftest=${OPBATT_SELFTEST_OK:-0}"
}

_bridge_try_loader() {
    local label="$1" output rc
    shift
    OPBATT_LAST_LOADER="$label"
    OPBATT_LAST_LOADER_RC=127
    OPBATT_LAST_LOADER_OUTPUT=
    if ! _bridge_marker_write loading "$label"; then
        OPBATT_LAST_LOADER_RC=125
        OPBATT_LAST_LOADER_OUTPUT="无法持久化加载器标记"
        _bridge_diag "event=loader_abort tool=$label reason=marker_write_failed"
        return 125
    fi
    _bridge_diag "event=loader_begin tool=$label command=$(_bridge_clean_text "$*")"
    sync
    output=$("$@" 2>&1)
    rc=$?
    output=$(_bridge_clean_text "$output")
    OPBATT_LAST_LOADER_RC=$rc
    OPBATT_LAST_LOADER_OUTPUT="$output"
    _bridge_diag "event=loader_attempt tool=$label rc=$rc output=${output:-none}"
    return "$rc"
}

_bridge_detect_ksud_loader() {
    local resolved tool help
    OPBATT_KSUD_PATH=
    resolved=$(command -v ksud 2>/dev/null)
    case "$resolved" in /*) ;; *) resolved= ;; esac
    for tool in "$resolved" /data/adb/ksu/bin/ksud; do
        [ -n "$tool" ] && [ -x "$tool" ] || continue
        [ "$tool" = "$OPBATT_KSUD_PATH" ] && continue
        help=$("$tool" --help 2>&1)
        printf '%s\n' "$help" |
            grep -Eq '(^|[[:space:]])insmod([[:space:]]|$)' || continue
        OPBATT_KSUD_PATH="$tool"
        return 0
    done
    return 1
}

_bridge_direct_loader_allowed() {
    case "${OPBATT_RELEASE:-$(uname -r 2>/dev/null)}" in
        6.12.*-android16-5-*) return 0 ;;
        *) return 1 ;;
    esac
}

_opbatt_bridge_loaded() {
    grep -q "^${OPBATT_BRIDGE_MODULE} " /proc/modules 2>/dev/null
}

_opbatt_charger_online() {
    local supply online type status
    for supply in /sys/class/power_supply/*; do
        [ -r "$supply/online" ] || continue
        online=$(tr -d ' \r\n' < "$supply/online" 2>/dev/null)
        [ "$online" = "1" ] || continue
        type=$(tr -d '\r\n' < "$supply/type" 2>/dev/null)
        case "$type" in Battery|BMS) ;; *) return 0 ;; esac
    done
    status=$(tr -d '\r\n' < /sys/class/power_supply/battery/status 2>/dev/null)
    [ "$status" = "Charging" ]
}

_opbatt_module_version() {
    local prop value
    for prop in /data/adb/modules/fopbatt/module.prop \
                /data/adb/modules_update/fopbatt/module.prop; do
        [ -r "$prop" ] || continue
        value=$(sed -n 's/^version=//p' "$prop" 2>/dev/null |
            head -n 1 | tr -d '\r')
        [ -n "$value" ] || continue
        printf '%s' "$value"
        return 0
    done
    return 1
}

_select_opbatt_bridge() {
    local actual_sha release schema marker module extra
    local candidate
    [ -r "$OPBATT_BRIDGE_MANIFEST" ] || return 1
    OPBATT_KO=
    for candidate in \
        /vendor_dlkm/lib/modules/oplus_chg_v2.ko \
        /odm_dlkm/lib/modules/oplus_chg_v2.ko \
        /system_dlkm/lib/modules/oplus_chg_v2.ko \
        /vendor/lib/modules/oplus_chg_v2.ko \
        /system/vendor_dlkm/lib/modules/oplus_chg_v2.ko \
        /data/adb/modules/fopbatt/system/vendor_dlkm/lib/modules/oplus_chg_v2.ko \
        /data/adb/modules_update/fopbatt/system/vendor_dlkm/lib/modules/oplus_chg_v2.ko; do
        if [ -r "$candidate" ]; then
            OPBATT_KO="$candidate"
            break
        fi
    done
    if [ -z "$OPBATT_KO" ]; then
        for candidate in /data/adb/modules/fopbatt /data/adb/modules_update/fopbatt; do
            [ -d "$candidate" ] || continue
            OPBATT_KO=$(find "$candidate" -type f -name oplus_chg_v2.ko 2>/dev/null | head -n 1)
            [ -n "$OPBATT_KO" ] && break
        done
    fi
    [ -r "$OPBATT_KO" ] || return 1
    actual_sha=$(sha256sum "$OPBATT_KO" 2>/dev/null | awk '{print $1}')
    release=$(uname -r 2>/dev/null)
    OPBATT_ACTUAL_SHA256="$actual_sha"
    OPBATT_RELEASE="$release"
    OPBATT_INITSTATE=$(tr -d ' \r\n' < /sys/module/oplus_chg_v2/initstate 2>/dev/null)
    [ -n "$OPBATT_INITSTATE" ] || OPBATT_INITSTATE=unknown
    OPBATT_MATCH_VERSION=$(_opbatt_module_version 2>/dev/null || true)
    OPBATT_BRIDGE_KO=
    OPBATT_KMI_MARKER=
    _bridge_diag "event=select_start opbatt_sha=$actual_sha kernel_release=$release opbatt_path=$OPBATT_KO opbatt_initstate=$OPBATT_INITSTATE manifest=$OPBATT_BRIDGE_MANIFEST"
    while IFS="$(printf '\t')" read -r schema marker module extra; do
        case "$schema" in ''|'#'*) continue ;; *[!0-9]*) continue ;; esac
        [ -z "$extra" ] || continue
        case "$release" in $marker) ;; *) continue ;; esac
        case "$module" in ''|*[!A-Za-z0-9._-]*) continue ;; esac
        OPBATT_LAYOUT_SCHEMA=$schema
        OPBATT_KMI_MARKER="$marker"
        [ -n "$OPBATT_MATCH_VERSION" ] ||
            OPBATT_MATCH_VERSION="dynamic-schema-$schema"
        OPBATT_BRIDGE_KO="$MODDIR/bin/kcompat/$module"
        _bridge_diag "event=select_match schema=$schema module=$module kmi=$marker"
        return 0
    done < "$OPBATT_BRIDGE_MANIFEST"
    _bridge_diag "event=select_no_match opbatt_sha=$actual_sha kernel_release=$release"
    return 1
}

_bridge_insmod() {
    local resolved tool rc
    OPBATT_LAST_LOADER=
    OPBATT_LAST_LOADER_RC=127
    OPBATT_LAST_LOADER_OUTPUT=
    OPBATT_LOADER_POLICY=

    if _bridge_detect_ksud_loader; then
        OPBATT_LOADER_POLICY=ksud-authoritative
        _bridge_diag "event=loader_selected policy=$OPBATT_LOADER_POLICY tool=$OPBATT_KSUD_PATH reason=kernel_manager_supports_insmod"
        _bridge_try_loader "ksud-insmod:$OPBATT_KSUD_PATH" \
            "$OPBATT_KSUD_PATH" insmod "$1"
        rc=$?
        if [ "$rc" -eq 0 ] || _opbatt_bridge_loaded; then return 0; fi
        _bridge_diag "event=loader_stop policy=$OPBATT_LOADER_POLICY rc=$rc reason=authoritative_loader_returned"
        return "$rc"
    fi

    resolved=$(command -v insmod 2>/dev/null)
    case "$resolved" in /*) ;; *) resolved= ;; esac
    for tool in "$resolved" /system/bin/insmod /vendor/bin/insmod; do
        [ -n "$tool" ] || continue
        [ -x "$tool" ] || continue
        OPBATT_LOADER_POLICY=system-insmod-authoritative
        _bridge_diag "event=loader_selected policy=$OPBATT_LOADER_POLICY tool=$tool reason=no_supported_ksud_loader"
        _bridge_try_loader "path:$tool" "$tool" "$1"
        rc=$?
        if [ "$rc" -eq 0 ] || _opbatt_bridge_loaded; then return 0; fi
        _bridge_diag "event=loader_stop policy=$OPBATT_LOADER_POLICY rc=$rc reason=authoritative_loader_returned"
        return "$rc"
    done

    if _bridge_direct_loader_allowed; then
        OPBATT_LOADER_POLICY=direct-finit-last-resort
        _bridge_diag "event=loader_selected policy=$OPBATT_LOADER_POLICY tool=$BIN reason=no_manager_or_system_loader"
        _bridge_try_loader "direct-finit-module" "$BIN" --load-opbatt-bridge "$1"
        rc=$?
        if [ "$rc" -eq 0 ] || _opbatt_bridge_loaded; then return 0; fi
        return "$rc"
    fi

    OPBATT_LOADER_POLICY=fail-closed-no-safe-loader
    OPBATT_LAST_LOADER="none"
    OPBATT_LAST_LOADER_RC=127
    OPBATT_LAST_LOADER_OUTPUT="当前 KMI 未找到安全加载器，已禁止 direct finit_module"
    _bridge_diag "event=loader_missing policy=$OPBATT_LOADER_POLICY direct_finit=blocked kernel=$OPBATT_RELEASE"
    return 127
}

_bridge_rmmod() {
    if "$BIN" --unload-opbatt-bridge >/dev/null 2>&1; then
        return 0
    fi
    if command -v rmmod >/dev/null 2>&1; then
        rmmod "$OPBATT_BRIDGE_MODULE"
    elif [ -x /system/bin/rmmod ]; then
        /system/bin/rmmod "$OPBATT_BRIDGE_MODULE"
    else
        return 127
    fi
}

_bridge_healthcheck() {
    local i output raw rc max_wait require_selftest key value
    max_wait="${1:-10}"
    require_selftest="${2:-1}"
    case "$max_wait" in ''|*[!0-9]*) max_wait=10 ;; esac
    i=0
    while [ "$i" -lt "$max_wait" ] && [ ! -c "$OPBATT_BRIDGE_DEVICE" ]; do
        sleep 1
        i=$((i + 1))
    done
    if [ ! -c "$OPBATT_BRIDGE_DEVICE" ]; then
        _bridge_diag "event=healthcheck device=missing waited=${i}s max_wait=${max_wait}s"
        return 1
    fi
    output=$("$BIN" --opbatt-bridge-status 2>&1)
    rc=$?
    output=$(_bridge_clean_text "$output")
    if [ "$rc" -eq 0 ]; then
        "$BIN" --opbatt-bridge-status > "$OPBATT_BRIDGE_STATUS_FILE.live.tmp" 2>/dev/null || true
        if [ -s "$OPBATT_BRIDGE_STATUS_FILE.live.tmp" ]; then
            mv -f "$OPBATT_BRIDGE_STATUS_FILE.live.tmp" "$OPBATT_BRIDGE_STATUS_FILE.live"
            while IFS='=' read -r key value; do
                case "$key" in
                    abi) OPBATT_BRIDGE_ABI="$value" ;;
                    selftest_ok) OPBATT_SELFTEST_OK="$value" ;;
                    owned) OPBATT_LIVE_OWNED="$value" ;;
                    set_ok) OPBATT_LIVE_SET_OK="$value" ;;
                    clear_ok) OPBATT_LIVE_CLEAR_OK="$value" ;;
                    conflicts) OPBATT_LIVE_CONFLICTS="$value" ;;
                    errors) OPBATT_LIVE_ERRORS="$value" ;;
                    last_error) OPBATT_LIVE_LAST_ERROR="$value" ;;
                    layout_id) OPBATT_LAYOUT_ID="$value" ;;
                    confidence) OPBATT_CONFIDENCE="$value" ;;
                    validation_flags) OPBATT_VALIDATION_FLAGS="$value" ;;
                    find_from_anchor) OPBATT_FIND_DELTA="$value" ;;
                    getter_from_anchor) OPBATT_GETTER_DELTA="$value" ;;
                    ic_list_offset) OPBATT_LIST_OFFSET="$value" ;;
                    ic_lock_offset) OPBATT_LOCK_OFFSET="$value" ;;
                    anchor_kcfi) OPBATT_ANCHOR_KCFI="$value" ;;
                    find_kcfi) OPBATT_FIND_KCFI="$value" ;;
                    sha256) OPBATT_ACTUAL_SHA256="$value" ;;
                    build_id) OPBATT_TARGET_BUILD_ID="$value" ;;
                    kmi_marker) OPBATT_KMI_MARKER="$value" ;;
                esac
            done < "$OPBATT_BRIDGE_STATUS_FILE.live"
        else
            rm -f "$OPBATT_BRIDGE_STATUS_FILE.live.tmp"
            rc=1
        fi
    fi
    if [ "$rc" -eq 0 ] && [ "$require_selftest" = 1 ] &&
       [ "${OPBATT_SELFTEST_OK:-0}" != 1 ]; then
        OPBATT_STAGE=selftest
        _bridge_marker_write selftest "${OPBATT_LAST_LOADER:-direct-finit-module}" || true
        raw=$("$BIN" --opbatt-bridge-selftest 2>&1)
        rc=$?
        OPBATT_SELFTEST_OK=$(printf '%s\n' "$raw" | sed -n 's/^selftest_ok=//p' | tail -n 1)
        output=$(_bridge_clean_text "$raw")
        case "$OPBATT_SELFTEST_OK" in 1) ;; *) OPBATT_SELFTEST_OK=0 ;; esac
        _bridge_diag "event=selftest rc=$rc selftest_ok=$OPBATT_SELFTEST_OK output=${output:-none}"
    fi
    if [ "$rc" -eq 0 ] && [ "$require_selftest" = 1 ] &&
       [ "${OPBATT_SELFTEST_OK:-0}" != 1 ]; then
        rc=1
    fi
    if [ "$rc" -eq 0 ]; then
        _bridge_diag "event=healthcheck result=ok status=${output:-none} selftest=${OPBATT_SELFTEST_OK:-0}"
        return 0
    fi
    rm -f "$OPBATT_BRIDGE_STATUS_FILE.live.tmp"
    _bridge_diag "event=healthcheck result=fail rc=$rc output=${output:-none} selftest=${OPBATT_SELFTEST_OK:-0}"
    return 1
}

_bridge_handle_loading_marker() {
    local marker_boot marker_stage marker_pid marker_epoch now age current_boot i
    marker_boot=$(_bridge_marker_field boot_id "$OPBATT_BRIDGE_LOADING_MARKER")
    marker_stage=$(_bridge_marker_field stage "$OPBATT_BRIDGE_LOADING_MARKER")
    marker_pid=$(_bridge_marker_field pid "$OPBATT_BRIDGE_LOADING_MARKER")
    marker_epoch=$(_bridge_marker_field started_epoch "$OPBATT_BRIDGE_LOADING_MARKER")
    current_boot=$(_bridge_boot_id)
    now=$(date +%s 2>/dev/null)
    age=unknown
    case "$marker_epoch:$now" in
        ''|*:*[!0-9]*) ;;
        *) [ "$now" -ge "$marker_epoch" ] 2>/dev/null && age=$((now - marker_epoch)) ;;
    esac
    _bridge_diag "event=stale_marker marker_boot=${marker_boot:-legacy} current_boot=$current_boot marker_pid=${marker_pid:-unknown} stage=${marker_stage:-unknown} age=${age}s file=$OPBATT_BRIDGE_LOADING_MARKER"

    # If another service instance is still completing the same-boot attempt,
    # give it a short window to publish the device instead of quarantining it.
    if [ -n "$marker_boot" ] && [ "$marker_boot" = "$current_boot" ]; then
        _bridge_diag "event=stale_marker_same_boot action=wait timeout=12s"
        i=0
        while [ "$i" -lt 12 ]; do
            if _bridge_healthcheck 1 1; then
                rm -f "$OPBATT_BRIDGE_LOADING_MARKER" "$OPBATT_BRIDGE_QUARANTINE"
                _bridge_diag "event=stale_marker_recovered action=clear"
                _log "opbatt 内核桥接已由同一启动周期的加载实例恢复"
                return 0
            fi
            sleep 1
            i=$((i + 1))
        done
        if [ "${marker_stage:-unknown}" = prepared ]; then
            rm -f "$OPBATT_BRIDGE_LOADING_MARKER"
            _bridge_diag "event=stale_marker_same_boot action=retry stage=prepared"
            return 2
        fi
    else
        if [ "${marker_stage:-unknown}" = prepared ]; then
            rm -f "$OPBATT_BRIDGE_LOADING_MARKER"
            _bridge_diag "event=stale_marker_after_reboot action=retry stage=prepared"
            return 2
        fi
        _bridge_diag "event=stale_marker_after_reboot action=quarantine stage=${marker_stage:-unknown}"
    fi

    mv -f "$OPBATT_BRIDGE_LOADING_MARKER" \
        "$OPBATT_BRIDGE_QUARANTINE" 2>/dev/null ||
        touch "$OPBATT_BRIDGE_QUARANTINE"
    OPBATT_STAGE=quarantine
    _bridge_status 0 "$OPBATT_LAYOUT_SCHEMA" "上次加载阶段为 ${marker_stage:-unknown}，已隔离以避免重复重启；请查看详细诊断"
    _bridge_diag "event=quarantine reason=incomplete_load marker_stage=${marker_stage:-unknown}"
    _log "⚠ opbatt 内核桥接上次加载未完成，本次已跳过"
    return 1
}

_bridge_import_layout_cache() {
    local key value
    [ -r "$OPBATT_LAYOUT_CACHE" ] || return 1
    OPBATT_LAYOUT_ID=
    OPBATT_CONFIDENCE=
    OPBATT_VALIDATION_FLAGS=
    OPBATT_TARGET_BUILD_ID=
    OPBATT_FIND_DELTA=
    OPBATT_GETTER_DELTA=
    OPBATT_LIST_OFFSET=
    OPBATT_LOCK_OFFSET=
    OPBATT_BRIDGE_ABI=
    OPBATT_ANCHOR_KCFI=
    OPBATT_FIND_KCFI=
    OPBATT_MODULE_ABI_VERIFIED=0
    OPBATT_THIS_MODULE_SIZE=
    OPBATT_THIS_MODULE_ALIGN=
    OPBATT_MODULE_NAME_OFFSET=
    OPBATT_MODULE_INIT_OFFSET=
    OPBATT_MODULE_EXIT_OFFSET=
    OPBATT_MODULE_LAYOUT_CRC=
    OPBATT_MODULE_INIT_KCFI=
    OPBATT_MODULE_ABI_REASON=
    while IFS='=' read -r key value; do
        case "$key" in
            bridge_abi) OPBATT_BRIDGE_ABI="$value" ;;
            schema) OPBATT_LAYOUT_SCHEMA="$value" ;;
            layout_id) OPBATT_LAYOUT_ID="$value" ;;
            confidence) OPBATT_CONFIDENCE="$value" ;;
            validation_flags) OPBATT_VALIDATION_FLAGS="$value" ;;
            target_sha256) [ "$value" = "$OPBATT_ACTUAL_SHA256" ] || return 1 ;;
            target_build_id) OPBATT_TARGET_BUILD_ID="$value" ;;
            kmi_marker) OPBATT_KMI_MARKER="$value" ;;
            find_from_anchor) OPBATT_FIND_DELTA="$value" ;;
            getter_from_anchor) OPBATT_GETTER_DELTA="$value" ;;
            ic_list_offset) OPBATT_LIST_OFFSET="$value" ;;
            ic_lock_offset) OPBATT_LOCK_OFFSET="$value" ;;
            anchor_kcfi) OPBATT_ANCHOR_KCFI="$value" ;;
            find_kcfi) OPBATT_FIND_KCFI="$value" ;;
            module_abi_verified) OPBATT_MODULE_ABI_VERIFIED="$value" ;;
            this_module_size) OPBATT_THIS_MODULE_SIZE="$value" ;;
            this_module_align) OPBATT_THIS_MODULE_ALIGN="$value" ;;
            module_name_offset) OPBATT_MODULE_NAME_OFFSET="$value" ;;
            module_init_offset) OPBATT_MODULE_INIT_OFFSET="$value" ;;
            module_exit_offset) OPBATT_MODULE_EXIT_OFFSET="$value" ;;
            module_layout_crc) OPBATT_MODULE_LAYOUT_CRC="$value" ;;
            module_init_kcfi) OPBATT_MODULE_INIT_KCFI="$value" ;;
            module_abi_reason) OPBATT_MODULE_ABI_REASON="$value" ;;
        esac
    done < "$OPBATT_LAYOUT_CACHE"
    [ "$OPBATT_BRIDGE_ABI" = 3 ] && [ "$OPBATT_LAYOUT_SCHEMA" = 2 ] &&
        [ -n "$OPBATT_LAYOUT_ID" ] && [ "$OPBATT_CONFIDENCE" = high ] &&
        [ -n "$OPBATT_TARGET_BUILD_ID" ] && [ -n "$OPBATT_ANCHOR_KCFI" ] &&
        [ -n "$OPBATT_FIND_KCFI" ] && [ "$OPBATT_MODULE_ABI_VERIFIED" = 1 ] &&
        [ -n "$OPBATT_THIS_MODULE_SIZE" ] &&
        [ -n "$OPBATT_THIS_MODULE_ALIGN" ] &&
        [ -n "$OPBATT_MODULE_NAME_OFFSET" ] &&
        [ -n "$OPBATT_MODULE_INIT_OFFSET" ] &&
        [ -n "$OPBATT_MODULE_EXIT_OFFSET" ] &&
        [ -n "$OPBATT_MODULE_LAYOUT_CRC" ] &&
        [ -n "$OPBATT_MODULE_INIT_KCFI" ]
}

load_opbatt_bridge() {
    local release output rc marker_rc validation_ko verify_output
    OPBATT_ATTEMPT_EPOCH=$(date +%s 2>/dev/null || printf 0)
    OPBATT_STAGE=enter
    _bridge_diag "event=load_enter loaded=$(_opbatt_bridge_loaded && printf yes || printf no) charger=$(_opbatt_charger_online && printf yes || printf no)"

    if _opbatt_bridge_loaded; then
        OPBATT_STAGE=loaded_existing
        if ! _select_opbatt_bridge; then
            _bridge_status 0 0 "已发现桥接模块，但无法定位本机 opbatt 或对应 KMI 核心"
            _bridge_diag "event=loaded_existing_verify_fail reason=select_failed"
            return 1
        fi
        if [ ! -r "$OPBATT_BRIDGE_RUNTIME_KO" ]; then
            _bridge_status 0 "$OPBATT_LAYOUT_SCHEMA" "已发现桥接模块，但缺少已加载运行时 KO，需重启后重新完成 ABI 验证"
            _bridge_diag "event=loaded_existing_verify_fail reason=runtime_ko_missing"
            return 1
        fi
        verify_output=$("$BIN" --verify-opbatt-module-abi \
            "$OPBATT_BRIDGE_RUNTIME_KO" "$OPBATT_KO" 2>&1)
        rc=$?
        verify_output=$(_bridge_clean_text "$verify_output")
        if [ "$rc" -ne 0 ]; then
            rm -f "$OPBATT_LAYOUT_CACHE"
            _bridge_status 0 "$OPBATT_LAYOUT_SCHEMA" "当前已加载桥接的模块 ABI 未通过复核；请重启后使用新核心"
            _bridge_diag "event=loaded_existing_verify_fail reason=module_abi rc=$rc output=${verify_output:-none}"
            return 1
        fi
        release="${OPBATT_RELEASE:-$(uname -r 2>/dev/null)}"
        validation_ko="$PIDDIR/opbatt_bridge.validate.$$"
        rm -f "$validation_ko" "$OPBATT_LAYOUT_CACHE"
        output=$("$BIN" --prepare-opbatt-bridge "$OPBATT_BRIDGE_KO" \
            "$OPBATT_KO" "$validation_ko" "$release" \
            "$OPBATT_LAYOUT_CACHE" 2>&1)
        rc=$?
        output=$(_bridge_clean_text "$output")
        rm -f "$validation_ko"
        if [ "$rc" -ne 0 ] || ! _bridge_import_layout_cache; then
            _bridge_status 0 "$OPBATT_LAYOUT_SCHEMA" "已加载桥接通过运行时 ABI 复核，但新版完整布局验证失败；请重启后重试"
            _bridge_diag "event=loaded_existing_verify_fail reason=layout rc=$rc output=${output:-none}"
            return 1
        fi
        OPBATT_MODULE_ABI_REASON="已加载运行时 KO、预编译核心与原生模块 ABI 均一致"
        OPBATT_LAST_LOADER=existing-loaded
        OPBATT_LAST_LOADER_RC=0
        OPBATT_LAST_LOADER_OUTPUT="已复核当前运行时 KO，未重复执行 insmod"
        OPBATT_LOADER_POLICY=existing-runtime-verified
        _bridge_diag "event=loaded_existing_verify_ok this_module=$OPBATT_THIS_MODULE_SIZE init=$OPBATT_MODULE_INIT_OFFSET exit=$OPBATT_MODULE_EXIT_OFFSET module_crc=$OPBATT_MODULE_LAYOUT_CRC init_kcfi=$OPBATT_MODULE_INIT_KCFI"
        if _bridge_healthcheck 2 1; then
            rm -f "$OPBATT_BRIDGE_LOADING_MARKER" "$OPBATT_BRIDGE_QUARANTINE"
            _bridge_status 1 "$OPBATT_LAYOUT_SCHEMA" "动态桥接已加载并通过真实读回自检"
            _log "opbatt 动态内核桥接已在运行"
            return 0
        fi
        _bridge_status 0 "$OPBATT_LAYOUT_SCHEMA" "模块已加载但动态布局或真实读回自检异常"
        _bridge_diag "event=loaded_unhealthy action=stop"
        return 1
    fi

    if [ -f "$OPBATT_BRIDGE_LOADING_MARKER" ]; then
        _bridge_handle_loading_marker
        marker_rc=$?
        [ "$marker_rc" -eq 0 ] && return 0
        [ "$marker_rc" -ne 2 ] && return 1
    fi
    if [ -f "$OPBATT_BRIDGE_QUARANTINE" ]; then
        OPBATT_STAGE=quarantine
        _bridge_status 0 "$OPBATT_LAYOUT_SCHEMA" "安全隔离中；详细状态可查看触发阶段、布局和加载器返回值"
        _bridge_diag "event=quarantine_active action=skip"
        return 1
    fi

    OPBATT_STAGE=select
    if ! _select_opbatt_bridge; then
        if [ -z "$OPBATT_KO" ]; then
            _bridge_status 0 0 "未找到已挂载的 oplus_chg_v2.ko"
            _bridge_diag "event=select_fail reason=opbatt_missing"
        else
            _bridge_status 0 0 "当前 KMI 不在 15.0 动态桥接核心范围"
            _bridge_diag "event=select_fail reason=kmi_core_missing release=${OPBATT_RELEASE:-unknown}"
        fi
        return 1
    fi
    [ -r "$OPBATT_BRIDGE_KO" ] || {
        _bridge_status 0 "$OPBATT_LAYOUT_SCHEMA" "对应 KMI 的动态桥接核心不存在"
        _bridge_diag "event=select_fail reason=bridge_ko_missing path=$OPBATT_BRIDGE_KO"
        return 1
    }
    release="${OPBATT_RELEASE:-$(uname -r 2>/dev/null)}"
    if _opbatt_charger_online; then
        touch "$OPBATT_BRIDGE_DEFERRED" 2>/dev/null || true
        OPBATT_STAGE=deferred
        _bridge_status 0 "$OPBATT_LAYOUT_SCHEMA" "等待断开充电器后再执行动态解析和真实读回自检"
        _bridge_diag "event=load_deferred reason=charger_online schema=$OPBATT_LAYOUT_SCHEMA"
        return 1
    fi

    OPBATT_STAGE=prepare
    rm -f "$OPBATT_BRIDGE_DEFERRED" "$OPBATT_BRIDGE_RUNTIME_KO" \
        "$OPBATT_BRIDGE_LOADING_MARKER.tmp.$$" "$OPBATT_LAYOUT_CACHE"
    _bridge_diag "event=prepare_start schema=$OPBATT_LAYOUT_SCHEMA source=$OPBATT_BRIDGE_KO opbatt=$OPBATT_KO release=$release"
    output=$("$BIN" --prepare-opbatt-bridge "$OPBATT_BRIDGE_KO" "$OPBATT_KO" \
        "$OPBATT_BRIDGE_RUNTIME_KO" "$release" "$OPBATT_LAYOUT_CACHE" 2>&1)
    rc=$?
    output=$(_bridge_clean_text "$output")
    if [ "$rc" -ne 0 ] || ! _bridge_import_layout_cache; then
        _bridge_status 0 "$OPBATT_LAYOUT_SCHEMA" "本机模块 ABI 或 opbatt 布局未通过完整验证，已拒绝加载"
        _bridge_diag "event=prepare_fail rc=$rc output=${output:-none} cache=$OPBATT_LAYOUT_CACHE"
        _log "⚠ opbatt 桥接完整 ABI 验证失败：${output:-未知错误}"
        return 1
    fi
    _bridge_diag "event=prepare_ok bridge_abi=$OPBATT_BRIDGE_ABI layout=$OPBATT_LAYOUT_ID confidence=$OPBATT_CONFIDENCE flags=$OPBATT_VALIDATION_FLAGS anchor_kcfi=$OPBATT_ANCHOR_KCFI find_kcfi=$OPBATT_FIND_KCFI find=$OPBATT_FIND_DELTA getter=$OPBATT_GETTER_DELTA list=$OPBATT_LIST_OFFSET lock=$OPBATT_LOCK_OFFSET module_abi=$OPBATT_MODULE_ABI_VERIFIED this_module=$OPBATT_THIS_MODULE_SIZE align=$OPBATT_THIS_MODULE_ALIGN name=$OPBATT_MODULE_NAME_OFFSET init=$OPBATT_MODULE_INIT_OFFSET exit=$OPBATT_MODULE_EXIT_OFFSET module_crc=$OPBATT_MODULE_LAYOUT_CRC init_kcfi=$OPBATT_MODULE_INIT_KCFI runtime_sha=$(sha256sum "$OPBATT_BRIDGE_RUNTIME_KO" 2>/dev/null | awk '{print $1}')"
    _bridge_marker_write prepared none || {
        _bridge_status 0 "$OPBATT_LAYOUT_SCHEMA" "无法写入动态桥接加载标记"
        _bridge_diag "event=marker_fail stage=prepared"
        return 1
    }

    OPBATT_STAGE=loading
    _bridge_insmod "$OPBATT_BRIDGE_RUNTIME_KO"
    rc=$?
    output=$(_bridge_clean_text "$OPBATT_LAST_LOADER_OUTPUT")
    if [ "$rc" -ne 0 ]; then
        rm -f "$OPBATT_BRIDGE_LOADING_MARKER"
        _bridge_status 0 "$OPBATT_LAYOUT_SCHEMA" "动态桥接加载失败：${output:-未知错误}"
        _bridge_diag "event=insmod_fail rc=$rc tool=${OPBATT_LAST_LOADER:-unknown} output=${output:-none}"
        _log "⚠ opbatt 动态桥接加载失败：${output:-未知错误}"
        return 1
    fi
    _bridge_diag "event=insmod_ok tool=${OPBATT_LAST_LOADER:-unknown}"
    _bridge_marker_write loaded "${OPBATT_LAST_LOADER:-unknown}" ||
        _bridge_diag "event=marker_fail stage=loaded"

    OPBATT_STAGE=selftest
    if ! _bridge_healthcheck 10 1; then
        _bridge_rmmod >/dev/null 2>&1 || true
        rm -f "$OPBATT_BRIDGE_LOADING_MARKER" "$OPBATT_BRIDGE_STATUS_FILE.live.tmp"
        _bridge_status 0 "$OPBATT_LAYOUT_SCHEMA" "加载后真实读回自检失败，已主动卸载桥接"
        _bridge_diag "event=load_fail stage=selftest action=unload"
        _log "⚠ opbatt 动态桥接真实读回自检失败，已卸载"
        return 1
    fi
    OPBATT_STAGE=probation
    _bridge_marker_write probation "${OPBATT_LAST_LOADER:-unknown}" ||
        _bridge_diag "event=marker_fail stage=probation"
    _bridge_status 1 "$OPBATT_LAYOUT_SCHEMA" "动态布局、内核加载和真实读回自检均已通过，进入安全观察期"
    _log "opbatt 动态内核桥接已进入安全观察期 (layout=$OPBATT_LAYOUT_ID loader=${OPBATT_LAST_LOADER:-unknown})"
    return 0
}

start_opbatt_bridge_probation() {
    [ -f "$OPBATT_BRIDGE_LOADING_MARKER" ] || return 0
    _bridge_diag "event=probation_start seconds=$OPBATT_BRIDGE_PROBATION_SECONDS layout=${OPBATT_LAYOUT_ID:-unknown}"
    (
        sleep "$OPBATT_BRIDGE_PROBATION_SECONDS"
        if [ ! -f "$OPBATT_BRIDGE_LOADING_MARKER" ]; then
            _bridge_diag "event=probation_end result=marker_missing"
            exit 0
        fi
        if _opbatt_bridge_loaded && _bridge_healthcheck 2 1; then
            rm -f "$OPBATT_BRIDGE_LOADING_MARKER" "$OPBATT_BRIDGE_QUARANTINE"
            sync
            OPBATT_STAGE=active
            _bridge_status 1 "$OPBATT_LAYOUT_SCHEMA" "动态桥接已加载并可用于内核伪装；持续监测中"
            _bridge_diag "event=probation_end result=pass action=clear_marker"
            _log "opbatt 动态内核桥接安全观察通过"
        else
            OPBATT_STAGE=probation_failed
            _bridge_status 0 "$OPBATT_LAYOUT_SCHEMA" "安全观察未通过；保留标记以避免下一次启动重复触发风险"
            _bridge_diag "event=probation_end result=fail action=retain_marker"
            _log "⚠ opbatt 动态内核桥接安全观察未通过，保留隔离标记"
        fi
    ) &
}

_clear_kernel_usb_therm() {
    local Z TYPE LABEL_PATH LABEL INPUT NAME
    for Z in /sys/class/thermal/thermal_zone*; do
        [ -r "$Z/type" ] || continue
        TYPE=$(tr '[:upper:]-' '[:lower:]_' < "$Z/type" 2>/dev/null | tr -d '\r\n')
        case "$TYPE" in
            usb|*usb_therm*|*svooc_mos_btb*)
                [ -w "$Z/emul_temp" ] && printf '0\n' > "$Z/emul_temp" 2>/dev/null
                _umount_all "$Z/temp"
                ;;
        esac
    done

    for LABEL_PATH in /sys/bus/iio/devices/iio:device*/in_temp_*_label; do
        [ -r "$LABEL_PATH" ] || continue
        LABEL=$(tr '[:upper:]-' '[:lower:]_' < "$LABEL_PATH" 2>/dev/null | tr -d '\r\n')
        case "$LABEL" in
            *usb_therm*|*svooc_mos_btb*)
                INPUT=${LABEL_PATH%_label}_input
                [ -e "$INPUT" ] && _umount_all "$INPUT"
                ;;
        esac
    done

    for INPUT in /sys/bus/iio/devices/iio:device*/in_temp_*usb*therm*_input \
                 /sys/bus/iio/devices/iio:device*/in_temp_*svooc_mos_btb*_input; do
        [ -e "$INPUT" ] || continue
        NAME=$(printf '%s' "${INPUT##*/}" | tr '[:upper:]-' '[:lower:]_')
        case "$NAME" in
            *usb_therm*|*svooc_mos_btb*) _umount_all "$INPUT" ;;
        esac
    done
}

_pid_alive() {
    local p expected cmd
    [ -s "$1" ] || return 1
    expected="$2"
    p=$(cat "$1" 2>/dev/null | _trim_pid)
    case "$p" in
        ''|*[!0-9]*) rm -f "$1" 2>/dev/null; return 1 ;;
    esac
    if kill -0 "$p" 2>/dev/null && [ -r "/proc/$p/cmdline" ]; then
        cmd=$(tr '\0' ' ' < "/proc/$p/cmdline" 2>/dev/null)
        case "$cmd" in
            *"$BIN"*)
                if [ -z "$expected" ]; then
                    return 0
                fi
                case "$cmd" in *"$expected"*) return 0 ;; esac
                ;;
        esac
    fi
    rm -f "$1" 2>/dev/null
    return 1
}

_pid_value() {
    cat "$1" 2>/dev/null | _trim_pid
}

_runtime_status_reason() {
    [ -s "$1" ] || return 1
    tr '\r\n' ' ' < "$1" 2>/dev/null | cut -c1-240
}

_start_blocked_by_status() {
    local reason
    reason=$(_runtime_status_reason "$INTEGRITY_STATUS_FILE")
    if [ -n "$reason" ]; then
        _log "模块完整性校验失败，停止启动辅助进程：$reason"
        return 0
    fi
    [ "$1" = "integrity" ] && return 1
    reason=$(_runtime_status_reason "$DONATION_STATUS_FILE")
    if [ -n "$reason" ]; then
        _log "捐赠授权校验失败，停止启动辅助进程：$reason"
        return 0
    fi
    return 1
}

MODULE_NAME=$(grep "^name=" "$MODDIR/module.prop" 2>/dev/null | cut -d= -f2)
[ -z "$MODULE_NAME" ] && MODULE_NAME="模块加载失败"

notify() {
    su 2000 -c "cmd notification post -S bigtext -t \"$1\" tempspoof_action \"$2\"" 2>/dev/null
    _log "通知发送: 标题=\"$1\", 内容=\"$2\""
}

if [ -f "$LOG" ] && [ "$(wc -c < "$LOG")" -gt 1048576 ]; then
    tail -c 65536 "$LOG" > "${LOG}.tmp"
    mv "${LOG}.tmp" "$LOG"
fi

touch "$LOG" 2>/dev/null
chmod 0755 "$BIN" 2>/dev/null

[ -x "$BIN" ] || { _log "致命: AaTempSpoof 不可执行"; exit 1; }

_sec "SERVICE"

_log "设备: $(getprop ro.product.model)"
_log "Android: $(getprop ro.build.version.release)"
_log "平台: $(getprop ro.board.platform)"
_bridge_log_environment

rm -f "$STOP_FLAG" "$FLAGFILE"

WAIT=0
while [ "$WAIT" -lt 120 ]; do
    [ "$(getprop sys.boot_completed)" = "1" ] && break
    sleep 5
    WAIT=$((WAIT + 5))
done

_log "等待 sysfs 热管理节点就绪..."
SYSFS_WAIT=0
while [ "$SYSFS_WAIT" -lt 30 ]; do
    if [ -e "/sys/class/thermal/thermal_zone0/emul_temp" ] || \
       [ -e "/sys/class/oplus_chg/battery/temp" ] || \
       [ -e "/sys/class/power_supply/battery/temp" ]; then
        break
    fi
    sleep 2
    SYSFS_WAIT=$((SYSFS_WAIT + 2))
done

BATT_WAIT=0
while [ "$BATT_WAIT" -lt 20 ]; do
    _v=$(cat /sys/class/power_supply/battery/temp 2>/dev/null)
    case "${_v:-0}" in
        [1-9]*|[-][1-9]*) break ;;
    esac
    sleep 2
    BATT_WAIT=$((BATT_WAIT + 2))
done
unset _v

if [ -w "$GAUGE_PATH" ]; then
    printf '0\n' > "$GAUGE_PATH" 2>/dev/null
    _log "内核电池温度伪装节点已复位"
fi
_clear_kernel_virtual_gauge
_clear_kernel_usb_therm
[ -d "$VIRTUAL_IC_ROOT" ] && _log "内核电池底层伪装节点已复位"

_log "系统就绪 (boot=${WAIT}s sysfs=${SYSFS_WAIT}s batt=${BATT_WAIT}s)"

CDMSFILE="$CFGDIR/cdms.txt"
(
    sleep 10
    if [ -f "$CDMSFILE" ] && [ "$(tr -d '[:space:]' < "$CDMSFILE" 2>/dev/null)" = "1" ]; then
        _log "cdms.txt=1，触发重置"
        printf '0' > "$CDMSFILE"
        sleep 1
        printf '1' > "$CDMSFILE"
        _log "cdms.txt 重触发完成"
    fi
) &

is_alive() {
    _pid_alive "$PIDFILE" --start
}

cb_alive() {
    _pid_alive "$CBPID" cb
}

touch_alive() {
    _pid_alive "$TOUCHPID" touch_daemon
}

tombstone_alive() {
    _pid_alive "$TOMBSTONEPID" color_tombstone
}

charge_alive() {
    _pid_alive "$CHARGEPID" charge_horae_daemon
}

app_user_ready() {
    local state
    state=$(getprop sys.user.0.ce_available 2>/dev/null | tr -d ' \r\n')
    case "$state" in
        true|1) return 0 ;;
        false|0) return 1 ;;
    esac
    dumpsys user 2>/dev/null \
        | grep -q 'Started users state:.*0=RUNNING_UNLOCKED'
}

app_device_charging() {
    local supply online type status
    status=$(tr -d '\r\n' < /sys/class/power_supply/battery/status 2>/dev/null)
    [ "$status" = "Full" ] && return 1
    for supply in /sys/class/power_supply/*; do
        [ -r "$supply/online" ] || continue
        online=$(tr -d ' \r\n' < "$supply/online" 2>/dev/null)
        [ "$online" = "1" ] || continue
        type=$(tr -d '\r\n' < "$supply/type" 2>/dev/null)
        case "$type" in
            Battery|BMS) ;;
            *) return 0 ;;
        esac
    done
    case "$status" in
        Charging) return 0 ;;
        *) return 1 ;;
    esac
}

app_live_enabled() {
    [ -r "$APP_PREF" ] || return 0
    grep -q 'name="enabled"[[:space:]]*value="false"' "$APP_PREF" 2>/dev/null \
        && return 1
    return 0
}

app_process_alive() {
    pidof "$APP_PACKAGE" >/dev/null 2>&1
}

app_service_alive() {
    app_process_alive || return 1
    dumpsys activity services "$APP_PACKAGE" 2>/dev/null \
        | grep -Fq 'ChargingLiveService'
}

start_charging_app() {
    local output
    output=$(/system/bin/am start-foreground-service --user 0 \
        -n "$APP_SERVICE" 2>&1)
    case "$output" in
        *Error:*|*Exception*|*"not found"*|*"not allowed"*) ;;
        *)
            app_service_alive && return 0
            sleep 1
            app_service_alive && return 0
            ;;
    esac

    /system/bin/am broadcast --user 0 --include-stopped-packages \
        -a android.intent.action.ACTION_POWER_CONNECTED \
        -n "$APP_PACKAGE/.ChargingPowerReceiver" >/dev/null 2>&1 || true
    sleep 1
    app_service_alive && return 0

    output=$(/system/bin/am start-foreground-service --user 0 \
        -n "$APP_SERVICE" 2>&1)
    case "$output" in
        *Error:*|*Exception*|*"not found"*|*"not allowed"*) ;;
        *)
            app_service_alive && return 0
            sleep 1
            app_service_alive && return 0
            ;;
    esac

    output=$(printf '%s' "$output" | tr '\r\n' ' ' | cut -c1-160)
    [ -n "$output" ] || output="服务未进入运行态"
    _log "⚠ 充电流体云应用拉起失败：$output"
    return 1
}

sync_charge_dual_cell() {
    local value current
    value=$(tr -d ' \r\n' < "$APP_DUAL_CELL_CONFIG" 2>/dev/null)
    [ "$value" = "1" ] || value=0
    mkdir -p "${APP_DUAL_CELL_RUNTIME%/*}" 2>/dev/null || return
    current=$(tr -d ' \r\n' < "$APP_DUAL_CELL_RUNTIME" 2>/dev/null)
    if [ "$current" != "$value" ]; then
        printf '%s\n' "$value" > "$APP_DUAL_CELL_RUNTIME" 2>/dev/null || return
        chmod 0644 "$APP_DUAL_CELL_RUNTIME" 2>/dev/null || true
    fi
}

app_hans_guard_alive() {
    local pid cmdline
    [ -s "$APP_HANS_PIDFILE" ] || return 1
    read pid < "$APP_HANS_PIDFILE"
    case "$pid" in ''|*[!0-9]*) return 1 ;; esac
    kill -0 "$pid" 2>/dev/null || return 1
    cmdline=$(tr '\000' ' ' < "/proc/$pid/cmdline" 2>/dev/null)
    printf '%s\n' "$cmdline" | grep -Fq 'com.aatempspoof.tile.RootHansGuard'
}

stop_app_hans_guard() {
    local pid
    if app_hans_guard_alive; then
        read pid < "$APP_HANS_PIDFILE"
        kill "$pid" 2>/dev/null || true
    fi
    rm -f "$APP_HANS_PIDFILE" "$APP_HANS_READY"
}

start_app_hans_guard() {
    local uid pid status wait_count
    app_hans_guard_alive && return 0
    [ "$APP_HANS_RETRY_BACKOFF" -le 0 ] || {
        APP_HANS_RETRY_BACKOFF=$((APP_HANS_RETRY_BACKOFF - 1))
        return 1
    }
    /system/bin/service check oplus_freeze 2>/dev/null \
        | grep -q 'found' || return 0
    [ -r "$APP_APK" ] || return 1

    uid=$(stat -c '%u' "/data/user/0/$APP_PACKAGE" 2>/dev/null)
    case "$uid" in ''|*[!0-9]*) return 1 ;; esac
    rm -f "$APP_HANS_PIDFILE" "$APP_HANS_READY"
    CLASSPATH="$APP_APK" /system/bin/app_process /system/bin \
        com.aatempspoof.tile.RootHansGuard \
        "$uid" "$APP_PACKAGE" "$APP_HANS_READY" >> "$LOG" 2>&1 &
    pid=$!
    printf '%s\n' "$pid" > "$APP_HANS_PIDFILE"
    wait_count=0
    status=
    while [ "$wait_count" -lt 4 ]; do
        status=$(tr -d ' \r\n' < "$APP_HANS_READY" 2>/dev/null)
        [ -n "$status" ] && break
        kill -0 "$pid" 2>/dev/null || break
        wait_count=$((wait_count + 1))
        sleep 1
    done
    if [ "$status" = "1" ] && app_hans_guard_alive; then
        _log "Oplus Hans 充电后台保护已启用 (PID=$pid)"
        APP_HANS_RETRY_BACKOFF=0
        return 0
    fi
    stop_app_hans_guard
    APP_HANS_RETRY_BACKOFF=15
    _log "⚠ Oplus Hans 充电后台保护启动失败 (${status:-无回调})"
    return 1
}

app_package_can_restart() {
    local package_state sdk
    pm path "$APP_PACKAGE" >/dev/null 2>&1 || return 1
    package_state=$(dumpsys package "$APP_PACKAGE" 2>/dev/null)

    sdk=$(getprop ro.build.version.sdk 2>/dev/null | tr -d ' \r\n')
    case "$sdk" in ''|*[!0-9]*) sdk=0 ;; esac
    if [ "$sdk" -ge 33 ]; then
        printf '%s\n' "$package_state" \
            | grep -q 'android.permission.POST_NOTIFICATIONS: granted=true' \
            || return 1
    fi
    return 0
}

ensure_charging_app() {
    app_user_ready || return
    if ! app_device_charging || ! app_live_enabled; then
        if [ "$APP_GUARD_ACTIVE" != "0" ]; then
            /system/bin/am stopservice --user 0 \
                -n "$APP_SERVICE" >/dev/null 2>&1
        fi
        stop_app_hans_guard
        APP_GUARD_ACTIVE=0
        APP_RESTART_BACKOFF=0
        return
    fi
    APP_GUARD_ACTIVE=1
    if app_service_alive; then
        APP_RESTART_BACKOFF=0
    else
        if [ "$APP_RESTART_BACKOFF" -gt 0 ]; then
            APP_RESTART_BACKOFF=$((APP_RESTART_BACKOFF - 1))
        elif ! app_package_can_restart; then
            APP_RESTART_BACKOFF=1
        elif start_charging_app; then
            _log "充电流体云服务缺失，已由 root 守护重新拉起"
            APP_RESTART_BACKOFF=0
        else
            APP_RESTART_BACKOFF=0
        fi
    fi
    start_app_hans_guard || true
}

publish_real_temp_node() {
    (
        local i
        i=0
        while [ "$i" -lt 15 ]; do
            if [ -d /dev/aatempspoof ]; then
                chmod 0711 /dev/aatempspoof 2>/dev/null
                chcon u:object_r:system_file:s0 /dev/aatempspoof 2>/dev/null || true
            fi
            if [ -f /dev/aatempspoof/real_batt_temp ]; then
                chmod 0644 /dev/aatempspoof/real_batt_temp 2>/dev/null
                chcon u:object_r:system_file:s0 \
                    /dev/aatempspoof/real_batt_temp 2>/dev/null || true
                return 0
            fi
            sleep 1
            i=$((i + 1))
        done
    ) &
}

start_daemon() {
    local i p try
    [ -x "$BIN" ] || { _log "AaTempSpoof 二进制不存在或不可执行"; return 1; }
    _start_blocked_by_status integrity && return 1
    is_alive && {
        p=$(_pid_value "$PIDFILE")
        _log "AaTempSpoof 已运行 PID=$p"
        publish_real_temp_node
        return 0
    }

    rm -f "$PIDFILE"
    for try in 1 2 3; do
        _log "启动 AaTempSpoof (${try}/3)"
        "$BIN" --start --moddir "$MODDIR" >/dev/null 2>&1
        _start_blocked_by_status && return 1
        if [ -f "$DONATION_SUSPEND_FLAG" ]; then
            _log "捐赠校验未通过且无72小时有效缓存，本次启动停止重试"
            return 1
        fi
        i=0
        while [ "$i" -lt 10 ]; do
            if is_alive; then
                touch "$FLAGFILE"
                p=$(_pid_value "$PIDFILE")
                _log "AaTempSpoof PID=$p"
                publish_real_temp_node
                return 0
            fi
            sleep 1
            i=$((i + 1))
        done
        _log "AaTempSpoof 第 ${try} 次启动后未确认到进程"
        sleep 2
    done
    _log "⚠ AaTempSpoof 未检测到"
    return 1
}

_start_bg() {
    local tool="$1"
    local pidfile="$2"
    local label="$3"
    local p try i

    [ -x "$BIN" ] || { _log "⚠ AaTempSpoof 不存在或不可执行，无法启动 $label"; return 0; }
    _pid_alive "$pidfile" "$tool" && { p=$(_pid_value "$pidfile"); _log "$label 已运行 PID=$p"; return 0; }

    rm -f "$pidfile"
    for try in 1 2 3; do
        _log "启动 $label (${try}/3)"
        "$BIN" "$tool" >/dev/null 2>&1 &
        p=$!
        i=0
        while [ "$i" -lt 8 ]; do
            if _pid_alive "$pidfile" "$tool"; then
                p=$(_pid_value "$pidfile")
                _log "$label PID=$p"
                return 0
            fi
            if [ "$i" -ge 2 ] && [ -n "$p" ] && kill -0 "$p" 2>/dev/null; then
                printf '%s\n' "$p" > "$pidfile" 2>/dev/null
                _log "$label PID=$p (shell)"
                return 0
            fi
            sleep 1
            i=$((i + 1))
        done
        _log "$label 第 ${try} 次启动后未确认到进程"
        sleep 2
    done
    _log "⚠ $label 未检测到"
    return 1
}

start_cb() {
    _start_bg cb "$CBPID" cb
}

start_touch() {
    _start_bg touch_daemon "$TOUCHPID" touch_daemon
}

start_tombstone() {
    _start_bg color_tombstone "$TOMBSTONEPID" color_tombstone
}

start_charge() {
    _start_bg charge_horae_daemon "$CHARGEPID" charge_horae_daemon
}

ensure_all() {
    local round ok
    _log "$1：检查所有功能进程"
    for round in 1 2 3; do
        ok=1
        if ! is_alive; then
            ok=0
            if ! start_daemon; then
                if [ -f "$DONATION_SUSPEND_FLAG" ]; then
                    _log "$1：捐赠授权暂停，等待下次模块启动重新校验"
                fi
                return 1
            fi
        fi
        if [ -f "$DONATION_SUSPEND_FLAG" ]; then
            _log "$1：捐赠授权暂停，等待下次模块启动重新校验"
            return 1
        fi
        cb_alive        || { ok=0; start_cb; }
        touch_alive     || { ok=0; start_touch; }
        tombstone_alive || { ok=0; start_tombstone; }
        charge_alive    || { ok=0; start_charge; }
        [ "$ok" = "1" ] && { _log "$1：所有功能进程已确认"; return 0; }
        sleep 3
    done
    _log "$1：仍有功能进程未确认，等待后续 watchdog"
    return 1
}

run_periodic_cloud_sync() {
    local p
    if [ -s "$CLOUDSYNCPID" ]; then
        read p < "$CLOUDSYNCPID"
        case "$p" in
            ''|*[!0-9]*) p= ;;
        esac
        [ -n "$p" ] && kill -0 "$p" 2>/dev/null && return 0
        rm -f "$CLOUDSYNCPID"
    fi
    (
        "$BIN" --periodic-cloud-sync >/dev/null 2>&1
        rc=$?
        rm -f "$CLOUDSYNCPID"
        if [ "$rc" -eq 0 ]; then
            _log "十分钟云端同步完成：捐赠授权与温度墙规则均已刷新"
            ensure_all "云端同步恢复"
        elif [ "$rc" -eq 2 ]; then
            _log "十分钟云端同步完成：设备ID明确不在最新捐赠名单"
        elif [ "$rc" -eq 3 ]; then
            _log "十分钟云端同步完成：授权缓存超过72小时，等待联网确认"
        else
            _log "十分钟云端同步暂未完成 (code=$rc)，保留当前可用状态"
        fi
    ) &
    printf '%s\n' "$!" > "$CLOUDSYNCPID"
}

USER_UNLOCK_WAIT=0
if ! app_user_ready; then
    _log "等待用户 0 解锁，暂不启动捐赠硬件证明校验"
fi
while ! app_user_ready; do
    sleep 2
    USER_UNLOCK_WAIT=$((USER_UNLOCK_WAIT + 2))
done
if [ "$USER_UNLOCK_WAIT" -gt 0 ]; then
    _log "用户 0 已解锁，继续启动模块 (${USER_UNLOCK_WAIT}s)"
fi

# Do not insert a kernel bridge while the system is still in the pre-unlock
# boot phase.  Some Android 16 vendor drivers finish registering their IC
# objects only after user 0 is unlocked; loading earlier can reset the device.
if [ "$OPBATT_BRIDGE_STABILIZE_SECONDS" -gt 0 ] 2>/dev/null; then
    _bridge_diag "event=stabilize_wait seconds=$OPBATT_BRIDGE_STABILIZE_SECONDS reason=post_unlock"
    sleep "$OPBATT_BRIDGE_STABILIZE_SECONDS"
fi
if load_opbatt_bridge; then
    start_opbatt_bridge_probation
fi

_sec "守护进程启动"
sync_charge_dual_cell
ensure_all "首次启动"

(sleep 20
 [ -f "$STOP_FLAG" ] && exit 0
 ensure_all "20s 二次确认"
 if [ -s "$PIDFILE" ]; then
     read _p < "$PIDFILE"
     kill -HUP "$_p" 2>/dev/null
     _log "20s SIGHUP 已发送 (PID=$_p)"
 fi
) &

if [ -f "$PIDDIR/hw" ]; then
    _log "检测到 hw 标记，禁用 HW 叠加层"
    service call SurfaceFlinger 1008 i32 1 >/dev/null 2>&1
fi

_sec "启动完成"

if [ -f "$NOTIFY_FILE" ]; then
    (
        _log "开始发送初始化通知"
        notify "$MODULE_NAME" "模块初始化加载中，预计15s加载完成"
        sleep 15
        notify "$MODULE_NAME" "模块加载完成，温控伪装挂载等已生效"
    ) &
else
    _log "通知文件不存在，跳过通知发送"
fi

renice 10 $$ >/dev/null 2>&1

FAIL=0
WATCHDOG_TICKS=0
CLOUD_SYNC_TICKS=0
MAIN_WAS_ALIVE=1
APP_GUARD_ACTIVE=
APP_RESTART_BACKOFF=0
APP_HANS_RETRY_BACKOFF=0

while true; do
    sleep 2

    sync_charge_dual_cell
    ensure_charging_app

    if is_alive; then
        MAIN_WAS_ALIVE=1
    elif [ "$MAIN_WAS_ALIVE" = "1" ]; then
        [ -w "$GAUGE_PATH" ] && printf '0\n' > "$GAUGE_PATH" 2>/dev/null
        _clear_kernel_virtual_gauge
        _clear_kernel_usb_therm
        MAIN_WAS_ALIVE=0
        _log "⚠ AaTempSpoof 异常退出，内核温度伪装已复位"
    fi

    WATCHDOG_TICKS=$((WATCHDOG_TICKS + 1))
    CLOUD_SYNC_TICKS=$((CLOUD_SYNC_TICKS + 1))
    if [ "$CLOUD_SYNC_TICKS" -ge 300 ]; then
        CLOUD_SYNC_TICKS=0
        run_periodic_cloud_sync
    fi
    [ "$WATCHDOG_TICKS" -lt 60 ] && continue
    WATCHDOG_TICKS=0

    [ -f "$STOP_FLAG" ] && continue
    [ -f "$DONATION_SUSPEND_FLAG" ] && continue
    [ -s "$INTEGRITY_STATUS_FILE" ] && continue

    if [ -f "$OPBATT_BRIDGE_DEFERRED" ] &&
       ! _opbatt_bridge_loaded && ! _opbatt_charger_online; then
        if load_opbatt_bridge; then
            start_opbatt_bridge_probation
        fi
    fi

    if ! is_alive; then
        FAIL=$((FAIL + 1))
        _log "⚠ AaTempSpoof 死亡 ($FAIL/5)"
        _clear_kernel_virtual_gauge
        _clear_kernel_usb_therm
        rm -f "$PIDFILE"
        start_daemon && FAIL=0
    else
        FAIL=0
    fi

    if ! cb_alive; then
        _log "⚠ cb 死亡"
        rm -f "$CBPID"
        start_cb
    fi

    if ! touch_alive; then
        _log "⚠ touch_daemon 死亡"
        rm -f "$TOUCHPID"
        start_touch
    fi

    if ! tombstone_alive; then
        _log "⚠ color_tombstone 死亡"
        rm -f "$TOMBSTONEPID"
        start_tombstone
    fi

    if ! charge_alive; then
        _log "⚠ charge_horae_daemon 死亡"
        rm -f "$CHARGEPID"
        start_charge
    fi

    if [ "$FAIL" -gt 5 ]; then
        _log "✗ AaTempSpoof 连续重启失败，延长等待后继续监控"
        sleep 300
        FAIL=0
    fi
done
