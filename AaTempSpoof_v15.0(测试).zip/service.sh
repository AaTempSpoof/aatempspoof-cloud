#!/system/bin/sh

MODDIR="${0%/*}"
BIN="$MODDIR/bin/AaTempSpoof"
GAUGE_PATH="/sys/module/oplus_chg_v2/parameters/gauge_dbg_tbat"
VIRTUAL_IC_ROOT="/sys/class/virtual_ic"
OPBATT_KO="/vendor_dlkm/lib/modules/oplus_chg_v2.ko"
OPBATT_BRIDGE_MANIFEST="$MODDIR/bin/kcompat/manifest.tsv"
OPBATT_BRIDGE_KO=
OPBATT_BRIDGE_RUNTIME_KO="$MODDIR/pid/opbatt_bridge.runtime.ko"
OPBATT_BRIDGE_DEVICE="/dev/aats_opbatt_bridge"
OPBATT_BRIDGE_MODULE="aats_opbatt_bridge"
OPBATT_BRIDGE_PROFILE=0
OPBATT_EXPECTED_SHA256=
OPBATT_EXPECTED_BUILD_ID=

CFGDIR="$MODDIR/bin/config/AaTempSpoof"
PIDDIR="$MODDIR/pid"
LOG="$CFGDIR/tempspoof.log"

mkdir -p "$CFGDIR" "$PIDDIR"

PIDFILE="$PIDDIR/daemon.pid"
CBPID="$PIDDIR/cb.pid"
TOUCHPID="$PIDDIR/touch_daemon.pid"
TOMBSTONEPID="$PIDDIR/color_tombstone.pid"
CHARGEPID="$PIDDIR/charge_horae_daemon.pid"
NOTIFY_FILE="$PIDDIR/通知"
DONATION_SUSPEND_FLAG="$PIDDIR/donation.suspended"
DONATION_STATUS_FILE="$PIDDIR/donation.status"
INTEGRITY_STATUS_FILE="$PIDDIR/integrity.status"
OPBATT_BRIDGE_STATUS_FILE="$PIDDIR/opbatt_bridge.status"
OPBATT_BRIDGE_LOADING_MARKER="$PIDDIR/opbatt_bridge.loading"
OPBATT_BRIDGE_QUARANTINE="$PIDDIR/opbatt_bridge.quarantine"
OPBATT_BRIDGE_DEFERRED="$PIDDIR/opbatt_bridge.deferred"
OPBATT_BRIDGE_DIAG_FILE="$PIDDIR/opbatt_bridge.diag"
OPBATT_BRIDGE_PROBATION_SECONDS=45
OPBATT_BRIDGE_STABILIZE_SECONDS=8
OPBATT_BRIDGE_MARKER_VERSION=2
OPBATT_BRIDGE_DIAG_MAX_BYTES=262144

OPBATT_ACTUAL_SHA256=
OPBATT_RELEASE=
OPBATT_MATCH_VERSION=
OPBATT_LAST_LOADER=
OPBATT_LAST_LOADER_RC=127
OPBATT_LAST_LOADER_OUTPUT=
OPBATT_KSUD_PATH=

FLAGFILE="$PIDDIR/fake_batt_temp"
STOP_FLAG="$CFGDIR/user_stopped"
APP_PACKAGE="com.aatempspoof.tile"
APP_SERVICE="$APP_PACKAGE/.ChargingLiveService"
APP_PREF="/data/user/0/$APP_PACKAGE/shared_prefs/charging_live.xml"
APP_APK="$MODDIR/bin/apk/AaTempSpoof.apk"
APP_DUAL_CELL_CONFIG="$CFGDIR/充电统计双电.txt"
APP_DUAL_CELL_RUNTIME="/dev/aatempspoof/charge_dual_cell"
APP_HANS_PIDFILE="$PIDDIR/app_hans_guard.pid"
APP_HANS_READY="$PIDDIR/app_hans_guard.ready"

_log() {
    printf '[%s] [service] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOG"
}

_bridge_clean_text() {
    printf '%s' "$*" | tr '\r\n' '  ' | cut -c1-600
}

_bridge_boot_id() {
    local id
    id=$(tr -d ' \r\n' < /proc/sys/kernel/random/boot_id 2>/dev/null)
    [ -n "$id" ] || id=$(getprop ro.boot.bootreason 2>/dev/null | tr -d ' \r\n')
    [ -n "$id" ] || id=unknown
    printf '%s' "$id"
}

_bridge_uptime() {
    awk '{printf "%.3f", $1}' /proc/uptime 2>/dev/null || printf 'unknown'
}

_bridge_diag() {
    local message timestamp size tmp
    message=$(_bridge_clean_text "$*")
    timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    printf '[%s] [opbatt_bridge] %s\n' "$timestamp" "$message" >> "$OPBATT_BRIDGE_DIAG_FILE" 2>/dev/null
    printf '[%s] [service] opbatt_bridge: %s\n' "$timestamp" "$message" >> "$LOG" 2>/dev/null
    size=$(wc -c < "$OPBATT_BRIDGE_DIAG_FILE" 2>/dev/null)
    case "$size" in ''|*[!0-9]*) size=0 ;; esac
    if [ "$size" -gt "$OPBATT_BRIDGE_DIAG_MAX_BYTES" ] 2>/dev/null; then
        tmp="$OPBATT_BRIDGE_DIAG_FILE.tmp.$$"
        tail -c $((OPBATT_BRIDGE_DIAG_MAX_BYTES / 2)) "$OPBATT_BRIDGE_DIAG_FILE" > "$tmp" 2>/dev/null &&
            mv -f "$tmp" "$OPBATT_BRIDGE_DIAG_FILE"
        rm -f "$tmp" 2>/dev/null
    fi
}

_bridge_marker_field() {
    local key="$1" file="$2"
    [ -r "$file" ] || return 1
    sed -n "s/^${key}=//p" "$file" 2>/dev/null | head -n 1
}

_bridge_marker_write() {
    local stage="$1" loader="${2:-none}" tmp
    tmp="$OPBATT_BRIDGE_LOADING_MARKER.tmp.$$"
    {
        printf 'marker_version=%s\n' "$OPBATT_BRIDGE_MARKER_VERSION"
        printf 'boot_id=%s\n' "$(_bridge_boot_id)"
        printf 'pid=%s\n' "$$"
        printf 'started_epoch=%s\n' "$(date +%s 2>/dev/null)"
        printf 'started_at=%s\n' "$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)"
        printf 'uptime=%s\n' "$(_bridge_uptime)"
        printf 'stage=%s\n' "$stage"
        printf 'profile=%s\n' "${OPBATT_BRIDGE_PROFILE:-0}"
        printf 'opbatt_sha256=%s\n' "${OPBATT_ACTUAL_SHA256:-unknown}"
        printf 'opbatt_version=%s\n' "${OPBATT_MATCH_VERSION:-unknown}"
        printf 'kernel_release=%s\n' "${OPBATT_RELEASE:-$(uname -r 2>/dev/null)}"
        printf 'loader=%s\n' "$loader"
        printf 'runtime_sha256=%s\n' "$(sha256sum "$OPBATT_BRIDGE_RUNTIME_KO" 2>/dev/null | awk '{print $1}')"
    } > "$tmp" 2>/dev/null || {
        rm -f "$tmp" 2>/dev/null
        return 1
    }
    chmod 0600 "$tmp" 2>/dev/null || true
    mv -f "$tmp" "$OPBATT_BRIDGE_LOADING_MARKER" 2>/dev/null || {
        rm -f "$tmp" 2>/dev/null
        return 1
    }
    sync
    _bridge_diag "event=marker stage=$stage profile=${OPBATT_BRIDGE_PROFILE:-0} loader=$loader boot_id=$(_bridge_boot_id)"
    return 0
}

_bridge_log_environment() {
    _bridge_diag "event=environment pid=$$ boot_id=$(_bridge_boot_id) uptime=$(_bridge_uptime) model=$(_bridge_clean_text "$(getprop ro.product.model 2>/dev/null)") platform=$(_bridge_clean_text "$(getprop ro.board.platform 2>/dev/null)") kernel=$(_bridge_clean_text "$(uname -r 2>/dev/null)")"
    _bridge_diag "event=boot_reason ro_boot_bootreason=$(_bridge_clean_text "$(getprop ro.boot.bootreason 2>/dev/null)") sys_boot_reason=$(_bridge_clean_text "$(getprop sys.boot.reason 2>/dev/null)")"
    _bridge_diag "event=loader_paths path_insmod=$(_bridge_clean_text "$(command -v insmod 2>/dev/null)") path_ksud=$(_bridge_clean_text "$(command -v ksud 2>/dev/null)") system_insmod=$([ -x /system/bin/insmod ] && printf yes || printf no) vendor_insmod=$([ -x /vendor/bin/insmod ] && printf yes || printf no)"
    for _AATS_PSTORE_DIR in /sys/fs/pstore /data/pstore; do
        [ -d "$_AATS_PSTORE_DIR" ] || continue
        for _AATS_PSTORE_FILE in "$_AATS_PSTORE_DIR"/*; do
            [ -r "$_AATS_PSTORE_FILE" ] || continue
            _bridge_diag "event=pstore file=$_AATS_PSTORE_FILE size=$(wc -c < "$_AATS_PSTORE_FILE" 2>/dev/null) matches=$(_bridge_clean_text "$(grep -iE 'aats[_-]opbatt|oplus_chg_v2|watchdog|panic|oops|fatal' "$_AATS_PSTORE_FILE" 2>/dev/null | tail -n 3)")"
        done
    done
}

_sec() {
    local _ts
    _ts=$(date '+%Y-%m-%d %H:%M:%S')
    printf '\n' >> "$LOG"
    printf '[%s] [service] ┌─────────────────────────────────────┐\n' "$_ts" >> "$LOG"
    printf '[%s] [service] │  %-35s│\n' "$_ts" "$1" >> "$LOG"
    printf '[%s] [service] └─────────────────────────────────────┘\n' "$_ts" >> "$LOG"
}

_trim_pid() {
    tr -d ' \r\n' 2>/dev/null
}

_umount_all() {
    local I
    [ -n "$1" ] || return
    I=0
    while [ "$I" -lt 8 ]; do
        umount -l "$1" >/dev/null 2>&1 || break
        I=$((I + 1))
    done
}

_clear_kernel_virtual_gauge() {
    local D NAME FUNCS FUNC OLD
    if [ -c "$OPBATT_BRIDGE_DEVICE" ]; then
        "$BIN" --opbatt-bridge-clear-all >/dev/null 2>&1 || true
        return
    fi
    for D in "$VIRTUAL_IC_ROOT"/vic-*; do
        [ -r "$D/name" ] || continue
        NAME=$(tr -d '\r\n' < "$D/name" 2>/dev/null)
        case "$NAME" in
            oplus,virtual_gauge|oplus,adsp_gauge) FUNCS="405 448" ;;
            oplus,virtual_buck|oplus,pm8550_charger) FUNCS="509 510 527 528 532" ;;
            oplus,adsp_mos|oplus,ufcs_virtual_cp) FUNCS="315" ;;
            *) continue ;;
        esac
        [ -w "$D/func_id" ] && [ -w "$D/clean_overwrite" ] || continue
        OLD=$(tr -d ' \r\n' < "$D/func_id" 2>/dev/null)
        case "$OLD" in ''|*[!0-9-]*) continue ;; esac
        for FUNC in $FUNCS; do
            printf '%s\n' "$FUNC" > "$D/func_id" 2>/dev/null || continue
            printf '1\n' > "$D/clean_overwrite" 2>/dev/null
        done
        printf '%s\n' "$OLD" > "$D/func_id" 2>/dev/null
    done
}

_bridge_status() {
    mkdir -p "$PIDDIR" 2>/dev/null
    printf 'ready=%s\nprofile=%s\nreason=%s\n' \
        "$1" "$2" "$3" > "$OPBATT_BRIDGE_STATUS_FILE" 2>/dev/null
    chmod 0600 "$OPBATT_BRIDGE_STATUS_FILE" 2>/dev/null || true
}

_bridge_try_loader() {
    local label="$1" output rc
    shift
    OPBATT_LAST_LOADER="$label"
    OPBATT_LAST_LOADER_RC=127
    OPBATT_LAST_LOADER_OUTPUT=
    if ! _bridge_marker_write loading "$label"; then
        OPBATT_LAST_LOADER_RC=125
        OPBATT_LAST_LOADER_OUTPUT="无法持久化加载器标记"
        _bridge_diag "event=loader_abort tool=$label reason=marker_write_failed"
        return 125
    fi
    _bridge_diag "event=loader_begin tool=$label command=$(_bridge_clean_text "$*")"
    sync
    output=$("$@" 2>&1)
    rc=$?
    output=$(_bridge_clean_text "$output")
    OPBATT_LAST_LOADER_RC=$rc
    OPBATT_LAST_LOADER_OUTPUT="$output"
    _bridge_diag "event=loader_attempt tool=$label rc=$rc output=${output:-none}"
    return "$rc"
}

_bridge_detect_ksud_loader() {
    local tool help
    OPBATT_KSUD_PATH=
    tool=$(command -v ksud 2>/dev/null)
    [ -n "$tool" ] && [ -x "$tool" ] || return 1
    help=$("$tool" --help 2>&1)
    printf '%s\n' "$help" | grep -Eq '(^|[[:space:]])insmod([[:space:]]|$)' || return 1
    OPBATT_KSUD_PATH="$tool"
    return 0
}

_opbatt_bridge_loaded() {
    grep -q "^${OPBATT_BRIDGE_MODULE} " /proc/modules 2>/dev/null
}

_opbatt_charger_online() {
    local supply online type status
    for supply in /sys/class/power_supply/*; do
        [ -r "$supply/online" ] || continue
        online=$(tr -d ' \r\n' < "$supply/online" 2>/dev/null)
        [ "$online" = "1" ] || continue
        type=$(tr -d '\r\n' < "$supply/type" 2>/dev/null)
        case "$type" in Battery|BMS) ;; *) return 0 ;; esac
    done
    status=$(tr -d '\r\n' < /sys/class/power_supply/battery/status 2>/dev/null)
    [ "$status" = "Charging" ]
}

_select_opbatt_bridge() {
    local actual_sha release profile marker version sha build module extra
    [ -r "$OPBATT_BRIDGE_MANIFEST" ] || return 1
    actual_sha=$(sha256sum "$OPBATT_KO" 2>/dev/null | awk '{print $1}')
    release=$(uname -r 2>/dev/null)
    OPBATT_ACTUAL_SHA256="$actual_sha"
    OPBATT_RELEASE="$release"
    OPBATT_MATCH_VERSION=
    OPBATT_BRIDGE_PROFILE=0
    OPBATT_BRIDGE_KO=
    OPBATT_EXPECTED_SHA256=
    OPBATT_EXPECTED_BUILD_ID=
    _bridge_diag "event=select_start opbatt_sha=$actual_sha kernel_release=$release manifest=$OPBATT_BRIDGE_MANIFEST"
    while IFS="$(printf '\t')" read -r profile marker version sha build module extra; do
        case "$profile" in ''|'#'*) continue ;; *[!0-9]*) continue ;; esac
        [ -z "$extra" ] || continue
        [ "$sha" = "$actual_sha" ] || continue
        case "$release" in $marker) ;; *) continue ;; esac
        case "$module" in ''|*[!A-Za-z0-9._-]*) continue ;; esac
        OPBATT_BRIDGE_PROFILE=$profile
        OPBATT_EXPECTED_SHA256=$sha
        OPBATT_EXPECTED_BUILD_ID=$build
        OPBATT_MATCH_VERSION=$version
        OPBATT_BRIDGE_KO="$MODDIR/bin/kcompat/$module"
        _bridge_diag "event=select_match profile=$profile version=$version module=$module expected_build=$build"
        return 0
    done < "$OPBATT_BRIDGE_MANIFEST"
    _bridge_diag "event=select_no_match opbatt_sha=$actual_sha kernel_release=$release"
    return 1
}

_opbatt_bridge_profile_state() {
    case "$1" in
        15086501|15087501|15087502|15088503) printf 'verified\n' ;;
        *) printf 'candidate\n' ;;
    esac
}

_bridge_insmod() {
    local resolved tool rc attempted
    OPBATT_LAST_LOADER=
    OPBATT_LAST_LOADER_RC=127
    OPBATT_LAST_LOADER_OUTPUT=
    attempted=0
    if _bridge_detect_ksud_loader; then
        attempted=1
        _bridge_try_loader "ksud insmod:$OPBATT_KSUD_PATH" \
            "$OPBATT_KSUD_PATH" insmod "$@"
        rc=$?
        if [ "$rc" -eq 0 ] || _opbatt_bridge_loaded; then
            return 0
        fi
        _bridge_diag "event=loader_fallback from=ksud rc=$rc next=path_insmod"
    fi

    resolved=$(command -v insmod 2>/dev/null)
    if [ -n "$resolved" ] && [ -x "$resolved" ]; then
        attempted=1
        _bridge_try_loader "path:$resolved" "$resolved" "$@"
        rc=$?
        if [ "$rc" -eq 0 ] || _opbatt_bridge_loaded; then
            return 0
        fi
        _bridge_diag "event=loader_fallback from=$resolved rc=$rc next=system_vendor"
    fi
    for tool in /system/bin/insmod /vendor/bin/insmod; do
        [ -x "$tool" ] || continue
        [ "$tool" = "$resolved" ] && continue
        attempted=1
        _bridge_try_loader "path:$tool" "$tool" "$@"
        rc=$?
        if [ "$rc" -eq 0 ] || _opbatt_bridge_loaded; then
            return 0
        fi
        _bridge_diag "event=loader_fallback from=$tool rc=$rc next=remaining"
    done

    if [ "$attempted" -eq 0 ]; then
        OPBATT_LAST_LOADER="none"
        OPBATT_LAST_LOADER_RC=127
        OPBATT_LAST_LOADER_OUTPUT="未找到可用的内核模块加载器"
        _bridge_diag "event=loader_missing"
    fi
    return "$OPBATT_LAST_LOADER_RC"
}

_bridge_rmmod() {
    if command -v rmmod >/dev/null 2>&1; then
        rmmod "$OPBATT_BRIDGE_MODULE"
    elif [ -x /system/bin/rmmod ]; then
        /system/bin/rmmod "$OPBATT_BRIDGE_MODULE"
    else
        return 127
    fi
}

_bridge_healthcheck() {
    local i output rc max_wait
    max_wait="${1:-10}"
    case "$max_wait" in ''|*[!0-9]*) max_wait=10 ;; esac
    i=0
    while [ "$i" -lt "$max_wait" ] && [ ! -c "$OPBATT_BRIDGE_DEVICE" ]; do
        sleep 1
        i=$((i + 1))
    done
    if [ ! -c "$OPBATT_BRIDGE_DEVICE" ]; then
        _bridge_diag "event=healthcheck device=missing waited=${i}s max_wait=${max_wait}s"
        return 1
    fi
    output=$("$BIN" --opbatt-bridge-status 2>&1)
    rc=$?
    output=$(_bridge_clean_text "$output")
    if [ "$rc" -eq 0 ]; then
        "$BIN" --opbatt-bridge-status > "$OPBATT_BRIDGE_STATUS_FILE.tmp" 2>/dev/null || true
        if [ -s "$OPBATT_BRIDGE_STATUS_FILE.tmp" ]; then
            mv -f "$OPBATT_BRIDGE_STATUS_FILE.tmp" "$OPBATT_BRIDGE_STATUS_FILE"
            chmod 0600 "$OPBATT_BRIDGE_STATUS_FILE" 2>/dev/null || true
        else
            rm -f "$OPBATT_BRIDGE_STATUS_FILE.tmp"
        fi
        _bridge_diag "event=healthcheck result=ok status=${output:-none}"
        return 0
    fi
    rm -f "$OPBATT_BRIDGE_STATUS_FILE.tmp"
    _bridge_diag "event=healthcheck result=fail rc=$rc output=${output:-none}"
    return "$rc"
}

_bridge_handle_loading_marker() {
    local marker_boot marker_stage marker_pid marker_epoch now age current_boot i
    marker_boot=$(_bridge_marker_field boot_id "$OPBATT_BRIDGE_LOADING_MARKER")
    marker_stage=$(_bridge_marker_field stage "$OPBATT_BRIDGE_LOADING_MARKER")
    marker_pid=$(_bridge_marker_field pid "$OPBATT_BRIDGE_LOADING_MARKER")
    marker_epoch=$(_bridge_marker_field started_epoch "$OPBATT_BRIDGE_LOADING_MARKER")
    current_boot=$(_bridge_boot_id)
    now=$(date +%s 2>/dev/null)
    age=unknown
    case "$marker_epoch:$now" in
        ''|*:*[!0-9]*) ;;
        *) [ "$now" -ge "$marker_epoch" ] 2>/dev/null && age=$((now - marker_epoch)) ;;
    esac
    _bridge_diag "event=stale_marker marker_boot=${marker_boot:-legacy} current_boot=$current_boot marker_pid=${marker_pid:-unknown} stage=${marker_stage:-unknown} age=${age}s file=$OPBATT_BRIDGE_LOADING_MARKER"

    # If another service instance is still completing the same-boot attempt,
    # give it a short window to publish the device instead of quarantining it.
    if [ -n "$marker_boot" ] && [ "$marker_boot" = "$current_boot" ]; then
        _bridge_diag "event=stale_marker_same_boot action=wait timeout=12s"
        i=0
        while [ "$i" -lt 12 ]; do
            if _bridge_healthcheck 1; then
                rm -f "$OPBATT_BRIDGE_LOADING_MARKER" "$OPBATT_BRIDGE_QUARANTINE"
                _bridge_diag "event=stale_marker_recovered action=clear"
                _log "opbatt 内核桥接已由同一启动周期的加载实例恢复"
                return 0
            fi
            sleep 1
            i=$((i + 1))
        done
    else
        _bridge_diag "event=stale_marker_after_reboot action=quarantine"
    fi

    mv -f "$OPBATT_BRIDGE_LOADING_MARKER" \
        "$OPBATT_BRIDGE_QUARANTINE" 2>/dev/null ||
        touch "$OPBATT_BRIDGE_QUARANTINE"
    _bridge_status 0 "$OPBATT_BRIDGE_PROFILE" "上次加载未完成，已隔离以避免重复重启"
    _bridge_diag "event=quarantine reason=incomplete_load marker_stage=${marker_stage:-unknown}"
    _log "⚠ opbatt 内核桥接上次加载未完成，本次已跳过"
    return 1
}

load_opbatt_bridge() {
    local release output rc profile_state
    _bridge_diag "event=load_enter loaded=$(_opbatt_bridge_loaded && printf yes || printf no) charger=$(_opbatt_charger_online && printf yes || printf no)"

    if _opbatt_bridge_loaded; then
        if _bridge_healthcheck; then
            rm -f "$OPBATT_BRIDGE_LOADING_MARKER" "$OPBATT_BRIDGE_QUARANTINE"
            _log "opbatt 内核桥接已在运行"
            return 0
        fi
        _bridge_status 0 "$OPBATT_BRIDGE_PROFILE" "模块已加载但设备状态异常"
        _bridge_diag "event=loaded_unhealthy action=stop"
        return 1
    fi

    if [ -f "$OPBATT_BRIDGE_LOADING_MARKER" ]; then
        _bridge_handle_loading_marker && return 0
        return 1
    fi
    if [ -f "$OPBATT_BRIDGE_QUARANTINE" ]; then
        _bridge_status 0 "$OPBATT_BRIDGE_PROFILE" "安全隔离中，重新刷入测试包后再试"
        _bridge_diag "event=quarantine_active action=skip"
        return 1
    fi
    [ -r "$OPBATT_KO" ] || {
        _bridge_status 0 0 "未找到 oplus_chg_v2.ko"
        _bridge_diag "event=select_fail reason=opbatt_missing path=$OPBATT_KO"
        return 1
    }
    if ! _select_opbatt_bridge; then
        _bridge_status 0 0 "opbatt 内核文件不在 15.0 已验证范围"
        _log "opbatt 内核桥接未加载：opbatt SHA 或 KMI 未匹配"
        return 1
    fi
    profile_state=$(_opbatt_bridge_profile_state "$OPBATT_BRIDGE_PROFILE")
    if [ "$profile_state" != verified ]; then
        rm -f "$OPBATT_BRIDGE_DEFERRED" 2>/dev/null || true
        if [ "$profile_state" = blocked ]; then
            _bridge_status 0 "$OPBATT_BRIDGE_PROFILE" "6.6 内核桥接已禁止自动加载，请先导出兼容诊断"
        else
            _bridge_status 0 "$OPBATT_BRIDGE_PROFILE" "该内核桥接尚未完成实机验证，请先导出兼容诊断"
        fi
        _bridge_diag "event=autoload_blocked profile=$OPBATT_BRIDGE_PROFILE state=$profile_state"
        _log "opbatt 内核桥接未自动加载：profile=$OPBATT_BRIDGE_PROFILE state=$profile_state"
        return 1
    fi
    [ -r "$OPBATT_BRIDGE_KO" ] || {
        _bridge_status 0 "$OPBATT_BRIDGE_PROFILE" "桥接内核模块不存在"
        _bridge_diag "event=select_fail reason=bridge_ko_missing path=$OPBATT_BRIDGE_KO"
        return 1
    }
    release="${OPBATT_RELEASE:-$(uname -r 2>/dev/null)}"
    if _opbatt_charger_online; then
        touch "$OPBATT_BRIDGE_DEFERRED" 2>/dev/null || true
        _bridge_status 0 "$OPBATT_BRIDGE_PROFILE" "等待断开充电器后安全加载"
        _bridge_diag "event=load_deferred reason=charger_online profile=$OPBATT_BRIDGE_PROFILE"
        return 1
    fi
    rm -f "$OPBATT_BRIDGE_DEFERRED" "$OPBATT_BRIDGE_RUNTIME_KO" "$OPBATT_BRIDGE_LOADING_MARKER.tmp.$$"
    _bridge_diag "event=prepare_start profile=$OPBATT_BRIDGE_PROFILE source=$OPBATT_BRIDGE_KO release=$release"
    output=$("$BIN" --prepare-opbatt-bridge "$OPBATT_BRIDGE_KO" \
        "$OPBATT_BRIDGE_RUNTIME_KO" "$release" 2>&1)
    rc=$?
    output=$(_bridge_clean_text "$output")
    if [ "$rc" -ne 0 ]; then
        _bridge_status 0 "$OPBATT_BRIDGE_PROFILE" "桥接内核模块运行时匹配失败"
        _bridge_diag "event=prepare_fail rc=$rc output=${output:-none}"
        _log "⚠ opbatt 内核桥接 vermagic 匹配失败：${output:-未知错误}"
        return 1
    fi
    _bridge_diag "event=prepare_ok runtime_sha=$(sha256sum "$OPBATT_BRIDGE_RUNTIME_KO" 2>/dev/null | awk '{print $1}')"
    _bridge_marker_write prepared none || {
        _bridge_status 0 "$OPBATT_BRIDGE_PROFILE" "无法写入桥接加载标记"
        _bridge_diag "event=marker_fail stage=prepared"
        return 1
    }
    _bridge_insmod "$OPBATT_BRIDGE_RUNTIME_KO" \
        "target_profile=$OPBATT_BRIDGE_PROFILE"
    rc=$?
    output=$(_bridge_clean_text "$OPBATT_LAST_LOADER_OUTPUT")
    if [ "$rc" -ne 0 ]; then
        rm -f "$OPBATT_BRIDGE_LOADING_MARKER"
        _bridge_status 0 "$OPBATT_BRIDGE_PROFILE" "${output:-加载失败}"
        _bridge_diag "event=insmod_fail rc=$rc tool=${OPBATT_LAST_LOADER:-unknown} output=${output:-none}"
        _log "⚠ opbatt 内核桥接加载失败：${output:-未知错误}"
        return 1
    fi
    _bridge_diag "event=insmod_ok tool=${OPBATT_LAST_LOADER:-unknown}"
    _bridge_marker_write loaded "${OPBATT_LAST_LOADER:-unknown}" ||
        _bridge_diag "event=marker_fail stage=loaded"
    if ! _bridge_healthcheck; then
        _bridge_rmmod >/dev/null 2>&1 || true
        rm -f "$OPBATT_BRIDGE_LOADING_MARKER" "$OPBATT_BRIDGE_STATUS_FILE.tmp"
        _bridge_status 0 "$OPBATT_BRIDGE_PROFILE" "加载后健康检查失败"
        _bridge_diag "event=load_fail stage=healthcheck action=unload"
        _log "⚠ opbatt 内核桥接加载后健康检查失败，已卸载"
        return 1
    fi
    _bridge_marker_write probation "${OPBATT_LAST_LOADER:-unknown}" ||
        _bridge_diag "event=marker_fail stage=probation"
    _log "opbatt 8.2.8.1 内核桥接已进入安全观察期 (profile=$OPBATT_BRIDGE_PROFILE loader=${OPBATT_LAST_LOADER:-unknown})"
    return 0
}

start_opbatt_bridge_probation() {
    [ -f "$OPBATT_BRIDGE_LOADING_MARKER" ] || return 0
    _bridge_diag "event=probation_start seconds=$OPBATT_BRIDGE_PROBATION_SECONDS"
    (
        sleep "$OPBATT_BRIDGE_PROBATION_SECONDS"
        if [ ! -f "$OPBATT_BRIDGE_LOADING_MARKER" ]; then
            _bridge_diag "event=probation_end result=marker_missing"
            exit 0
        fi
        if _opbatt_bridge_loaded && _bridge_healthcheck; then
            rm -f "$OPBATT_BRIDGE_LOADING_MARKER"
            sync
            _bridge_diag "event=probation_end result=pass action=clear_marker"
            _log "opbatt 内核桥接安全观察通过"
        else
            rm -f "$OPBATT_BRIDGE_STATUS_FILE.tmp"
            _bridge_diag "event=probation_end result=fail action=retain_marker"
            _log "⚠ opbatt 内核桥接安全观察未通过，保留隔离标记"
        fi
    ) &
}

_clear_kernel_usb_therm() {
    local Z TYPE LABEL_PATH LABEL INPUT NAME
    for Z in /sys/class/thermal/thermal_zone*; do
        [ -r "$Z/type" ] || continue
        TYPE=$(tr '[:upper:]-' '[:lower:]_' < "$Z/type" 2>/dev/null | tr -d '\r\n')
        case "$TYPE" in
            usb|*usb_therm*|*svooc_mos_btb*)
                [ -w "$Z/emul_temp" ] && printf '0\n' > "$Z/emul_temp" 2>/dev/null
                _umount_all "$Z/temp"
                ;;
        esac
    done

    for LABEL_PATH in /sys/bus/iio/devices/iio:device*/in_temp_*_label; do
        [ -r "$LABEL_PATH" ] || continue
        LABEL=$(tr '[:upper:]-' '[:lower:]_' < "$LABEL_PATH" 2>/dev/null | tr -d '\r\n')
        case "$LABEL" in
            *usb_therm*|*svooc_mos_btb*)
                INPUT=${LABEL_PATH%_label}_input
                [ -e "$INPUT" ] && _umount_all "$INPUT"
                ;;
        esac
    done

    for INPUT in /sys/bus/iio/devices/iio:device*/in_temp_*usb*therm*_input \
                 /sys/bus/iio/devices/iio:device*/in_temp_*svooc_mos_btb*_input; do
        [ -e "$INPUT" ] || continue
        NAME=$(printf '%s' "${INPUT##*/}" | tr '[:upper:]-' '[:lower:]_')
        case "$NAME" in
            *usb_therm*|*svooc_mos_btb*) _umount_all "$INPUT" ;;
        esac
    done
}

_pid_alive() {
    local p expected cmd
    [ -s "$1" ] || return 1
    expected="$2"
    p=$(cat "$1" 2>/dev/null | _trim_pid)
    case "$p" in
        ''|*[!0-9]*) rm -f "$1" 2>/dev/null; return 1 ;;
    esac
    if kill -0 "$p" 2>/dev/null && [ -r "/proc/$p/cmdline" ]; then
        cmd=$(tr '\0' ' ' < "/proc/$p/cmdline" 2>/dev/null)
        case "$cmd" in
            *"$BIN"*)
                if [ -z "$expected" ]; then
                    return 0
                fi
                case "$cmd" in *"$expected"*) return 0 ;; esac
                ;;
        esac
    fi
    rm -f "$1" 2>/dev/null
    return 1
}

_pid_value() {
    cat "$1" 2>/dev/null | _trim_pid
}

_runtime_status_reason() {
    [ -s "$1" ] || return 1
    tr '\r\n' ' ' < "$1" 2>/dev/null | cut -c1-240
}

_start_blocked_by_status() {
    local reason
    reason=$(_runtime_status_reason "$INTEGRITY_STATUS_FILE")
    if [ -n "$reason" ]; then
        _log "模块完整性校验失败，停止启动辅助进程：$reason"
        return 0
    fi
    [ "$1" = "integrity" ] && return 1
    reason=$(_runtime_status_reason "$DONATION_STATUS_FILE")
    if [ -n "$reason" ]; then
        _log "捐赠授权校验失败，停止启动辅助进程：$reason"
        return 0
    fi
    return 1
}

MODULE_NAME=$(grep "^name=" "$MODDIR/module.prop" 2>/dev/null | cut -d= -f2)
[ -z "$MODULE_NAME" ] && MODULE_NAME="模块加载失败"

notify() {
    su 2000 -c "cmd notification post -S bigtext -t \"$1\" tempspoof_action \"$2\"" 2>/dev/null
    _log "通知发送: 标题=\"$1\", 内容=\"$2\""
}

if [ -f "$LOG" ] && [ "$(wc -c < "$LOG")" -gt 1048576 ]; then
    tail -c 65536 "$LOG" > "${LOG}.tmp"
    mv "${LOG}.tmp" "$LOG"
fi

touch "$LOG" 2>/dev/null
chmod 0755 "$BIN" 2>/dev/null

[ -x "$BIN" ] || { _log "致命: AaTempSpoof 不可执行"; exit 1; }

_sec "SERVICE"

_log "设备: $(getprop ro.product.model)"
_log "Android: $(getprop ro.build.version.release)"
_log "平台: $(getprop ro.board.platform)"
_bridge_log_environment

rm -f "$STOP_FLAG" "$FLAGFILE"

WAIT=0
while [ "$WAIT" -lt 120 ]; do
    [ "$(getprop sys.boot_completed)" = "1" ] && break
    sleep 5
    WAIT=$((WAIT + 5))
done

_log "等待 sysfs 热管理节点就绪..."
SYSFS_WAIT=0
while [ "$SYSFS_WAIT" -lt 30 ]; do
    if [ -e "/sys/class/thermal/thermal_zone0/emul_temp" ] || \
       [ -e "/sys/class/oplus_chg/battery/temp" ] || \
       [ -e "/sys/class/power_supply/battery/temp" ]; then
        break
    fi
    sleep 2
    SYSFS_WAIT=$((SYSFS_WAIT + 2))
done

BATT_WAIT=0
while [ "$BATT_WAIT" -lt 20 ]; do
    _v=$(cat /sys/class/power_supply/battery/temp 2>/dev/null)
    case "${_v:-0}" in
        [1-9]*|[-][1-9]*) break ;;
    esac
    sleep 2
    BATT_WAIT=$((BATT_WAIT + 2))
done
unset _v

if [ -w "$GAUGE_PATH" ]; then
    printf '0\n' > "$GAUGE_PATH" 2>/dev/null
    _log "内核电池温度伪装节点已复位"
fi
_clear_kernel_virtual_gauge
_clear_kernel_usb_therm
[ -d "$VIRTUAL_IC_ROOT" ] && _log "内核电池底层伪装节点已复位"

_log "系统就绪 (boot=${WAIT}s sysfs=${SYSFS_WAIT}s batt=${BATT_WAIT}s)"

CDMSFILE="$CFGDIR/cdms.txt"
(
    sleep 10
    if [ -f "$CDMSFILE" ] && [ "$(tr -d '[:space:]' < "$CDMSFILE" 2>/dev/null)" = "1" ]; then
        _log "cdms.txt=1，触发重置"
        printf '0' > "$CDMSFILE"
        sleep 1
        printf '1' > "$CDMSFILE"
        _log "cdms.txt 重触发完成"
    fi
) &

is_alive() {
    _pid_alive "$PIDFILE" --start
}

cb_alive() {
    _pid_alive "$CBPID" cb
}

touch_alive() {
    _pid_alive "$TOUCHPID" touch_daemon
}

tombstone_alive() {
    _pid_alive "$TOMBSTONEPID" color_tombstone
}

charge_alive() {
    _pid_alive "$CHARGEPID" charge_horae_daemon
}

app_user_ready() {
    local state
    state=$(getprop sys.user.0.ce_available 2>/dev/null | tr -d ' \r\n')
    case "$state" in
        true|1) return 0 ;;
        false|0) return 1 ;;
    esac
    dumpsys user 2>/dev/null \
        | grep -q 'Started users state:.*0=RUNNING_UNLOCKED'
}

app_device_charging() {
    local supply online type status
    status=$(tr -d '\r\n' < /sys/class/power_supply/battery/status 2>/dev/null)
    [ "$status" = "Full" ] && return 1
    for supply in /sys/class/power_supply/*; do
        [ -r "$supply/online" ] || continue
        online=$(tr -d ' \r\n' < "$supply/online" 2>/dev/null)
        [ "$online" = "1" ] || continue
        type=$(tr -d '\r\n' < "$supply/type" 2>/dev/null)
        case "$type" in
            Battery|BMS) ;;
            *) return 0 ;;
        esac
    done
    case "$status" in
        Charging) return 0 ;;
        *) return 1 ;;
    esac
}

app_live_enabled() {
    [ -r "$APP_PREF" ] || return 0
    grep -q 'name="enabled"[[:space:]]*value="false"' "$APP_PREF" 2>/dev/null \
        && return 1
    return 0
}

app_process_alive() {
    pidof "$APP_PACKAGE" >/dev/null 2>&1
}

app_service_alive() {
    app_process_alive || return 1
    dumpsys activity services "$APP_PACKAGE" 2>/dev/null \
        | grep -Fq 'ChargingLiveService'
}

start_charging_app() {
    local output
    output=$(/system/bin/am start-foreground-service --user 0 \
        -n "$APP_SERVICE" 2>&1)
    case "$output" in
        *Error:*|*Exception*|*"not found"*|*"not allowed"*) ;;
        *)
            app_service_alive && return 0
            sleep 1
            app_service_alive && return 0
            ;;
    esac

    /system/bin/am broadcast --user 0 --include-stopped-packages \
        -a android.intent.action.ACTION_POWER_CONNECTED \
        -n "$APP_PACKAGE/.ChargingPowerReceiver" >/dev/null 2>&1 || true
    sleep 1
    app_service_alive && return 0

    output=$(/system/bin/am start-foreground-service --user 0 \
        -n "$APP_SERVICE" 2>&1)
    case "$output" in
        *Error:*|*Exception*|*"not found"*|*"not allowed"*) ;;
        *)
            app_service_alive && return 0
            sleep 1
            app_service_alive && return 0
            ;;
    esac

    output=$(printf '%s' "$output" | tr '\r\n' ' ' | cut -c1-160)
    [ -n "$output" ] || output="服务未进入运行态"
    _log "⚠ 充电流体云应用拉起失败：$output"
    return 1
}

sync_charge_dual_cell() {
    local value current
    value=$(tr -d ' \r\n' < "$APP_DUAL_CELL_CONFIG" 2>/dev/null)
    [ "$value" = "1" ] || value=0
    mkdir -p "${APP_DUAL_CELL_RUNTIME%/*}" 2>/dev/null || return
    current=$(tr -d ' \r\n' < "$APP_DUAL_CELL_RUNTIME" 2>/dev/null)
    if [ "$current" != "$value" ]; then
        printf '%s\n' "$value" > "$APP_DUAL_CELL_RUNTIME" 2>/dev/null || return
        chmod 0644 "$APP_DUAL_CELL_RUNTIME" 2>/dev/null || true
    fi
}

app_hans_guard_alive() {
    local pid cmdline
    [ -s "$APP_HANS_PIDFILE" ] || return 1
    read pid < "$APP_HANS_PIDFILE"
    case "$pid" in ''|*[!0-9]*) return 1 ;; esac
    kill -0 "$pid" 2>/dev/null || return 1
    cmdline=$(tr '\000' ' ' < "/proc/$pid/cmdline" 2>/dev/null)
    printf '%s\n' "$cmdline" | grep -Fq 'com.aatempspoof.tile.RootHansGuard'
}

stop_app_hans_guard() {
    local pid
    if app_hans_guard_alive; then
        read pid < "$APP_HANS_PIDFILE"
        kill "$pid" 2>/dev/null || true
    fi
    rm -f "$APP_HANS_PIDFILE" "$APP_HANS_READY"
}

start_app_hans_guard() {
    local uid pid status wait_count
    app_hans_guard_alive && return 0
    [ "$APP_HANS_RETRY_BACKOFF" -le 0 ] || {
        APP_HANS_RETRY_BACKOFF=$((APP_HANS_RETRY_BACKOFF - 1))
        return 1
    }
    /system/bin/service check oplus_freeze 2>/dev/null \
        | grep -q 'found' || return 0
    [ -r "$APP_APK" ] || return 1

    uid=$(stat -c '%u' "/data/user/0/$APP_PACKAGE" 2>/dev/null)
    case "$uid" in ''|*[!0-9]*) return 1 ;; esac
    rm -f "$APP_HANS_PIDFILE" "$APP_HANS_READY"
    CLASSPATH="$APP_APK" /system/bin/app_process /system/bin \
        com.aatempspoof.tile.RootHansGuard \
        "$uid" "$APP_PACKAGE" "$APP_HANS_READY" >> "$LOG" 2>&1 &
    pid=$!
    printf '%s\n' "$pid" > "$APP_HANS_PIDFILE"
    wait_count=0
    status=
    while [ "$wait_count" -lt 4 ]; do
        status=$(tr -d ' \r\n' < "$APP_HANS_READY" 2>/dev/null)
        [ -n "$status" ] && break
        kill -0 "$pid" 2>/dev/null || break
        wait_count=$((wait_count + 1))
        sleep 1
    done
    if [ "$status" = "1" ] && app_hans_guard_alive; then
        _log "Oplus Hans 充电后台保护已启用 (PID=$pid)"
        APP_HANS_RETRY_BACKOFF=0
        return 0
    fi
    stop_app_hans_guard
    APP_HANS_RETRY_BACKOFF=15
    _log "⚠ Oplus Hans 充电后台保护启动失败 (${status:-无回调})"
    return 1
}

app_package_can_restart() {
    local package_state sdk
    pm path "$APP_PACKAGE" >/dev/null 2>&1 || return 1
    package_state=$(dumpsys package "$APP_PACKAGE" 2>/dev/null)

    sdk=$(getprop ro.build.version.sdk 2>/dev/null | tr -d ' \r\n')
    case "$sdk" in ''|*[!0-9]*) sdk=0 ;; esac
    if [ "$sdk" -ge 33 ]; then
        printf '%s\n' "$package_state" \
            | grep -q 'android.permission.POST_NOTIFICATIONS: granted=true' \
            || return 1
    fi
    return 0
}

ensure_charging_app() {
    app_user_ready || return
    if ! app_device_charging || ! app_live_enabled; then
        if [ "$APP_GUARD_ACTIVE" != "0" ]; then
            /system/bin/am stopservice --user 0 \
                -n "$APP_SERVICE" >/dev/null 2>&1
        fi
        stop_app_hans_guard
        APP_GUARD_ACTIVE=0
        APP_RESTART_BACKOFF=0
        return
    fi
    APP_GUARD_ACTIVE=1
    if app_service_alive; then
        APP_RESTART_BACKOFF=0
    else
        if [ "$APP_RESTART_BACKOFF" -gt 0 ]; then
            APP_RESTART_BACKOFF=$((APP_RESTART_BACKOFF - 1))
        elif ! app_package_can_restart; then
            APP_RESTART_BACKOFF=1
        elif start_charging_app; then
            _log "充电流体云服务缺失，已由 root 守护重新拉起"
            APP_RESTART_BACKOFF=0
        else
            APP_RESTART_BACKOFF=0
        fi
    fi
    start_app_hans_guard || true
}

publish_real_temp_node() {
    (
        local i
        i=0
        while [ "$i" -lt 15 ]; do
            if [ -d /dev/aatempspoof ]; then
                chmod 0711 /dev/aatempspoof 2>/dev/null
                chcon u:object_r:system_file:s0 /dev/aatempspoof 2>/dev/null || true
            fi
            if [ -f /dev/aatempspoof/real_batt_temp ]; then
                chmod 0644 /dev/aatempspoof/real_batt_temp 2>/dev/null
                chcon u:object_r:system_file:s0 \
                    /dev/aatempspoof/real_batt_temp 2>/dev/null || true
                return 0
            fi
            sleep 1
            i=$((i + 1))
        done
    ) &
}

start_daemon() {
    local i p try
    [ -x "$BIN" ] || { _log "AaTempSpoof 二进制不存在或不可执行"; return 1; }
    _start_blocked_by_status integrity && return 1
    is_alive && {
        p=$(_pid_value "$PIDFILE")
        _log "AaTempSpoof 已运行 PID=$p"
        publish_real_temp_node
        return 0
    }

    rm -f "$PIDFILE"
    for try in 1 2 3; do
        _log "启动 AaTempSpoof (${try}/3)"
        "$BIN" --start --moddir "$MODDIR" >/dev/null 2>&1
        _start_blocked_by_status && return 1
        if [ -f "$DONATION_SUSPEND_FLAG" ]; then
            _log "捐赠校验未通过且无72小时有效缓存，本次启动停止重试"
            return 1
        fi
        i=0
        while [ "$i" -lt 10 ]; do
            if is_alive; then
                touch "$FLAGFILE"
                p=$(_pid_value "$PIDFILE")
                _log "AaTempSpoof PID=$p"
                publish_real_temp_node
                return 0
            fi
            sleep 1
            i=$((i + 1))
        done
        _log "AaTempSpoof 第 ${try} 次启动后未确认到进程"
        sleep 2
    done
    _log "⚠ AaTempSpoof 未检测到"
    return 1
}

_start_bg() {
    local tool="$1"
    local pidfile="$2"
    local label="$3"
    local p try i

    [ -x "$BIN" ] || { _log "⚠ AaTempSpoof 不存在或不可执行，无法启动 $label"; return 0; }
    _pid_alive "$pidfile" "$tool" && { p=$(_pid_value "$pidfile"); _log "$label 已运行 PID=$p"; return 0; }

    rm -f "$pidfile"
    for try in 1 2 3; do
        _log "启动 $label (${try}/3)"
        "$BIN" "$tool" >/dev/null 2>&1 &
        p=$!
        i=0
        while [ "$i" -lt 8 ]; do
            if _pid_alive "$pidfile" "$tool"; then
                p=$(_pid_value "$pidfile")
                _log "$label PID=$p"
                return 0
            fi
            if [ "$i" -ge 2 ] && [ -n "$p" ] && kill -0 "$p" 2>/dev/null; then
                printf '%s\n' "$p" > "$pidfile" 2>/dev/null
                _log "$label PID=$p (shell)"
                return 0
            fi
            sleep 1
            i=$((i + 1))
        done
        _log "$label 第 ${try} 次启动后未确认到进程"
        sleep 2
    done
    _log "⚠ $label 未检测到"
    return 1
}

start_cb() {
    _start_bg cb "$CBPID" cb
}

start_touch() {
    _start_bg touch_daemon "$TOUCHPID" touch_daemon
}

start_tombstone() {
    _start_bg color_tombstone "$TOMBSTONEPID" color_tombstone
}

start_charge() {
    _start_bg charge_horae_daemon "$CHARGEPID" charge_horae_daemon
}

ensure_all() {
    local round ok
    _log "$1：检查所有功能进程"
    for round in 1 2 3; do
        ok=1
        if ! is_alive; then
            ok=0
            if ! start_daemon; then
                if [ -f "$DONATION_SUSPEND_FLAG" ]; then
                    _log "$1：捐赠授权暂停，等待下次模块启动重新校验"
                fi
                return 1
            fi
        fi
        if [ -f "$DONATION_SUSPEND_FLAG" ]; then
            _log "$1：捐赠授权暂停，等待下次模块启动重新校验"
            return 1
        fi
        cb_alive        || { ok=0; start_cb; }
        touch_alive     || { ok=0; start_touch; }
        tombstone_alive || { ok=0; start_tombstone; }
        charge_alive    || { ok=0; start_charge; }
        [ "$ok" = "1" ] && { _log "$1：所有功能进程已确认"; return 0; }
        sleep 3
    done
    _log "$1：仍有功能进程未确认，等待后续 watchdog"
    return 1
}

USER_UNLOCK_WAIT=0
if ! app_user_ready; then
    _log "等待用户 0 解锁，暂不启动捐赠硬件证明校验"
fi
while ! app_user_ready; do
    sleep 2
    USER_UNLOCK_WAIT=$((USER_UNLOCK_WAIT + 2))
done
if [ "$USER_UNLOCK_WAIT" -gt 0 ]; then
    _log "用户 0 已解锁，继续启动模块 (${USER_UNLOCK_WAIT}s)"
fi

# Do not insert a kernel bridge while the system is still in the pre-unlock
# boot phase.  Some Android 16 vendor drivers finish registering their IC
# objects only after user 0 is unlocked; loading earlier can reset the device.
if [ "$OPBATT_BRIDGE_STABILIZE_SECONDS" -gt 0 ] 2>/dev/null; then
    _bridge_diag "event=stabilize_wait seconds=$OPBATT_BRIDGE_STABILIZE_SECONDS reason=post_unlock"
    sleep "$OPBATT_BRIDGE_STABILIZE_SECONDS"
fi
if load_opbatt_bridge; then
    start_opbatt_bridge_probation
fi

_sec "守护进程启动"
sync_charge_dual_cell
ensure_all "首次启动"

(sleep 20
 [ -f "$STOP_FLAG" ] && exit 0
 ensure_all "20s 二次确认"
 if [ -s "$PIDFILE" ]; then
     read _p < "$PIDFILE"
     kill -HUP "$_p" 2>/dev/null
     _log "20s SIGHUP 已发送 (PID=$_p)"
 fi
) &

if [ -f "$PIDDIR/hw" ]; then
    _log "检测到 hw 标记，禁用 HW 叠加层"
    service call SurfaceFlinger 1008 i32 1 >/dev/null 2>&1
fi

_sec "启动完成"

if [ -f "$NOTIFY_FILE" ]; then
    (
        _log "开始发送初始化通知"
        notify "$MODULE_NAME" "模块初始化加载中，预计15s加载完成"
        sleep 15
        notify "$MODULE_NAME" "模块加载完成，温控伪装挂载等已生效"
    ) &
else
    _log "通知文件不存在，跳过通知发送"
fi

renice 10 $$ >/dev/null 2>&1

FAIL=0
WATCHDOG_TICKS=0
MAIN_WAS_ALIVE=1
APP_GUARD_ACTIVE=
APP_RESTART_BACKOFF=0
APP_HANS_RETRY_BACKOFF=0

while true; do
    sleep 2

    sync_charge_dual_cell
    ensure_charging_app

    if is_alive; then
        MAIN_WAS_ALIVE=1
    elif [ "$MAIN_WAS_ALIVE" = "1" ]; then
        [ -w "$GAUGE_PATH" ] && printf '0\n' > "$GAUGE_PATH" 2>/dev/null
        _clear_kernel_virtual_gauge
        _clear_kernel_usb_therm
        MAIN_WAS_ALIVE=0
        _log "⚠ AaTempSpoof 异常退出，内核温度伪装已复位"
    fi

    WATCHDOG_TICKS=$((WATCHDOG_TICKS + 1))
    [ "$WATCHDOG_TICKS" -lt 60 ] && continue
    WATCHDOG_TICKS=0

    [ -f "$STOP_FLAG" ] && continue
    [ -f "$DONATION_SUSPEND_FLAG" ] && continue
    [ -s "$INTEGRITY_STATUS_FILE" ] && continue

    if [ -f "$OPBATT_BRIDGE_DEFERRED" ] &&
       ! _opbatt_bridge_loaded && ! _opbatt_charger_online; then
        if load_opbatt_bridge; then
            start_opbatt_bridge_probation
        fi
    fi

    if ! is_alive; then
        FAIL=$((FAIL + 1))
        _log "⚠ AaTempSpoof 死亡 ($FAIL/5)"
        _clear_kernel_virtual_gauge
        _clear_kernel_usb_therm
        rm -f "$PIDFILE"
        start_daemon && FAIL=0
    else
        FAIL=0
    fi

    if ! cb_alive; then
        _log "⚠ cb 死亡"
        rm -f "$CBPID"
        start_cb
    fi

    if ! touch_alive; then
        _log "⚠ touch_daemon 死亡"
        rm -f "$TOUCHPID"
        start_touch
    fi

    if ! tombstone_alive; then
        _log "⚠ color_tombstone 死亡"
        rm -f "$TOMBSTONEPID"
        start_tombstone
    fi

    if ! charge_alive; then
        _log "⚠ charge_horae_daemon 死亡"
        rm -f "$CHARGEPID"
        start_charge
    fi

    if [ "$FAIL" -gt 5 ]; then
        _log "✗ AaTempSpoof 连续重启失败，延长等待后继续监控"
        sleep 300
        FAIL=0
    fi
done
