#!/system/bin/sh

MODDIR="/data/adb/modules/AAaTempSpoof"
BIN="$MODDIR/bin/AaTempSpoof"

[ -x "$BIN" ] || exit 1
if [ "$#" -eq 2 ] && [ "$1" = "--from-webui" ] && [ -n "$2" ]; then
    exec "$BIN" --queue-webui-uninstall "$2"
fi
exec "$BIN" --cancel-external-uninstall
