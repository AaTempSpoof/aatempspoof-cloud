#!/system/bin/sh

MODDIR="/data/adb/modules/AAaTempSpoof"
BIN="$MODDIR/bin/AaTempSpoof"

[ -x "$BIN" ] || exit 1
exec "$BIN" --module-action "$MODDIR"
