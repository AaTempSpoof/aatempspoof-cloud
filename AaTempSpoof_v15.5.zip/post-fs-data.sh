#!/system/bin/sh
MODDIR=${0%/*}
BIN="$MODDIR/bin/AaTempSpoof"
KCOMPAT_COLLECTOR="$MODDIR/bin/kcompat/collect.sh"

[ -x "$BIN" ] || exit 0
"$BIN" --boot-grace --moddir "$MODDIR" >/dev/null 2>&1 &

if [ -r "$KCOMPAT_COLLECTOR" ]; then
    if [ -x /system/bin/timeout ]; then
        /system/bin/timeout -k 2 12 /system/bin/sh \
            "$KCOMPAT_COLLECTOR" --preserve-pstore >/dev/null 2>&1
    else
        /system/bin/sh "$KCOMPAT_COLLECTOR" --preserve-pstore >/dev/null 2>&1
    fi
fi
"$BIN" --post-fs-data --moddir "$MODDIR" >/dev/null 2>&1
exit 0
