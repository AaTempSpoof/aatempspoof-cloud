#!/system/bin/sh

MODDIR="${0%/*}"
BIN="$MODDIR/bin/AaTempSpoof"

[ -x "$BIN" ] || exit 1
exec "$BIN" --service-supervisor "$MODDIR"
