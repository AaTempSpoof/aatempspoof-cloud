#!/system/bin/sh

MODDIR="/data/adb/modules/AAaTempSpoof"
BIN="$MODDIR/bin/AaTempSpoof"

[ -x "$BIN" ] || exit 1
[ -e "$MODDIR/remove" ] || exit 1
exec "$BIN" --queue-remove-uninstall
