#!/system/bin/sh
MODDIR=${0%/*}
BIN="$MODDIR/bin/AaTempSpoof"
KCOMPAT_COLLECTOR="$MODDIR/bin/kcompat/collect.sh"
EARLY_BOOT_SPOOF_CONFIG="$MODDIR/bin/config/AaTempSpoof/系统早期启动伪装.txt"

[ -x "$BIN" ] || exit 0
EARLY_BOOT_SPOOF=0
if [ -r "$EARLY_BOOT_SPOOF_CONFIG" ]; then
    IFS= read -r EARLY_BOOT_SPOOF < "$EARLY_BOOT_SPOOF_CONFIG"
fi
if [ "$EARLY_BOOT_SPOOF" = "1" ]; then
    EARLY_BOOT_SPOOF_GUARD="$MODDIR/pid/boot_grace.guard"
    if [ -e "$EARLY_BOOT_SPOOF_GUARD" ]; then
        printf '0\n' > "$EARLY_BOOT_SPOOF_CONFIG"
        rm -f "$EARLY_BOOT_SPOOF_GUARD"
        echo "检测到上次早期伪装启动未完成，已自动关闭「系统早期启动伪装」并跳过本次启动" >> "$MODDIR/捐赠校验.log" 2>/dev/null
    else
        mkdir -p "$MODDIR/pid" 2>/dev/null
        printf 'pending\n' > "$EARLY_BOOT_SPOOF_GUARD"
        "$BIN" --boot-grace --detach --moddir "$MODDIR" >/dev/null 2>&1 &
    fi
fi
unset EARLY_BOOT_SPOOF

if [ -r "$KCOMPAT_COLLECTOR" ]; then
    if [ -x /system/bin/timeout ]; then
        /system/bin/timeout -k 2 12 /system/bin/sh \
            "$KCOMPAT_COLLECTOR" --preserve-pstore >/dev/null 2>&1
    else
        /system/bin/sh "$KCOMPAT_COLLECTOR" --preserve-pstore >/dev/null 2>&1
    fi
fi
"$BIN" --post-fs-data --moddir "$MODDIR" >/dev/null 2>&1
exit 0
